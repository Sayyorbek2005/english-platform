import { useState, useContext } from 'react';
import { motion } from 'framer-motion';
import { ThemeContext } from '../context/ThemeContext';
import ModalForm from '../components/ModalForm';
import './About.css';

const About = () => {
  const [modalOpen, setModalOpen] = useState(false);
  const { language } = useContext(ThemeContext);

  const translations = {
    en: {
      title: 'About Me',
      subtitle: "I'm Ismailov and Web Developer",
      description: "I'm a passionate web developer with over 10 years of experience in creating beautiful and functional websites. My expertise includes modern web technologies, responsive design, and user experience optimization. I love turning complex problems into simple, elegant solutions.",
      info: [
        { label: 'Birthday', value: '5 June 1999' },
        { label: 'Age', value: '24' },
        { label: 'Website', value: 'www.ismailov.com' },
        { label: 'Email', value: 'info@gmail.com' },
        { label: 'Degree', value: 'Computer Science' },
        { label: 'Phone', value: '+998 93 000 19 99' },
        { label: 'City', value: 'Tashkent' },
        { label: 'Freelance', value: 'Available' }
      ],
      skills: [
        { name: 'HTML/CSS', level: 95 },
        { name: 'JavaScript', level: 90 },
        { name: 'React', level: 85 },
        { name: 'Node.js', level: 80 }
      ],
      downloadCV: 'Download CV',
      hireMe: 'Hire Me'
    },
    ru: {
      title: 'Обо мне',
      subtitle: 'Я Исмаилов и веб-разработчик',
      description: 'Я увлеченный веб-разработчик с более чем 10-летним опытом создания красивых и функциональных веб-сайтов. Моя специализация включает современные веб-технологии, адаптивный дизайн и оптимизацию пользовательского опыта. Я люблю превращать сложные проблемы в простые и элегантные решения.',
      info: [
        { label: 'День рождения', value: '5 июня 1999' },
        { label: 'Возраст', value: '24' },
        { label: 'Веб-сайт', value: 'www.ismailov.com' },
        { label: 'Email', value: 'info@gmail.com' },
        { label: 'Степень', value: 'Информатика' },
        { label: 'Телефон', value: '+998 93 000 19 99' },
        { label: 'Город', value: 'Ташкент' },
        { label: 'Фриланс', value: 'Доступен' }
      ],
      skills: [
        { name: 'HTML/CSS', level: 95 },
        { name: 'JavaScript', level: 90 },
        { name: 'React', level: 85 },
        { name: 'Node.js', level: 80 }
      ],
      downloadCV: 'Скачать резюме',
      hireMe: 'Нанять меня'
    },
    uz: {
      title: 'Men haqimda',
      subtitle: 'Men Ismailov va veb-dasturchiman',
      description: "Men 10 yildan ortiq tajribaga ega bo'lgan veb-dasturchiman. Mening mutaxassisligim zamonaviy veb-texnologiyalar, moslashuvchan dizayn va foydalanuvchi tajribasini optimallashtirish. Men murakkab muammolarni oddiy va oqlangan yechimlarga aylantirishni yaxshi ko'raman.",
      info: [
        { label: 'Tug\'ilgan kun', value: '5 iyun 1999' },
        { label: 'Yosh', value: '24' },
        { label: 'Veb-sayt', value: 'www.ismailov.com' },
        { label: 'Email', value: 'info@gmail.com' },
        { label: 'Daraja', value: 'Kompyuter fanlari' },
        { label: 'Telefon', value: '+998 93 000 19 99' },
        { label: 'Shahar', value: 'Toshkent' },
        { label: 'Frilans', value: 'Mavjud' }
      ],
      skills: [
        { name: 'HTML/CSS', level: 95 },
        { name: 'JavaScript', level: 90 },
        { name: 'React', level: 85 },
        { name: 'Node.js', level: 80 }
      ],
      downloadCV: 'CV yuklab olish',
      hireMe: 'Meni ishga oling'
    }
  };

  const t = translations[language];

  const handleDownloadCV = () => {
    const link = document.createElement('a');
    link.href = '/cv-sample.pdf';
    link.download = 'Ismailov-CV.pdf';
    link.click();
  };

  return (
    <section id="about" className="about-section">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
      >
        <h2 className="section-title">{t.title}</h2>

        <div className="about-container">
          <div className="about-content">
            <h3 className="about-subtitle">{t.subtitle}</h3>
            <p className="about-description">{t.description}</p>

            <div className="about-info">
              {t.info.map((item, index) => (
                <div key={index} className="info-item">
                  <span className="info-label">{item.label}:</span>
                  <span className="info-value">{item.value}</span>
                </div>
              ))}
            </div>

            <div className="about-buttons">
              <motion.button
                className="about-button primary"
                onClick={handleDownloadCV}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                {t.downloadCV}
              </motion.button>
              <motion.button
                className="about-button secondary"
                onClick={() => setModalOpen(true)}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                {t.hireMe}
              </motion.button>
            </div>
          </div>

          <div className="about-skills">
            {t.skills.map((skill, index) => (
              <motion.div
                key={index}
                className="skill-item"
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <div className="skill-header">
                  <span className="skill-name">{skill.name}</span>
                  <span className="skill-percentage">{skill.level}%</span>
                </div>
                <div className="skill-bar">
                  <motion.div
                    className="skill-progress"
                    initial={{ width: 0 }}
                    whileInView={{ width: `${skill.level}%` }}
                    viewport={{ once: true }}
                    transition={{ duration: 1, delay: 0.5 + index * 0.1 }}
                  />
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </motion.div>

      <ModalForm isOpen={modalOpen} onClose={() => setModalOpen(false)} />
    </section>
  );
};

export default About;
