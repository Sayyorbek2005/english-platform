import { useContext } from 'react';
import { motion } from 'framer-motion';
import { FaMobileAlt, FaLaptopCode, FaPalette, FaCode, FaSearch, FaBullhorn } from 'react-icons/fa';
import { ThemeContext } from '../context/ThemeContext';
import './Services.css';

const Services = () => {
  const { language } = useContext(ThemeContext);

  const translations = {
    en: {
      title: 'Services',
      services: [
        {
          icon: <FaMobileAlt />,
          title: 'Responsive Design',
          description: 'Creating mobile-friendly designs that work seamlessly across all devices and screen sizes.'
        },
        {
          icon: <FaLaptopCode />,
          title: 'Web Development',
          description: 'Building modern, fast, and scalable web applications using the latest technologies.'
        },
        {
          icon: <FaPalette />,
          title: 'UI/UX Design',
          description: 'Designing beautiful and intuitive user interfaces with exceptional user experience.'
        },
        {
          icon: <FaCode />,
          title: 'Frontend Development',
          description: 'Crafting interactive and dynamic user interfaces with React and modern frameworks.'
        },
        {
          icon: <FaSearch />,
          title: 'SEO Optimization',
          description: 'Improving website visibility and ranking in search engines for better reach.'
        },
        {
          icon: <FaBullhorn />,
          title: 'Digital Marketing',
          description: 'Helping businesses grow online through effective digital marketing strategies.'
        }
      ]
    },
    ru: {
      title: 'Услуги',
      services: [
        {
          icon: <FaMobileAlt />,
          title: 'Адаптивный дизайн',
          description: 'Создание мобильных дизайнов, которые безупречно работают на всех устройствах.'
        },
        {
          icon: <FaLaptopCode />,
          title: 'Веб-разработка',
          description: 'Создание современных, быстрых и масштабируемых веб-приложений.'
        },
        {
          icon: <FaPalette />,
          title: 'UI/UX дизайн',
          description: 'Разработка красивых и интуитивных пользовательских интерфейсов.'
        },
        {
          icon: <FaCode />,
          title: 'Frontend разработка',
          description: 'Создание интерактивных и динамичных пользовательских интерфейсов.'
        },
        {
          icon: <FaSearch />,
          title: 'SEO оптимизация',
          description: 'Улучшение видимости и рейтинга сайта в поисковых системах.'
        },
        {
          icon: <FaBullhorn />,
          title: 'Цифровой маркетинг',
          description: 'Помощь бизнесу в развитии через эффективные маркетинговые стратегии.'
        }
      ]
    },
    uz: {
      title: 'Xizmatlar',
      services: [
        {
          icon: <FaMobileAlt />,
          title: 'Moslashuvchan dizayn',
          description: "Barcha qurilmalarda mukammal ishlaydigan mobil dizaynlarni yaratish."
        },
        {
          icon: <FaLaptopCode />,
          title: 'Veb-dasturlash',
          description: "Zamonaviy texnologiyalar yordamida tez va kengaytiriladigan veb-ilovalar yaratish."
        },
        {
          icon: <FaPalette />,
          title: 'UI/UX dizayn',
          description: "Chiroyli va intuitiv foydalanuvchi interfeyslarini yaratish."
        },
        {
          icon: <FaCode />,
          title: 'Frontend dasturlash',
          description: "React va zamonaviy freymvorklar bilan interaktiv interfeyslar yaratish."
        },
        {
          icon: <FaSearch />,
          title: 'SEO optimallashtirish',
          description: "Veb-saytni qidiruv tizimlarida ko'rinadigan qilish va reytingini oshirish."
        },
        {
          icon: <FaBullhorn />,
          title: 'Raqamli marketing',
          description: "Biznesni samarali marketing strategiyalari orqali onlayn rivojlantirish."
        }
      ]
    }
  };

  const t = translations[language];

  return (
    <section id="services" className="services-section">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
      >
        <h2 className="section-title">{t.title}</h2>

        <div className="services-grid">
          {t.services.map((service, index) => (
            <motion.div
              key={index}
              className="service-card"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              whileHover={{ y: -10 }}
            >
              <div className="service-icon">{service.icon}</div>
              <h3 className="service-title">{service.title}</h3>
              <p className="service-description">{service.description}</p>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </section>
  );
};

export default Services;
