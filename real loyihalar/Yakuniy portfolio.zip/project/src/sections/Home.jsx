import { useState, useContext } from 'react';
import { motion } from 'framer-motion';
import { ThemeContext } from '../context/ThemeContext';
import ModalForm from '../components/ModalForm';
import profileImage from '../assets/image.png';
import './Home.css';

const Home = () => {
  const [modalOpen, setModalOpen] = useState(false);
  const { language } = useContext(ThemeContext);

  const translations = {
    en: {
      greeting: 'Hello, my name is',
      name: 'Ismailov',
      title: "I'm a Web Developer",
      description: "I'm a web designer with extensive experience for over 10 years. My expertise is to create and website design, graphic design, and many more...",
      button: 'More About Me'
    },
    ru: {
      greeting: 'Привет, меня зовут',
      name: 'Исмаилов',
      title: 'Я веб-разработчик',
      description: 'Я веб-дизайнер с обширным опытом работы более 10 лет. Моя специализация - создание веб-сайтов, графический дизайн и многое другое...',
      button: 'Подробнее обо мне'
    },
    uz: {
      greeting: 'Salom, mening ismim',
      name: 'Ismailov',
      title: 'Men veb-dasturchiman',
      description: "Men 10 yildan ortiq tajribaga ega veb-dizaynerman. Mening mutaxassisligim - veb-saytlar yaratish, grafik dizayn va boshqa ko'p narsalar...",
      button: 'Men haqimda ko\'proq'
    }
  };

  const t = translations[language];

  return (
    <section id="home" className="home-section">
      <div className="home-container">
        <motion.div
          className="home-content"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <p className="home-greeting">{t.greeting} <span className="home-name">{t.name}</span></p>
          <h1 className="home-title">{t.title}</h1>
          <p className="home-description">{t.description}</p>

          <motion.button
            className="home-button"
            onClick={() => setModalOpen(true)}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            {t.button}
          </motion.button>
        </motion.div>

        <motion.div
          className="home-image"
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <div className="image-wrapper">
            <img src={profileImage} alt="Profile" />
          </div>
        </motion.div>
      </div>

      <ModalForm isOpen={modalOpen} onClose={() => setModalOpen(false)} />
    </section>
  );
};

export default Home;
