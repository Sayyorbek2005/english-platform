import { useState, useContext } from 'react';
import { motion } from 'framer-motion';
import { FaLinkedin, FaGithub, FaTelegram, FaPhone, FaMapMarkerAlt, FaEnvelope, FaGlobe } from 'react-icons/fa';
import { toast } from 'react-toastify';
import { ThemeContext } from '../context/ThemeContext';
import './Contact.css';

const Contact = () => {
  const { language } = useContext(ThemeContext);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });

  const translations = {
    en: {
      title: 'Contact Me',
      heading: 'Have You Any Questions?',
      subheading: "I'M AT YOUR SERVICE",
      contactInfo: [
        { icon: <FaPhone />, label: 'Call Us On', value: '+998 93 000 19 99' },
        { icon: <FaMapMarkerAlt />, label: 'Office', value: '44 Street, Tashkent' },
        { icon: <FaEnvelope />, label: 'Email', value: 'info@ismailov.com' },
        { icon: <FaGlobe />, label: 'Website', value: 'www.ismailov.com' }
      ],
      formTitle: 'SEND ME AN EMAIL',
      formSubtitle: "I'M VERY RESPONSIVE TO MESSAGES",
      name: 'Name',
      email: 'Email',
      subject: 'Subject',
      message: 'Message',
      send: 'Send Message',
      success: 'Message sent successfully!',
      error: 'Please fill all fields'
    },
    ru: {
      title: 'Контакты',
      heading: 'У вас есть вопросы?',
      subheading: 'Я К ВАШИМ УСЛУГАМ',
      contactInfo: [
        { icon: <FaPhone />, label: 'Позвоните', value: '+998 93 000 19 99' },
        { icon: <FaMapMarkerAlt />, label: 'Офис', value: '44 улица, Ташкент' },
        { icon: <FaEnvelope />, label: 'Email', value: 'info@ismailov.com' },
        { icon: <FaGlobe />, label: 'Веб-сайт', value: 'www.ismailov.com' }
      ],
      formTitle: 'ОТПРАВЬТЕ МНЕ EMAIL',
      formSubtitle: 'Я ВСЕГДА ОТВЕЧАЮ НА СООБЩЕНИЯ',
      name: 'Имя',
      email: 'Email',
      subject: 'Тема',
      message: 'Сообщение',
      send: 'Отправить',
      success: 'Сообщение успешно отправлено!',
      error: 'Пожалуйста, заполните все поля'
    },
    uz: {
      title: 'Aloqa',
      heading: 'Savollaringiz bormi?',
      subheading: 'MEN SIZNING XIZMATINGIZDAMAN',
      contactInfo: [
        { icon: <FaPhone />, label: 'Qo\'ng\'iroq qiling', value: '+998 93 000 19 99' },
        { icon: <FaMapMarkerAlt />, label: 'Ofis', value: '44 ko\'cha, Toshkent' },
        { icon: <FaEnvelope />, label: 'Email', value: 'info@ismailov.com' },
        { icon: <FaGlobe />, label: 'Veb-sayt', value: 'www.ismailov.com' }
      ],
      formTitle: 'MENGA EMAIL YUBORING',
      formSubtitle: "MEN XABARLARGA TEZDA JAVOB BERAMAN",
      name: 'Ism',
      email: 'Email',
      subject: 'Mavzu',
      message: 'Xabar',
      send: 'Yuborish',
      success: 'Xabar muvaffaqiyatli yuborildi!',
      error: 'Iltimos, barcha maydonlarni to\'ldiring'
    }
  };

  const t = translations[language];

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!formData.name || !formData.email || !formData.subject || !formData.message) {
      toast.error(t.error);
      return;
    }

    toast.success(t.success);
    setFormData({ name: '', email: '', subject: '', message: '' });
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const socialLinks = [
    { icon: <FaLinkedin />, url: 'https://linkedin.com' },
    { icon: <FaGithub />, url: 'https://github.com' },
    { icon: <FaTelegram />, url: 'https://telegram.org' }
  ];

  return (
    <section id="contact" className="contact-section">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
      >
        <h2 className="section-title">{t.title}</h2>

        <div className="contact-intro">
          <h3 className="contact-heading">{t.heading}</h3>
          <p className="contact-subheading">{t.subheading}</p>
        </div>

        <div className="contact-info-grid">
          {t.contactInfo.map((item, index) => (
            <motion.div
              key={index}
              className="contact-info-card"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <div className="contact-info-icon">{item.icon}</div>
              <h4 className="contact-info-label">{item.label}</h4>
              <p className="contact-info-value">{item.value}</p>
            </motion.div>
          ))}
        </div>

        <div className="contact-form-section">
          <h3 className="form-title">{t.formTitle}</h3>
          <p className="form-subtitle">{t.formSubtitle}</p>

          <form className="contact-form" onSubmit={handleSubmit}>
            <div className="form-row">
              <input
                type="text"
                name="name"
                placeholder={t.name}
                value={formData.name}
                onChange={handleChange}
                className="form-input"
              />
              <input
                type="email"
                name="email"
                placeholder={t.email}
                value={formData.email}
                onChange={handleChange}
                className="form-input"
              />
            </div>

            <input
              type="text"
              name="subject"
              placeholder={t.subject}
              value={formData.subject}
              onChange={handleChange}
              className="form-input"
            />

            <textarea
              name="message"
              placeholder={t.message}
              value={formData.message}
              onChange={handleChange}
              className="form-textarea"
              rows="6"
            />

            <motion.button
              type="submit"
              className="form-submit"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              {t.send}
            </motion.button>
          </form>

          <div className="social-links">
            {socialLinks.map((link, index) => (
              <motion.a
                key={index}
                href={link.url}
                target="_blank"
                rel="noopener noreferrer"
                className="social-link"
                whileHover={{ scale: 1.2, y: -5 }}
                whileTap={{ scale: 0.9 }}
              >
                {link.icon}
              </motion.a>
            ))}
          </div>
        </div>
      </motion.div>
    </section>
  );
};

export default Contact;
