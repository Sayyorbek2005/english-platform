import { useState, useContext, useRef, useEffect } from 'react';
import { FaCog, FaGlobe } from 'react-icons/fa';
import { ThemeContext } from '../context/ThemeContext';
import { motion, AnimatePresence } from 'framer-motion';
import './Header.css';

const Header = () => {
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [languageOpen, setLanguageOpen] = useState(false);
  const { theme, setTheme, darkMode, setDarkMode, language, setLanguage } = useContext(ThemeContext);
  const settingsRef = useRef(null);
  const languageRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (settingsRef.current && !settingsRef.current.contains(event.target)) {
        setSettingsOpen(false);
      }
      if (languageRef.current && !languageRef.current.contains(event.target)) {
        setLanguageOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const languages = [
    { code: 'uz', label: 'O\'zbekcha' },
    { code: 'ru', label: 'Русский' },
    { code: 'en', label: 'English' }
  ];

  const themes = [
    { name: 'red', color: '#ef4444' },
    { name: 'blue', color: '#3b82f6' },
    { name: 'green', color: '#10b981' }
  ];

  return (
    <header className="header">
      <div className="header-icons">
        <div className="icon-wrapper" ref={settingsRef}>
          <button
            className="header-icon"
            onClick={() => {
              setSettingsOpen(!settingsOpen);
              setLanguageOpen(false);
            }}
          >
            <FaCog />
          </button>

          <AnimatePresence>
            {settingsOpen && (
              <motion.div
                className="settings-dropdown"
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
              >
                <div className="dropdown-section">
                  <label className="dropdown-label">Dark Mode</label>
                  <button
                    className={`toggle-btn ${darkMode ? 'active' : ''}`}
                    onClick={() => setDarkMode(!darkMode)}
                  >
                    <span className="toggle-slider"></span>
                  </button>
                </div>

                <div className="dropdown-section">
                  <label className="dropdown-label">Theme Color</label>
                  <div className="color-options">
                    {themes.map(t => (
                      <button
                        key={t.name}
                        className={`color-circle ${theme === t.name ? 'active' : ''}`}
                        style={{ backgroundColor: t.color }}
                        onClick={() => setTheme(t.name)}
                      />
                    ))}
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <div className="icon-wrapper" ref={languageRef}>
          <button
            className="header-icon"
            onClick={() => {
              setLanguageOpen(!languageOpen);
              setSettingsOpen(false);
            }}
          >
            <FaGlobe />
          </button>

          <AnimatePresence>
            {languageOpen && (
              <motion.div
                className="language-dropdown"
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
              >
                {languages.map(lang => (
                  <button
                    key={lang.code}
                    className={`language-option ${language === lang.code ? 'active' : ''}`}
                    onClick={() => {
                      setLanguage(lang.code);
                      setLanguageOpen(false);
                    }}
                  >
                    {lang.label}
                  </button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </header>
  );
};

export default Header;
