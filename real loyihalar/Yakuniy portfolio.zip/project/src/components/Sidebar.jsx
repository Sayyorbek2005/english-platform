import { useState, useContext } from 'react';
import { FaHome, FaUser, FaBriefcase, FaEnvelope, FaBars, FaTimes } from 'react-icons/fa';
import { ThemeContext } from '../context/ThemeContext';
import './Sidebar.css';

const Sidebar = ({ activeSection }) => {
  const [menuOpen, setMenuOpen] = useState(false);
  const { language } = useContext(ThemeContext);

  const translations = {
    en: {
      home: 'Home',
      about: 'About',
      services: 'Services',
      contact: 'Contact'
    },
    ru: {
      home: 'Главная',
      about: 'Обо мне',
      services: 'Услуги',
      contact: 'Контакты'
    },
    uz: {
      home: 'Bosh sahifa',
      about: 'Men haqimda',
      services: 'Xizmatlar',
      contact: 'Aloqa'
    }
  };

  const t = translations[language];

  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    setMenuOpen(false);
  };

  const menuItems = [
    { id: 'home', label: t.home, icon: <FaHome /> },
    { id: 'about', label: t.about, icon: <FaUser /> },
    { id: 'services', label: t.services, icon: <FaBriefcase /> },
    { id: 'contact', label: t.contact, icon: <FaEnvelope /> }
  ];

  return (
    <>
      <button className="hamburger" onClick={() => setMenuOpen(!menuOpen)}>
        {menuOpen ? <FaTimes /> : <FaBars />}
      </button>

      <aside className={`sidebar ${menuOpen ? 'open' : ''}`}>
        <div className="sidebar-logo">Ismailov</div>

        <nav className="sidebar-nav">
          {menuItems.map(item => (
            <button
              key={item.id}
              className={`nav-item ${activeSection === item.id ? 'active' : ''}`}
              onClick={() => scrollToSection(item.id)}
            >
              <span className="nav-icon">{item.icon}</span>
              <span className="nav-label">{item.label}</span>
            </button>
          ))}
        </nav>
      </aside>

      {menuOpen && <div className="sidebar-overlay" onClick={() => setMenuOpen(false)} />}
    </>
  );
};

export default Sidebar;
