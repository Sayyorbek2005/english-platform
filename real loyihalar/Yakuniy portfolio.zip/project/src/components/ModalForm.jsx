import { useState, useContext } from 'react';
import Modal from 'react-modal';
import { toast } from 'react-toastify';
import { motion } from 'framer-motion';
import { ThemeContext } from '../context/ThemeContext';
import './ModalForm.css';

Modal.setAppElement('#root');

const ModalForm = ({ isOpen, onClose }) => {
  const { language } = useContext(ThemeContext);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    phone: ''
  });

  const translations = {
    en: {
      title: 'Contact Information',
      firstName: 'First Name',
      lastName: 'Last Name',
      phone: 'Phone Number',
      submit: 'Submit',
      cancel: 'Cancel',
      success: 'Successfully submitted!',
      error: 'Please fill all fields'
    },
    ru: {
      title: 'Контактная информация',
      firstName: 'Имя',
      lastName: 'Фамилия',
      phone: 'Номер телефона',
      submit: 'Отправить',
      cancel: 'Отмена',
      success: 'Успешно отправлено!',
      error: 'Пожалуйста, заполните все поля'
    },
    uz: {
      title: 'Aloqa ma\'lumotlari',
      firstName: 'Ism',
      lastName: 'Familiya',
      phone: 'Telefon raqam',
      submit: 'Yuborish',
      cancel: 'Bekor qilish',
      success: 'Muvaffaqiyatli yuborildi!',
      error: 'Iltimos, barcha maydonlarni to\'ldiring'
    }
  };

  const t = translations[language];

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!formData.firstName || !formData.lastName || !formData.phone) {
      toast.error(t.error);
      return;
    }

    toast.success(t.success);
    setFormData({ firstName: '', lastName: '', phone: '' });
    onClose();
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <Modal
      isOpen={isOpen}
      onRequestClose={onClose}
      className="modal-content"
      overlayClassName="modal-overlay"
      closeTimeoutMS={200}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        transition={{ duration: 0.2 }}
      >
        <h2 className="modal-title">{t.title}</h2>
        <form onSubmit={handleSubmit} className="modal-form">
          <div className="form-group">
            <input
              type="text"
              name="firstName"
              placeholder={t.firstName}
              value={formData.firstName}
              onChange={handleChange}
              className="form-input"
            />
          </div>

          <div className="form-group">
            <input
              type="text"
              name="lastName"
              placeholder={t.lastName}
              value={formData.lastName}
              onChange={handleChange}
              className="form-input"
            />
          </div>

          <div className="form-group">
            <input
              type="tel"
              name="phone"
              placeholder="(+998) 00-000-00-00"
              value={formData.phone}
              onChange={handleChange}
              className="form-input"
            />
          </div>

          <div className="modal-buttons">
            <button type="submit" className="btn-submit">
              {t.submit}
            </button>
            <button type="button" onClick={onClose} className="btn-cancel">
              {t.cancel}
            </button>
          </div>
        </form>
      </motion.div>
    </Modal>
  );
};

export default ModalForm;
