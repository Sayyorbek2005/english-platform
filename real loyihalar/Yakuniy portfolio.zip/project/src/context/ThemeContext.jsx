import { createContext, useState, useEffect } from 'react';

export const ThemeContext = createContext();

export const ThemeProvider = ({ children }) => {
  const [theme, setTheme] = useState(() => {
    return localStorage.getItem('theme') || 'blue';
  });

  const [darkMode, setDarkMode] = useState(() => {
    return localStorage.getItem('darkMode') === 'true';
  });

  const [language, setLanguage] = useState(() => {
    return localStorage.getItem('language') || 'en';
  });

  useEffect(() => {
    localStorage.setItem('theme', theme);
    document.documentElement.style.setProperty('--accent-color', getAccentColor(theme));
  }, [theme]);

  useEffect(() => {
    localStorage.setItem('darkMode', darkMode);
    document.documentElement.style.setProperty('--bg-color', darkMode ? '#1a1a1a' : '#f5f5f5');
    document.documentElement.style.setProperty('--text-color', darkMode ? '#ffffff' : '#333333');
    document.documentElement.style.setProperty('--card-bg', darkMode ? '#252525' : '#ffffff');
    document.documentElement.style.setProperty('--sidebar-bg', darkMode ? '#202020' : '#ffffff');
  }, [darkMode]);

  useEffect(() => {
    localStorage.setItem('language', language);
  }, [language]);

  const getAccentColor = (themeName) => {
    const colors = {
      blue: '#3b82f6',
      red: '#ef4444',
      green: '#10b981'
    };
    return colors[themeName] || colors.blue;
  };

  return (
    <ThemeContext.Provider value={{ theme, setTheme, darkMode, setDarkMode, language, setLanguage }}>
      {children}
    </ThemeContext.Provider>
  );
};
