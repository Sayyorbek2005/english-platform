import React, { useState, useEffect } from 'react';
import Tile from './Tile';
import { RefreshCw, Trophy } from 'lucide-react';

interface TileData {
  id: number;
  number: number;
  isRevealed: boolean;
  isMatched: boolean;
}

const GameBoard: React.FC = () => {
  const [tiles, setTiles] = useState<TileData[]>([]);
  const [revealedTiles, setRevealedTiles] = useState<number[]>([]);
  const [isGameWon, setIsGameWon] = useState(false);
  const [isChecking, setIsChecking] = useState(false);
  const [moves, setMoves] = useState(0);

  // Generate shuffled numbers
  const generateShuffledNumbers = (): number[] => {
    const numbers = [];
    for (let i = 1; i <= 10; i++) {
      numbers.push(i, i); // Add each number twice
    }
    
    // Fisher-Yates shuffle algorithm
    for (let i = numbers.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [numbers[i], numbers[j]] = [numbers[j], numbers[i]];
    }
    
    return numbers;
  };

  // Initialize game
  const initializeGame = () => {
    const shuffledNumbers = generateShuffledNumbers();
    const newTiles = shuffledNumbers.map((number, index) => ({
      id: index,
      number,
      isRevealed: false,
      isMatched: false
    }));
    
    setTiles(newTiles);
    setRevealedTiles([]);
    setIsGameWon(false);
    setIsChecking(false);
    setMoves(0);
  };

  // Initialize game on component mount
  useEffect(() => {
    initializeGame();
  }, []);

  // Handle tile click
  const handleTileClick = (id: number) => {
    if (isChecking || revealedTiles.length >= 2) return;

    setTiles(prev => prev.map(tile => 
      tile.id === id ? { ...tile, isRevealed: true } : tile
    ));

    const newRevealedTiles = [...revealedTiles, id];
    setRevealedTiles(newRevealedTiles);

    if (newRevealedTiles.length === 2) {
      setIsChecking(true);
      setMoves(prev => prev + 1);
      
      setTimeout(() => {
        checkForMatch(newRevealedTiles);
      }, 1000);
    }
  };

  // Check if revealed tiles match
  const checkForMatch = (revealedIds: number[]) => {
    const [firstId, secondId] = revealedIds;
    const firstTile = tiles.find(tile => tile.id === firstId);
    const secondTile = tiles.find(tile => tile.id === secondId);

    if (firstTile && secondTile && firstTile.number === secondTile.number) {
      // Match found
      setTiles(prev => prev.map(tile => 
        revealedIds.includes(tile.id) 
          ? { ...tile, isMatched: true }
          : tile
      ));
    } else {
      // No match - hide tiles
      setTiles(prev => prev.map(tile => 
        revealedIds.includes(tile.id)
          ? { ...tile, isRevealed: false }
          : tile
      ));
    }

    setRevealedTiles([]);
    setIsChecking(false);
  };

  // Check for game completion
  useEffect(() => {
    const allMatched = tiles.length > 0 && tiles.every(tile => tile.isMatched);
    if (allMatched && !isGameWon) {
      setIsGameWon(true);
    }
  }, [tiles, isGameWon]);

  return (
    <div className="flex flex-col items-center p-4 sm:p-8">
      {/* Header */}
      <div className="mb-8 text-center">
        <h1 className="text-4xl sm:text-5xl font-bold text-slate-800 mb-4">
          Memory Game
        </h1>
        <p className="text-slate-600 mb-4">
          Find all matching pairs by clicking on the tiles
        </p>
        <div className="flex items-center justify-center gap-4 mb-4">
          <div className="bg-white px-4 py-2 rounded-lg shadow-md">
            <span className="text-slate-600">Moves: </span>
            <span className="font-bold text-slate-800">{moves}</span>
          </div>
          <button
            onClick={initializeGame}
            className="flex items-center gap-2 bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg shadow-md transition-colors duration-200"
          >
            <RefreshCw size={16} />
            New Game
          </button>
        </div>
      </div>

      {/* Game Board */}
      <div className="grid grid-cols-4 sm:grid-cols-5 gap-3 sm:gap-4 mb-8">
        {tiles.map((tile) => (
          <Tile
            key={tile.id}
            id={tile.id}
            number={tile.number}
            isRevealed={tile.isRevealed}
            isMatched={tile.isMatched}
            onClick={handleTileClick}
            disabled={isChecking || isGameWon}
          />
        ))}
      </div>

      {/* Victory Message */}
      {isGameWon && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-8 rounded-2xl shadow-2xl text-center transform animate-bounce">
            <div className="flex justify-center mb-4">
              <Trophy className="text-yellow-500" size={64} />
            </div>
            <h2 className="text-3xl font-bold text-slate-800 mb-4">
              Yutdingiz! 🎉
            </h2>
            <p className="text-slate-600 mb-4">
              You completed the game in {moves} moves!
            </p>
            <button
              onClick={initializeGame}
              className="bg-green-500 hover:bg-green-600 text-white px-6 py-3 rounded-lg shadow-md transition-colors duration-200 font-semibold"
            >
              Play Again
            </button>
          </div>
        </div>
      )}

      {/* Confetti Animation */}
      {isGameWon && (
        <div className="fixed inset-0 pointer-events-none z-40">
          <div className="animate-pulse">
            {[...Array(20)].map((_, i) => (
              <div
                key={i}
                className="absolute w-3 h-3 bg-yellow-400 rounded-full animate-ping"
                style={{
                  left: `${Math.random() * 100}%`,
                  top: `${Math.random() * 100}%`,
                  animationDelay: `${Math.random() * 2}s`,
                  animationDuration: `${1 + Math.random() * 2}s`
                }}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default GameBoard;