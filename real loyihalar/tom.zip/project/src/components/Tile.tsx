import React from 'react';

interface TileProps {
  id: number;
  number: number;
  isRevealed: boolean;
  isMatched: boolean;
  onClick: (id: number) => void;
  disabled: boolean;
}

const Tile: React.FC<TileProps> = ({ 
  id, 
  number, 
  isRevealed, 
  isMatched, 
  onClick, 
  disabled 
}) => {
  const getNumberColor = (num: number): string => {
    const colors = [
      'bg-red-500', 'bg-blue-500', 'bg-green-500', 'bg-yellow-500', 'bg-purple-500',
      'bg-pink-500', 'bg-indigo-500', 'bg-teal-500', 'bg-orange-500', 'bg-cyan-500'
    ];
    return colors[num - 1] || 'bg-gray-500';
  };

  const handleClick = () => {
    if (!disabled && !isRevealed && !isMatched) {
      onClick(id);
    }
  };

  return (
    <div
      className={`
        relative w-16 h-16 sm:w-20 sm:h-20 rounded-xl cursor-pointer 
        transform transition-all duration-300 hover:scale-105
        ${disabled ? 'cursor-not-allowed' : ''}
        ${isMatched ? 'opacity-75 cursor-default' : ''}
      `}
      onClick={handleClick}
    >
      {/* Card Back */}
      <div
        className={`
          absolute inset-0 rounded-xl shadow-lg transition-all duration-500
          ${isRevealed || isMatched ? 'rotate-y-180 opacity-0' : 'rotate-y-0 opacity-100'}
          bg-gradient-to-br from-slate-300 to-slate-400 border-2 border-slate-200
          flex items-center justify-center
        `}
      >
        <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-slate-500 opacity-30"></div>
      </div>

      {/* Card Front */}
      <div
        className={`
          absolute inset-0 rounded-xl shadow-lg transition-all duration-500
          ${isRevealed || isMatched ? 'rotate-y-0 opacity-100' : 'rotate-y-180 opacity-0'}
          ${getNumberColor(number)} text-white border-2 border-white
          flex items-center justify-center font-bold text-xl sm:text-2xl
          ${isMatched ? 'ring-4 ring-yellow-400 ring-opacity-75' : ''}
        `}
      >
        {number}
      </div>
    </div>
  );
};

export default Tile;