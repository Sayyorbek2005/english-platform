import React from 'react'
import './Hero.css'
const Hero = () => {
  return (
    <div className='Hero'>
      
    </div>
  )
}
export default Hero