import React, { useState } from "react";
import "./App.css";

const studentsData = [
  {
    id: 1,
    name: "Allamurodov Foziljon",
    phone: "(50) 020-91-81",
    attendance: [
      "Was", "Was", "Was", "Was", "Was", "Was", "Not", "Was", "Was", "Was", "Was", "Was", "Was", "Was"
    ],
  },
  {
    id: 2,
    name: "Ismoilov Sayyor",
    phone: "(93) 339-99-23",
    attendance: Array(14).fill("Was"),
  },
  {
    id: 3,
    name: "Mahmudjonov Lazizjon",
    phone: "(97) 395-26-52",
    attendance: Array(14).fill("Was"),
  },
  {
    id: 4,
    name: "Muhammadiyev Ibrohim",
    phone: "(99) 592-88-50",
    attendance: Array(14).fill("Was"),
  },
  {
    id: 5,
    name: "Sulaymonov Muhammadjon",
    phone: "(93) 354-24-52",
    attendance: Array(14).fill("Was"),
  },
];

const dates = [
  "2 aug", "5 aug", "7 aug", "9 aug", "12 aug", "14 aug", "16 aug",
  "19 aug", "21 aug", "23 aug", "26 aug", "28 aug", "30 aug"
];

export default function FrontendFevral() {
  const [attendanceData, setAttendanceData] = useState(studentsData);

  // Attendance toggle funksiyasi, "Was" <-> "Not"
  const toggleAttendance = (studentId, index) => {
    setAttendanceData(prevData =>
      prevData.map(student => {
        if (student.id === studentId) {
          const newAttendance = [...student.attendance];
          newAttendance[index] = newAttendance[index] === "Was" ? "Not" : "Was";
          return { ...student, attendance: newAttendance };
        }
        return student;
      })
    );
  };

  return (
    <div className="container">
      <aside className="sidebar">
        <div className="logo">
          <img src="/logo.png" alt="IT TAT Logo" />
        </div>
        <nav>
          <ul>
            <li className="active">Dekabr 16:00</li>
            <li className="active">Frontend Fevral 14:00</li>
            <li>Frontend Mart 16:00</li>
            <li>Salary</li>
          </ul>
        </nav>
      </aside>

      <main className="main-content">
        <header className="header">
          <h1>Frontend Fevral 14:00 · Frontend · Sayyorbek Xoliqov</h1>
          <div className="user-profile">
            <span>Sayyorbek Xoliqov</span>
            <img className="profile-pic" src="/profile.png" alt="User" />
          </div>
        </header>

        <section className="info-section">
          <div className="course-info">
            <p><b>Course:</b> Frontend</p>
            <p><b>Teacher:</b> Sayyorbek Xoliqov</p>
            <p><b>Price:</b> 690 000 UZS</p>
            <p><b>Time:</b> Even days · 14:00</p>
            <p><b>Rooms:</b> Room #1</p>
            <p><b>Room capacity:</b></p>
            <p><b>Training dates:</b> 15.02.2025 — 20.09.2025</p>
            <p><b>Branches:</b> <span className="branch-tag">IT TAT</span></p>

            <div className="student-list">
              <label>By A-Z</label>
              <ol>
                {attendanceData.map(student => (
                  <li key={student.id} className={student.id === 1 ? "highlight" : ""}>
                    <span className="status-dot"></span> <b>{student.name}</b> <span>{student.phone}</span>
                  </li>
                ))}
              </ol>
            </div>

            <textarea placeholder="Note" className="note-box"></textarea>
          </div>

          <div className="attendance-section">
            <div className="tabs">
              <button className="active">Attendance</button>
              <button>Online lessons and materials</button>
              <button>Exams</button>
            </div>

            <table>
              <thead>
                <tr>
                  <th>Name</th>
                  {dates.map(date => (
                    <th key={date}>{date}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {attendanceData.map(student => (
                  <tr key={student.id}>
                    <td>{student.name}</td>
                    {student.attendance.map((status, idx) => (
                      <td key={idx}>
                        <button
                          className={`status-btn ${status.toLowerCase()}`}
                          onClick={() => toggleAttendance(student.id, idx)}
                        >
                          {status}
                        </button>
                      </td>
                    ))}
                    <td><input type="checkbox" /></td>
                  </tr>
                ))}
              </tbody>
            </table>

            <div className="pagination">
              <button>{"<<"}</button>
              <button>{"<"}</button>
              <button className="current">Current</button>
              <button>{">"}</button>
              <button>{">>"}</button>
            </div>
          </div>
        </section>

        <footer>
          <p>Support | Documentation</p>
          <p>modme</p>
        </footer>
      </main>
    </div>
  );
}
