import './Modal.css'

function Modal({ show, message }) {
  if (!show) return null

  return (
    <div className="modal-overlay">
      <div className="modal">
        <div className="modal-content">
          <div className="success-icon">✓</div>
          <p className="modal-message">{message}</p>
        </div>
      </div>
    </div>
  )
}

export default Modal