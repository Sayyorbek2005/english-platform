import { useState } from 'react'
import ContactForm from './ContactForm'
import './Header.css'

function Header({ onAddContact }) {
  const [showForm, setShowForm] = useState(false)

  const handleToggleForm = () => {
    setShowForm(prev => !prev)
  }

  const handleContactAdded = (contact) => {
    onAddContact(contact)
    setShowForm(false)
  }

  return (
    <header className="header">
      <div className="header-container">
        <div className="header-content">
          <h1 className="header-title">Contact Manager</h1>
          <button 
            className="add-button"
            onClick={handleToggleForm}
          >
            {showForm ? '✕ Cancel' : '+ Add'}
          </button>
        </div>
        
        {showForm && (
          <div className="form-container">
            <ContactForm 
              onSubmit={handleContactAdded}
              onCancel={handleToggleForm}
            />
          </div>
        )}
      </div>
    </header>
  )
}

export default Header