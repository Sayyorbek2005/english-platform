import ContactTable from './ContactTable'
import './Hero.css'

function Hero({ contacts }) {
  return (
    <section className="hero">
      <div className="hero-container">
        <div className="hero-content">
          <h2 className="hero-title">Your Contacts</h2>
          <p className="hero-subtitle">
            Manage your contact list with ease
          </p>
          
          <ContactTable contacts={contacts} />
        </div>
      </div>
    </section>
  )
}

export default Hero