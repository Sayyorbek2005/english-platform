import { useState } from 'react'
import Header from './components/Header'
import Hero from './components/Hero'
import Modal from './components/Modal'
import './App.css'

function App() {
  const [contacts, setContacts] = useState([
    { id: 1, firstName: 'John', lastName: 'Doe', phoneNumber: '(555) 123-4567' },
    { id: 2, firstName: 'Jane', lastName: 'Smith', phoneNumber: '(555) 987-6543' },
    { id: 3, firstName: 'Mike', lastName: 'Johnson', phoneNumber: '(555) 456-7890' }
  ])
  const [showModal, setShowModal] = useState(false)

  const addContact = (contact) => {
    const newContact = {
      ...contact,
      id: Date.now()
    }
    setContacts(prev => [...prev, newContact])
    setShowModal(true)
    
    // Auto-hide modal after 3 seconds
    setTimeout(() => {
      setShowModal(false)
    }, 3000)
  }

  return (
    <div className="app">
      <Header onAddContact={addContact} />
      <Hero contacts={contacts} />
      <Modal show={showModal} message="Added!" />
    </div>
  )
}

export default App