import React, { useState, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import ProductGrid from '../../components/ProductGrid/ProductGrid';
import Filters from '../../components/Filters/Filters';
import { products } from '../../data/products';
import './Home.css';

function Home() {
  const [searchParams] = useSearchParams();
  const searchQuery = searchParams.get('search') || '';
  
  const [filters, setFilters] = useState({
    categories: [],
    brands: [],
    priceRange: null
  });

  const [sortBy, setSortBy] = useState('popularity');

  const handleFilterChange = (type, value) => {
    setFilters(prev => {
      if (type === 'categories' || type === 'brands') {
        const currentValues = prev[type] || [];
        const newValues = currentValues.includes(value)
          ? currentValues.filter(item => item !== value)
          : [...currentValues, value];
        return { ...prev, [type]: newValues };
      } else if (type === 'priceRange') {
        return { ...prev, [type]: value };
      }
      return prev;
    });
  };

  const filteredProducts = useMemo(() => {
    let result = [...products];

    // Search filter
    if (searchQuery) {
      result = result.filter(product =>
        product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.brand.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Category filter
    if (filters.categories.length > 0) {
      result = result.filter(product => 
        filters.categories.includes(product.category)
      );
    }

    // Brand filter
    if (filters.brands.length > 0) {
      result = result.filter(product => 
        filters.brands.includes(product.brand)
      );
    }

    // Price filter
    if (filters.priceRange) {
      result = result.filter(product =>
        product.price >= filters.priceRange.min && 
        product.price <= filters.priceRange.max
      );
    }

    // Sort
    switch (sortBy) {
      case 'price-low':
        result.sort((a, b) => a.price - b.price);
        break;
      case 'price-high':
        result.sort((a, b) => b.price - a.price);
        break;
      case 'rating':
        result.sort((a, b) => b.rating - a.rating);
        break;
      case 'discount':
        result.sort((a, b) => b.discount - a.discount);
        break;
      default:
        // popularity - keep original order
        break;
    }

    return result;
  }, [searchQuery, filters, sortBy]);

  return (
    <div className="home">
      <div className="container">
        <div className="home-content">
          <aside className="sidebar">
            <Filters 
              onFilterChange={handleFilterChange}
              activeFilters={filters}
            />
          </aside>

          <main className="main-content">
            <div className="catalog-header">
              <div className="catalog-title">
                {searchQuery ? (
                  <h1>Результаты поиска: "{searchQuery}"</h1>
                ) : (
                  <h1>Каталог товаров</h1>
                )}
                <span className="results-count">{filteredProducts.length} товаров</span>
              </div>

              <div className="sort-controls">
                <label htmlFor="sort" className="sort-label">Сортировка:</label>
                <select 
                  id="sort"
                  value={sortBy} 
                  onChange={(e) => setSortBy(e.target.value)}
                  className="sort-select"
                >
                  <option value="popularity">По популярности</option>
                  <option value="price-low">Цена: по возрастанию</option>
                  <option value="price-high">Цена: по убыванию</option>
                  <option value="rating">По рейтингу</option>
                  <option value="discount">По размеру скидки</option>
                </select>
              </div>
            </div>

            <Filters 
              onFilterChange={handleFilterChange}
              activeFilters={filters}
            />

            {filteredProducts.length > 0 ? (
              <ProductGrid products={filteredProducts} />
            ) : (
              <div className="no-results">
                <h3>Товары не найдены</h3>
                <p>Попробуйте изменить параметры поиска или фильтры</p>
              </div>
            )}
          </main>
        </div>
      </div>
    </div>
  );
}

export default Home;