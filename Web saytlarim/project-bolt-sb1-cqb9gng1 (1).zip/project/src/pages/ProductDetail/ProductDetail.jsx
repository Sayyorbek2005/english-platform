import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Heart, Star, ShoppingCart, ArrowLeft } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { products } from '../../data/products';
import './ProductDetail.css';

function ProductDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { state, dispatch } = useApp();
  
  const product = products.find(p => p.id === parseInt(id));
  const [selectedImage, setSelectedImage] = useState(0);
  const [selectedColor, setSelectedColor] = useState(product?.colors[0] || '');
  const [selectedSize, setSelectedSize] = useState(product?.sizes[0] || '');
  const [quantity, setQuantity] = useState(1);

  if (!product) {
    return (
      <div className="container">
        <div className="product-not-found">
          <h2>Товар не найден</h2>
          <button onClick={() => navigate('/')} className="back-btn">
            Вернуться к каталогу
          </button>
        </div>
      </div>
    );
  }

  const isFavorite = state.favorites.some(fav => fav.id === product.id);

  const handleFavoriteClick = () => {
    if (isFavorite) {
      dispatch({ type: 'REMOVE_FROM_FAVORITES', payload: product.id });
    } else {
      dispatch({ type: 'ADD_TO_FAVORITES', payload: product });
    }
  };

  const handleAddToCart = () => {
    const cartItem = {
      ...product,
      selectedColor,
      selectedSize,
      quantity,
      cartId: `${product.id}-${selectedColor}-${selectedSize}-${Date.now()}`
    };
    dispatch({ type: 'ADD_TO_CART', payload: cartItem });
  };

  const formatPrice = (price) => {
    return new Intl.NumberFormat('ru-RU').format(price);
  };

  return (
    <div className="product-detail">
      <div className="container">
        <button className="back-button" onClick={() => navigate(-1)}>
          <ArrowLeft size={20} />
          Назад
        </button>

        <div className="product-detail-content">
          <div className="product-images">
            <div className="main-image">
              <img 
                src={product.images[selectedImage]} 
                alt={product.name}
                className="main-product-image"
              />
              <button 
                className={`favorite-btn-large ${isFavorite ? 'favorite-active' : ''}`}
                onClick={handleFavoriteClick}
              >
                <Heart size={24} fill={isFavorite ? '#CB11AB' : 'none'} />
              </button>
            </div>
            
            {product.images.length > 1 && (
              <div className="image-thumbnails">
                {product.images.map((image, index) => (
                  <button
                    key={index}
                    className={`thumbnail ${selectedImage === index ? 'active' : ''}`}
                    onClick={() => setSelectedImage(index)}
                  >
                    <img src={image} alt={`${product.name} ${index + 1}`} />
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className="product-info-detail">
            <div className="product-header">
              <div className="product-brand-detail">{product.brand}</div>
              <h1 className="product-name-detail">{product.name}</h1>
              
              <div className="product-rating-detail">
                <div className="rating-stars">
                  <Star size={16} fill="#FFD700" color="#FFD700" />
                  <span className="rating-value">{product.rating}</span>
                </div>
                <span className="reviews-link">({product.reviews} отзывов)</span>
              </div>
            </div>

            <div className="product-price-detail">
              <div className="current-price-detail">{formatPrice(product.price)} ₽</div>
              {product.originalPrice > product.price && (
                <div className="price-info">
                  <span className="original-price-detail">{formatPrice(product.originalPrice)} ₽</span>
                  <span className="discount-detail">-{product.discount}%</span>
                </div>
              )}
            </div>

            <div className="product-options">
              <div className="option-group">
                <label className="option-label">Цвет:</label>
                <div className="color-options">
                  {product.colors.map(color => (
                    <button
                      key={color}
                      className={`color-option ${selectedColor === color ? 'selected' : ''}`}
                      onClick={() => setSelectedColor(color)}
                      style={{ backgroundColor: color === 'beige' ? '#F5F5DC' : color }}
                      title={color}
                    />
                  ))}
                </div>
              </div>

              <div className="option-group">
                <label className="option-label">Размер:</label>
                <div className="size-options">
                  {product.sizes.map(size => (
                    <button
                      key={size}
                      className={`size-option ${selectedSize === size ? 'selected' : ''}`}
                      onClick={() => setSelectedSize(size)}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>

              <div className="option-group">
                <label className="option-label">Количество:</label>
                <div className="quantity-controls">
                  <button 
                    className="quantity-btn"
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  >
                    -
                  </button>
                  <span className="quantity-value">{quantity}</span>
                  <button 
                    className="quantity-btn"
                    onClick={() => setQuantity(quantity + 1)}
                  >
                    +
                  </button>
                </div>
              </div>
            </div>

            <div className="product-actions">
              <button className="add-to-cart-btn" onClick={handleAddToCart}>
                <ShoppingCart size={20} />
                Добавить в корзину
              </button>
            </div>

            <div className="product-description">
              <h3>Описание товара</h3>
              <p>Высококачественный товар от бренда {product.brand}. Отличное качество материалов и современный дизайн. Подходит для повседневной носки и особых случаев.</p>
              
              <div className="product-features">
                <div className="feature">
                  <strong>Категория:</strong> {product.category}
                </div>
                <div className="feature">
                  <strong>Бренд:</strong> {product.brand}
                </div>
                <div className="feature">
                  <strong>Доступные цвета:</strong> {product.colors.join(', ')}
                </div>
                <div className="feature">
                  <strong>Доступные размеры:</strong> {product.sizes.join(', ')}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ProductDetail;