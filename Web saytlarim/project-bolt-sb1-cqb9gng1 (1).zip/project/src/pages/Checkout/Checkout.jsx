import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Check } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import './Checkout.css';

function Checkout() {
  const { state, dispatch } = useApp();
  const navigate = useNavigate();
  const [showThankYou, setShowThankYou] = useState(false);
  
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    address: '',
    deliveryMethod: 'pickup',
    paymentMethod: 'card'
  });

  const [errors, setErrors] = useState({});

  const formatPrice = (price) => {
    return new Intl.NumberFormat('ru-RU').format(price);
  };

  const totalPrice = state.cart.reduce((total, item) => total + (item.price * item.quantity), 0);
  const totalItems = state.cart.reduce((total, item) => total + item.quantity, 0);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.name.trim()) {
      newErrors.name = 'Укажите ваше имя';
    }

    if (!formData.phone.trim()) {
      newErrors.phone = 'Укажите номер телефона';
    } else if (!/^[\+]?[0-9\s\-\(\)]{10,}$/.test(formData.phone)) {
      newErrors.phone = 'Некорректный номер телефона';
    }

    if (formData.deliveryMethod === 'delivery' && !formData.address.trim()) {
      newErrors.address = 'Укажите адрес доставки';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (validateForm()) {
      setShowThankYou(true);
      // Clear cart after successful order
      setTimeout(() => {
        dispatch({ type: 'CLEAR_CART' });
        navigate('/');
      }, 3000);
    }
  };

  if (state.cart.length === 0) {
    navigate('/cart');
    return null;
  }

  return (
    <div className="checkout-page">
      <div className="container">
        <button className="back-button" onClick={() => navigate('/cart')}>
          <ArrowLeft size={20} />
          Вернуться в корзину
        </button>

        <div className="checkout-header">
          <h1>Оформление заказа</h1>
        </div>

        <div className="checkout-content">
          <form className="checkout-form" onSubmit={handleSubmit}>
            <div className="form-section">
              <h3>Контактная информация</h3>
              
              <div className="form-group">
                <label htmlFor="name">Имя и фамилия *</label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  className={errors.name ? 'error' : ''}
                  placeholder="Введите ваше имя"
                />
                {errors.name && <span className="error-message">{errors.name}</span>}
              </div>

              <div className="form-group">
                <label htmlFor="phone">Номер телефона *</label>
                <input
                  type="tel"
                  id="phone"
                  name="phone"
                  value={formData.phone}
                  onChange={handleInputChange}
                  className={errors.phone ? 'error' : ''}
                  placeholder="+7 (900) 123-45-67"
                />
                {errors.phone && <span className="error-message">{errors.phone}</span>}
              </div>

              <div className="form-group">
                <label htmlFor="email">Email</label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  placeholder="example@mail.ru"
                />
              </div>
            </div>

            <div className="form-section">
              <h3>Способ доставки</h3>
              
              <div className="radio-group">
                <label className="radio-option">
                  <input
                    type="radio"
                    name="deliveryMethod"
                    value="pickup"
                    checked={formData.deliveryMethod === 'pickup'}
                    onChange={handleInputChange}
                  />
                  <div className="radio-info">
                    <span className="radio-title">Самовывоз из пункта выдачи</span>
                    <span className="radio-subtitle">Бесплатно • 1-3 дня</span>
                  </div>
                </label>

                <label className="radio-option">
                  <input
                    type="radio"
                    name="deliveryMethod"
                    value="delivery"
                    checked={formData.deliveryMethod === 'delivery'}
                    onChange={handleInputChange}
                  />
                  <div className="radio-info">
                    <span className="radio-title">Доставка курьером</span>
                    <span className="radio-subtitle">300 ₽ • 1-2 дня</span>
                  </div>
                </label>
              </div>

              {formData.deliveryMethod === 'delivery' && (
                <div className="form-group">
                  <label htmlFor="address">Адрес доставки *</label>
                  <input
                    type="text"
                    id="address"
                    name="address"
                    value={formData.address}
                    onChange={handleInputChange}
                    className={errors.address ? 'error' : ''}
                    placeholder="Улица, дом, квартира"
                  />
                  {errors.address && <span className="error-message">{errors.address}</span>}
                </div>
              )}
            </div>

            <div className="form-section">
              <h3>Способ оплаты</h3>
              
              <div className="radio-group">
                <label className="radio-option">
                  <input
                    type="radio"
                    name="paymentMethod"
                    value="card"
                    checked={formData.paymentMethod === 'card'}
                    onChange={handleInputChange}
                  />
                  <div className="radio-info">
                    <span className="radio-title">Банковской картой</span>
                    <span className="radio-subtitle">Visa, MasterCard, МИР</span>
                  </div>
                </label>

                <label className="radio-option">
                  <input
                    type="radio"
                    name="paymentMethod"
                    value="cash"
                    checked={formData.paymentMethod === 'cash'}
                    onChange={handleInputChange}
                  />
                  <div className="radio-info">
                    <span className="radio-title">Наличными при получении</span>
                    <span className="radio-subtitle">Только для самовывоза</span>
                  </div>
                </label>
              </div>
            </div>

            <button type="submit" className="submit-order-btn">
              Оформить заказ на {formatPrice(totalPrice)} ₽
            </button>
          </form>

          <div className="order-summary">
            <div className="summary-card">
              <h3>Ваш заказ</h3>
              
              <div className="order-items">
                {state.cart.map(item => (
                  <div key={item.cartId} className="order-item">
                    <img src={item.images[0]} alt={item.name} className="order-item-image" />
                    <div className="order-item-info">
                      <div className="order-item-name">{item.name}</div>
                      <div className="order-item-details">
                        {item.selectedColor} • {item.selectedSize} • {item.quantity} шт.
                      </div>
                      <div className="order-item-price">
                        {formatPrice(item.price * item.quantity)} ₽
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="order-total">
                <div className="total-row">
                  <span>Товары ({totalItems})</span>
                  <span>{formatPrice(totalPrice)} ₽</span>
                </div>
                <div className="total-row">
                  <span>Доставка</span>
                  <span className="free-delivery">
                    {formData.deliveryMethod === 'delivery' ? '300 ₽' : 'Бесплатно'}
                  </span>
                </div>
                <div className="total-final">
                  <span>Итого</span>
                  <span>
                    {formatPrice(totalPrice + (formData.deliveryMethod === 'delivery' ? 300 : 0))} ₽
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {showThankYou && (
        <div className="thank-you-modal">
          <div className="thank-you-content">
            <div className="success-icon">
              <Check size={48} />
            </div>
            <h2>Спасибо за покупку!</h2>
            <p>Ваш заказ принят в обработку</p>
            <p>Мы свяжемся с вами в ближайшее время</p>
            <div className="thank-you-actions">
              <button 
                className="continue-btn"
                onClick={() => {
                  setShowThankYou(false);
                  navigate('/');
                }}
              >
                Продолжить покупки
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default Checkout;