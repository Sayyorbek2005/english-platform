import React from 'react';
import { Link } from 'react-router-dom';
import { Heart } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import ProductGrid from '../../components/ProductGrid/ProductGrid';
import './Favorites.css';

function Favorites() {
  const { state } = useApp();

  if (state.favorites.length === 0) {
    return (
      <div className="favorites-page">
        <div className="container">
          <div className="empty-favorites">
            <Heart size={64} color="#ccc" />
            <h2>Список избранного пуст</h2>
            <p>Добавляйте товары в избранное, нажимая на сердечко</p>
            <Link to="/" className="continue-shopping-btn">
              Перейти к покупкам
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="favorites-page">
      <div className="container">
        <div className="favorites-header">
          <h1>Избранное</h1>
          <span className="favorites-count">{state.favorites.length} товаров</span>
        </div>

        <ProductGrid products={state.favorites} />
      </div>
    </div>
  );
}

export default Favorites;