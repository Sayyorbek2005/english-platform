import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Trash2, Plus, Minus, ShoppingCart } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import './Cart.css';

function Cart() {
  const { state, dispatch } = useApp();
  const navigate = useNavigate();

  const updateQuantity = (cartId, newQuantity) => {
    if (newQuantity <= 0) {
      dispatch({ type: 'REMOVE_FROM_CART', payload: cartId });
    } else {
      dispatch({ type: 'UPDATE_CART_QUANTITY', payload: { cartId, quantity: newQuantity } });
    }
  };

  const removeItem = (cartId) => {
    dispatch({ type: 'REMOVE_FROM_CART', payload: cartId });
  };

  const formatPrice = (price) => {
    return new Intl.NumberFormat('ru-RU').format(price);
  };

  const totalPrice = state.cart.reduce((total, item) => total + (item.price * item.quantity), 0);
  const totalItems = state.cart.reduce((total, item) => total + item.quantity, 0);

  const handleCheckout = () => {
    navigate('/checkout');
  };

  if (state.cart.length === 0) {
    return (
      <div className="cart-page">
        <div className="container">
          <div className="empty-cart">
            <ShoppingCart size={64} color="#ccc" />
            <h2>Ваша корзина пуста</h2>
            <p>Добавьте товары в корзину, чтобы оформить заказ</p>
            <Link to="/" className="continue-shopping-btn">
              Перейти к покупкам
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="cart-page">
      <div className="container">
        <div className="cart-header">
          <h1>Корзина</h1>
          <span className="cart-count">{totalItems} товаров</span>
        </div>

        <div className="cart-content">
          <div className="cart-items">
            {state.cart.map(item => (
              <div key={item.cartId} className="cart-item">
                <Link to={`/product/${item.id}`} className="cart-item-image">
                  <img src={item.images[0]} alt={item.name} />
                </Link>

                <div className="cart-item-info">
                  <Link to={`/product/${item.id}`} className="cart-item-link">
                    <div className="cart-item-brand">{item.brand}</div>
                    <div className="cart-item-name">{item.name}</div>
                  </Link>
                  
                  <div className="cart-item-options">
                    <span>Цвет: {item.selectedColor}</span>
                    <span>Размер: {item.selectedSize}</span>
                  </div>

                  <div className="cart-item-controls">
                    <div className="quantity-controls">
                      <button 
                        className="quantity-btn"
                        onClick={() => updateQuantity(item.cartId, item.quantity - 1)}
                      >
                        <Minus size={16} />
                      </button>
                      <span className="quantity-value">{item.quantity}</span>
                      <button 
                        className="quantity-btn"
                        onClick={() => updateQuantity(item.cartId, item.quantity + 1)}
                      >
                        <Plus size={16} />
                      </button>
                    </div>

                    <button 
                      className="remove-btn"
                      onClick={() => removeItem(item.cartId)}
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>

                <div className="cart-item-price">
                  <div className="item-total-price">
                    {formatPrice(item.price * item.quantity)} ₽
                  </div>
                  <div className="item-unit-price">
                    {formatPrice(item.price)} ₽ за шт.
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="cart-summary">
            <div className="summary-card">
              <h3>Итого</h3>
              
              <div className="summary-row">
                <span>Товары ({totalItems})</span>
                <span>{formatPrice(totalPrice)} ₽</span>
              </div>
              
              <div className="summary-row">
                <span>Доставка</span>
                <span className="free-delivery">Бесплатно</span>
              </div>
              
              <div className="summary-total">
                <span>К оплате</span>
                <span>{formatPrice(totalPrice)} ₽</span>
              </div>

              <button className="checkout-btn" onClick={handleCheckout}>
                Оформить заказ
              </button>

              <div className="delivery-info">
                <p>🚚 Бесплатная доставка от 1 000 ₽</p>
                <p>📦 Доставка в пункт выдачи 1-3 дня</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Cart;