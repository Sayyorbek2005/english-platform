import React from 'react';
import { Link } from 'react-router-dom';
import { Heart, Star } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import './ProductCard.css';

function ProductCard({ product }) {
  const { state, dispatch } = useApp();
  const isFavorite = state.favorites.some(fav => fav.id === product.id);

  const handleFavoriteClick = (e) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (isFavorite) {
      dispatch({ type: 'REMOVE_FROM_FAVORITES', payload: product.id });
    } else {
      dispatch({ type: 'ADD_TO_FAVORITES', payload: product });
    }
  };

  const formatPrice = (price) => {
    return new Intl.NumberFormat('ru-RU').format(price);
  };

  return (
    <div className="product-card">
      <Link to={`/product/${product.id}`} className="product-link">
        <div className="product-image-container">
          <img 
            src={product.images[0]} 
            alt={product.name}
            className="product-image"
          />
          <button 
            className={`favorite-btn ${isFavorite ? 'favorite-active' : ''}`}
            onClick={handleFavoriteClick}
          >
            <Heart size={20} fill={isFavorite ? '#CB11AB' : 'none'} />
          </button>
          {product.discount > 0 && (
            <div className="discount-badge">-{product.discount}%</div>
          )}
        </div>
        
        <div className="product-info">
          <div className="product-brand">{product.brand}</div>
          <div className="product-name">{product.name}</div>
          
          <div className="product-rating">
            <Star size={14} fill="#FFD700" color="#FFD700" />
            <span className="rating-value">{product.rating}</span>
            <span className="reviews-count">({product.reviews})</span>
          </div>
          
          <div className="product-colors">
            {product.colors.slice(0, 3).map((color, index) => (
              <div 
                key={index}
                className="color-dot"
                style={{ backgroundColor: color === 'beige' ? '#F5F5DC' : color }}
                title={color}
              />
            ))}
            {product.colors.length > 3 && (
              <span className="more-colors">+{product.colors.length - 3}</span>
            )}
          </div>
          
          <div className="product-price">
            <span className="current-price">{formatPrice(product.price)} ₽</span>
            {product.originalPrice > product.price && (
              <span className="original-price">{formatPrice(product.originalPrice)} ₽</span>
            )}
          </div>
        </div>
      </Link>
    </div>
  );
}

export default ProductCard;