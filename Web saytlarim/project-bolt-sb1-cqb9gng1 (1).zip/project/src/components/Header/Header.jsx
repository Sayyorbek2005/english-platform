import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Search, Heart, ShoppingCart, User, Menu, X } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import './Header.css';

function Header() {
  const { state } = useApp();
  const [searchQuery, setSearchQuery] = useState('');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const navigate = useNavigate();

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/?search=${encodeURIComponent(searchQuery)}`);
      setIsMobileMenuOpen(false);
    }
  };

  const cartItemsCount = state.cart.reduce((total, item) => total + item.quantity, 0);
  const favoritesCount = state.favorites.length;

  return (
    <header className="header">
      <div className="header-top">
        <div className="container">
          <div className="header-top-content">
            <div className="header-links">
              <a href="#" className="header-link">Покупателям</a>
              <a href="#" className="header-link">Продавцам</a>
              <a href="#" className="header-link">Пункты выдачи</a>
            </div>
            <div className="header-auth">
              <User size={16} />
              <span>Войти</span>
            </div>
          </div>
        </div>
      </div>

      <div className="header-main">
        <div className="container">
          <div className="header-main-content">
            <button 
              className="mobile-menu-btn"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>

            <Link to="/" className="logo">
              <img src="https://static-basket-01.wb.ru/vol0/i/v5/header/logo-wildberries.svg" alt="Wildberries" />
            </Link>

            <form className="search-form" onSubmit={handleSearch}>
              <input
                type="text"
                placeholder="Найти на Wildberries"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="search-input"
              />
              <button type="submit" className="search-btn">
                <Search size={20} />
              </button>
            </form>

            <div className="header-actions">
              <Link to="/favorites" className="header-action">
                <Heart size={24} />
                {favoritesCount > 0 && <span className="badge">{favoritesCount}</span>}
                <span className="action-label">Избранное</span>
              </Link>
              <Link to="/cart" className="header-action">
                <ShoppingCart size={24} />
                {cartItemsCount > 0 && <span className="badge">{cartItemsCount}</span>}
                <span className="action-label">Корзина</span>
              </Link>
            </div>
          </div>
        </div>
      </div>

      {isMobileMenuOpen && (
        <div className="mobile-menu">
          <div className="mobile-menu-content">
            <form className="mobile-search-form" onSubmit={handleSearch}>
              <input
                type="text"
                placeholder="Найти на Wildberries"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="mobile-search-input"
              />
              <button type="submit" className="mobile-search-btn">
                <Search size={20} />
              </button>
            </form>
            
            <div className="mobile-nav">
              <Link to="/favorites" className="mobile-nav-item" onClick={() => setIsMobileMenuOpen(false)}>
                <Heart size={20} />
                <span>Избранное {favoritesCount > 0 && `(${favoritesCount})`}</span>
              </Link>
              <Link to="/cart" className="mobile-nav-item" onClick={() => setIsMobileMenuOpen(false)}>
                <ShoppingCart size={20} />
                <span>Корзина {cartItemsCount > 0 && `(${cartItemsCount})`}</span>
              </Link>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}

export default Header;