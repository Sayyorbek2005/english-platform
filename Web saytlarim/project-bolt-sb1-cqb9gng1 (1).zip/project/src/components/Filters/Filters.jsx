import React, { useState } from 'react';
import { ChevronDown, Filter } from 'lucide-react';
import './Filters.css';

function Filters({ onFilterChange, activeFilters = {} }) {
  const [showMobileFilters, setShowMobileFilters] = useState(false);
  const [expandedSections, setExpandedSections] = useState({
    category: true,
    price: true,
    brand: true
  });

  const categories = [
    'Женская одежда',
    'Мужская одежда',
    'Обувь',
    'Аксессуары',
    'Украшения'
  ];

  const brands = [
    'ZARA', 'H&M', 'Nike', 'Adidas', 'Mango', 'Uniqlo', 'Levi\'s'
  ];

  const priceRanges = [
    { label: 'До 1 000 ₽', min: 0, max: 1000 },
    { label: '1 000 - 3 000 ₽', min: 1000, max: 3000 },
    { label: '3 000 - 10 000 ₽', min: 3000, max: 10000 },
    { label: 'От 10 000 ₽', min: 10000, max: Infinity }
  ];

  const toggleSection = (section) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };

  const handleFilterChange = (type, value) => {
    onFilterChange(type, value);
  };

  const FilterContent = () => (
    <div className="filters-content">
      <div className="filter-section">
        <button 
          className="filter-section-header"
          onClick={() => toggleSection('category')}
        >
          <span>Категория</span>
          <ChevronDown className={expandedSections.category ? 'expanded' : ''} size={16} />
        </button>
        {expandedSections.category && (
          <div className="filter-options">
            {categories.map(category => (
              <label key={category} className="filter-option">
                <input
                  type="checkbox"
                  checked={activeFilters.categories?.includes(category) || false}
                  onChange={(e) => handleFilterChange('categories', category)}
                />
                <span>{category}</span>
              </label>
            ))}
          </div>
        )}
      </div>

      <div className="filter-section">
        <button 
          className="filter-section-header"
          onClick={() => toggleSection('price')}
        >
          <span>Цена</span>
          <ChevronDown className={expandedSections.price ? 'expanded' : ''} size={16} />
        </button>
        {expandedSections.price && (
          <div className="filter-options">
            {priceRanges.map((range, index) => (
              <label key={index} className="filter-option">
                <input
                  type="radio"
                  name="priceRange"
                  checked={activeFilters.priceRange?.min === range.min && activeFilters.priceRange?.max === range.max}
                  onChange={() => handleFilterChange('priceRange', range)}
                />
                <span>{range.label}</span>
              </label>
            ))}
          </div>
        )}
      </div>

      <div className="filter-section">
        <button 
          className="filter-section-header"
          onClick={() => toggleSection('brand')}
        >
          <span>Бренд</span>
          <ChevronDown className={expandedSections.brand ? 'expanded' : ''} size={16} />
        </button>
        {expandedSections.brand && (
          <div className="filter-options">
            {brands.map(brand => (
              <label key={brand} className="filter-option">
                <input
                  type="checkbox"
                  checked={activeFilters.brands?.includes(brand) || false}
                  onChange={() => handleFilterChange('brands', brand)}
                />
                <span>{brand}</span>
              </label>
            ))}
          </div>
        )}
      </div>
    </div>
  );

  return (
    <>
      <div className="filters-desktop">
        <FilterContent />
      </div>

      <div className="filters-mobile">
        <button 
          className="mobile-filters-btn"
          onClick={() => setShowMobileFilters(true)}
        >
          <Filter size={16} />
          Фильтры
        </button>

        {showMobileFilters && (
          <div className="mobile-filters-overlay">
            <div className="mobile-filters-modal">
              <div className="mobile-filters-header">
                <h3>Фильтры</h3>
                <button 
                  className="close-btn"
                  onClick={() => setShowMobileFilters(false)}
                >
                  ×
                </button>
              </div>
              <FilterContent />
              <div className="mobile-filters-footer">
                <button 
                  className="apply-filters-btn"
                  onClick={() => setShowMobileFilters(false)}
                >
                  Применить
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </>
  );
}

export default Filters;