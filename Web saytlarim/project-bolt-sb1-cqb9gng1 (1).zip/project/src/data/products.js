export const products = [
  {
    id: 1,
    name: "Платье женское летнее",
    brand: "ZARA",
    price: 2990,
    originalPrice: 3990,
    discount: 25,
    rating: 4.5,
    reviews: 128,
    colors: ["black", "white", "red"],
    sizes: ["XS", "S", "M", "L", "XL"],
    images: [
      "https://images.pexels.com/photos/1926769/pexels-photo-1926769.jpeg?auto=compress&cs=tinysrgb&w=400",
      "https://images.pexels.com/photos/1040945/pexels-photo-1040945.jpeg?auto=compress&cs=tinysrgb&w=400"
    ],
    category: "Женская одежда"
  },
  {
    id: 2,
    name: "Кроссовки мужские спортивные",
    brand: "Nike",
    price: 8990,
    originalPrice: 12990,
    discount: 31,
    rating: 4.8,
    reviews: 245,
    colors: ["white", "black", "blue"],
    sizes: ["40", "41", "42", "43", "44", "45"],
    images: [
      "https://images.pexels.com/photos/2529148/pexels-photo-2529148.jpeg?auto=compress&cs=tinysrgb&w=400",
      "https://images.pexels.com/photos/1464625/pexels-photo-1464625.jpeg?auto=compress&cs=tinysrgb&w=400"
    ],
    category: "Обувь"
  },
  {
    id: 3,
    name: "Сумка женская кожаная",
    brand: "Michael Kors",
    price: 15990,
    originalPrice: 19990,
    discount: 20,
    rating: 4.6,
    reviews: 89,
    colors: ["brown", "black", "beige"],
    sizes: ["One Size"],
    images: [
      "https://images.pexels.com/photos/1152077/pexels-photo-1152077.jpeg?auto=compress&cs=tinysrgb&w=400",
      "https://images.pexels.com/photos/1464625/pexels-photo-1464625.jpeg?auto=compress&cs=tinysrgb&w=400"
    ],
    category: "Аксессуары"
  },
  {
    id: 4,
    name: "Джинсы мужские классические",
    brand: "Levi's",
    price: 5990,
    originalPrice: 7990,
    discount: 25,
    rating: 4.3,
    reviews: 156,
    colors: ["blue", "black", "gray"],
    sizes: ["30", "32", "34", "36", "38", "40"],
    images: [
      "https://images.pexels.com/photos/1598507/pexels-photo-1598507.jpeg?auto=compress&cs=tinysrgb&w=400",
      "https://images.pexels.com/photos/1598505/pexels-photo-1598505.jpeg?auto=compress&cs=tinysrgb&w=400"
    ],
    category: "Мужская одежда"
  },
  {
    id: 5,
    name: "Блузка женская шелковая",
    brand: "H&M",
    price: 1990,
    originalPrice: 2990,
    discount: 33,
    rating: 4.2,
    reviews: 73,
    colors: ["white", "pink", "blue"],
    sizes: ["XS", "S", "M", "L"],
    images: [
      "https://images.pexels.com/photos/1043474/pexels-photo-1043474.jpeg?auto=compress&cs=tinysrgb&w=400",
      "https://images.pexels.com/photos/1040945/pexels-photo-1040945.jpeg?auto=compress&cs=tinysrgb&w=400"
    ],
    category: "Женская одежда"
  },
  {
    id: 6,
    name: "Куртка мужская зимняя",
    brand: "Columbia",
    price: 12990,
    originalPrice: 16990,
    discount: 24,
    rating: 4.7,
    reviews: 198,
    colors: ["black", "navy", "gray"],
    sizes: ["S", "M", "L", "XL", "XXL"],
    images: [
      "https://images.pexels.com/photos/1183266/pexels-photo-1183266.jpeg?auto=compress&cs=tinysrgb&w=400",
      "https://images.pexels.com/photos/1040427/pexels-photo-1040427.jpeg?auto=compress&cs=tinysrgb&w=400"
    ],
    category: "Мужская одежда"
  },
  {
    id: 7,
    name: "Туфли женские на каблуке",
    brand: "Zara",
    price: 4990,
    originalPrice: 6990,
    discount: 29,
    rating: 4.4,
    reviews: 112,
    colors: ["black", "nude", "red"],
    sizes: ["35", "36", "37", "38", "39", "40"],
    images: [
      "https://images.pexels.com/photos/1478442/pexels-photo-1478442.jpeg?auto=compress&cs=tinysrgb&w=400",
      "https://images.pexels.com/photos/1464625/pexels-photo-1464625.jpeg?auto=compress&cs=tinysrgb&w=400"
    ],
    category: "Обувь"
  },
  {
    id: 8,
    name: "Рюкзак городской молодежный",
    brand: "Herschel",
    price: 3990,
    originalPrice: 4990,
    discount: 20,
    rating: 4.6,
    reviews: 84,
    colors: ["black", "gray", "navy"],
    sizes: ["One Size"],
    images: [
      "https://images.pexels.com/photos/2905238/pexels-photo-2905238.jpeg?auto=compress&cs=tinysrgb&w=400",
      "https://images.pexels.com/photos/1464625/pexels-photo-1464625.jpeg?auto=compress&cs=tinysrgb&w=400"
    ],
    category: "Аксессуары"
  },
  {
    id: 9,
    name: "Свитер женский вязаный",
    brand: "Mango",
    price: 3490,
    originalPrice: 4490,
    discount: 22,
    rating: 4.3,
    reviews: 96,
    colors: ["beige", "pink", "gray"],
    sizes: ["XS", "S", "M", "L"],
    images: [
      "https://images.pexels.com/photos/1040945/pexels-photo-1040945.jpeg?auto=compress&cs=tinysrgb&w=400",
      "https://images.pexels.com/photos/1043474/pexels-photo-1043474.jpeg?auto=compress&cs=tinysrgb&w=400"
    ],
    category: "Женская одежда"
  },
  {
    id: 10,
    name: "Рубашка мужская деловая",
    brand: "Hugo Boss",
    price: 6990,
    originalPrice: 8990,
    discount: 22,
    rating: 4.5,
    reviews: 134,
    colors: ["white", "blue", "gray"],
    sizes: ["S", "M", "L", "XL"],
    images: [
      "https://images.pexels.com/photos/1043474/pexels-photo-1043474.jpeg?auto=compress&cs=tinysrgb&w=400",
      "https://images.pexels.com/photos/1040427/pexels-photo-1040427.jpeg?auto=compress&cs=tinysrgb&w=400"
    ],
    category: "Мужская одежда"
  },
  {
    id: 11,
    name: "Часы женские наручные",
    brand: "Casio",
    price: 4490,
    originalPrice: 5990,
    discount: 25,
    rating: 4.7,
    reviews: 67,
    colors: ["gold", "silver", "rose-gold"],
    sizes: ["One Size"],
    images: [
      "https://images.pexels.com/photos/1464625/pexels-photo-1464625.jpeg?auto=compress&cs=tinysrgb&w=400",
      "https://images.pexels.com/photos/1152077/pexels-photo-1152077.jpeg?auto=compress&cs=tinysrgb&w=400"
    ],
    category: "Аксессуары"
  },
  {
    id: 12,
    name: "Юбка женская мини",
    brand: "Bershka",
    price: 1490,
    originalPrice: 1990,
    discount: 25,
    rating: 4.1,
    reviews: 45,
    colors: ["black", "white", "red"],
    sizes: ["XS", "S", "M", "L"],
    images: [
      "https://images.pexels.com/photos/1926769/pexels-photo-1926769.jpeg?auto=compress&cs=tinysrgb&w=400",
      "https://images.pexels.com/photos/1040945/pexels-photo-1040945.jpeg?auto=compress&cs=tinysrgb&w=400"
    ],
    category: "Женская одежда"
  },
  {
    id: 13,
    name: "Кепка мужская спортивная",
    brand: "Adidas",
    price: 1990,
    originalPrice: 2490,
    discount: 20,
    rating: 4.4,
    reviews: 92,
    colors: ["black", "white", "navy"],
    sizes: ["One Size"],
    images: [
      "https://images.pexels.com/photos/1464625/pexels-photo-1464625.jpeg?auto=compress&cs=tinysrgb&w=400",
      "https://images.pexels.com/photos/2529148/pexels-photo-2529148.jpeg?auto=compress&cs=tinysrgb&w=400"
    ],
    category: "Аксессуары"
  },
  {
    id: 14,
    name: "Платье вечернее длинное",
    brand: "Mango",
    price: 7990,
    originalPrice: 9990,
    discount: 20,
    rating: 4.8,
    reviews: 156,
    colors: ["black", "navy", "burgundy"],
    sizes: ["XS", "S", "M", "L"],
    images: [
      "https://images.pexels.com/photos/1926769/pexels-photo-1926769.jpeg?auto=compress&cs=tinysrgb&w=400",
      "https://images.pexels.com/photos/1040945/pexels-photo-1040945.jpeg?auto=compress&cs=tinysrgb&w=400"
    ],
    category: "Женская одежда"
  },
  {
    id: 15,
    name: "Ботинки мужские кожаные",
    brand: "Timberland",
    price: 11990,
    originalPrice: 14990,
    discount: 20,
    rating: 4.6,
    reviews: 203,
    colors: ["brown", "black", "tan"],
    sizes: ["40", "41", "42", "43", "44", "45"],
    images: [
      "https://images.pexels.com/photos/1464625/pexels-photo-1464625.jpeg?auto=compress&cs=tinysrgb&w=400",
      "https://images.pexels.com/photos/2529148/pexels-photo-2529148.jpeg?auto=compress&cs=tinysrgb&w=400"
    ],
    category: "Обувь"
  },
  {
    id: 16,
    name: "Джемпер женский кашемировый",
    brand: "Uniqlo",
    price: 4990,
    originalPrice: 6490,
    discount: 23,
    rating: 4.7,
    reviews: 178,
    colors: ["gray", "pink", "white"],
    sizes: ["XS", "S", "M", "L", "XL"],
    images: [
      "https://images.pexels.com/photos/1043474/pexels-photo-1043474.jpeg?auto=compress&cs=tinysrgb&w=400",
      "https://images.pexels.com/photos/1040945/pexels-photo-1040945.jpeg?auto=compress&cs=tinysrgb&w=400"
    ],
    category: "Женская одежда"
  },
  {
    id: 17,
    name: "Шорты мужские джинсовые",
    brand: "Pull & Bear",
    price: 1790,
    originalPrice: 2290,
    discount: 22,
    rating: 4.2,
    reviews: 67,
    colors: ["blue", "black", "gray"],
    sizes: ["S", "M", "L", "XL"],
    images: [
      "https://images.pexels.com/photos/1598507/pexels-photo-1598507.jpeg?auto=compress&cs=tinysrgb&w=400",
      "https://images.pexels.com/photos/1598505/pexels-photo-1598505.jpeg?auto=compress&cs=tinysrgb&w=400"
    ],
    category: "Мужская одежда"
  },
  {
    id: 18,
    name: "Кольцо серебряное женское",
    brand: "Pandora",
    price: 3490,
    originalPrice: 4490,
    discount: 22,
    rating: 4.9,
    reviews: 234,
    colors: ["silver", "gold"],
    sizes: ["16", "17", "18", "19", "20"],
    images: [
      "https://images.pexels.com/photos/1152077/pexels-photo-1152077.jpeg?auto=compress&cs=tinysrgb&w=400",
      "https://images.pexels.com/photos/1464625/pexels-photo-1464625.jpeg?auto=compress&cs=tinysrgb&w=400"
    ],
    category: "Украшения"
  },
  {
    id: 19,
    name: "Футболка мужская базовая",
    brand: "H&M",
    price: 799,
    originalPrice: 999,
    discount: 20,
    rating: 4.1,
    reviews: 312,
    colors: ["white", "black", "gray", "navy"],
    sizes: ["S", "M", "L", "XL", "XXL"],
    images: [
      "https://images.pexels.com/photos/1043474/pexels-photo-1043474.jpeg?auto=compress&cs=tinysrgb&w=400",
      "https://images.pexels.com/photos/1040427/pexels-photo-1040427.jpeg?auto=compress&cs=tinysrgb&w=400"
    ],
    category: "Мужская одежда"
  },
  {
    id: 20,
    name: "Пальто женское демисезонное",
    brand: "Max Mara",
    price: 24990,
    originalPrice: 32990,
    discount: 24,
    rating: 4.8,
    reviews: 89,
    colors: ["beige", "black", "navy"],
    sizes: ["XS", "S", "M", "L"],
    images: [
      "https://images.pexels.com/photos/1926769/pexels-photo-1926769.jpeg?auto=compress&cs=tinysrgb&w=400",
      "https://images.pexels.com/photos/1040945/pexels-photo-1040945.jpeg?auto=compress&cs=tinysrgb&w=400"
    ],
    category: "Женская одежда"
  }
];