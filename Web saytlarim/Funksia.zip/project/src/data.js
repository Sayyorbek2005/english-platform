// Real Madrid players data
export const playersData = [
  {
    id: 1,
    firstName: "Karim",
    lastName: "Benzema",
    image: "https://images.pexels.com/photos/1884574/pexels-photo-1884574.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop",
    info: [
      "Tug‘ilgan sanasi: 1987-yil 19-dekabr",
      "Tug‘ilgan joyi: Lion, Fransiya",
      "Pozitsiyasi: Markaziy hujumchi"
    ]
  },
  {
    id: 2,
    firstName: "Luka",
    lastName: "Modric",
    image: "https://images.pexels.com/photos/1884581/pexels-photo-1884581.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop",
    info: [
      "Tug‘ilgan sanasi: 1985-yil 9-sentabr",
      "Tug‘ilgan joyi: Zadar, Yugoslaviya (hozirgi Xorvatiya)",
      "Pozitsiyasi: Markaziy yarim himoyachi (regista, playmaker)"
    ]
  },
  {
    id: 3,
    firstName: "Vinicius",
    lastName: "Junior",
    image: "https://images.pexels.com/photos/1884577/pexels-photo-1884577.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop",
    info: [
      "Tug‘ilgan sanasi: 2000-yil 12-iyul",
      "Tug‘ilgan joyi: São Gonçalo, Rio-de-Janeyro, Braziliya",
      "Pozitsiyasi: Chap qanot hujumchisi (vinger)"
    ]
  },
  {
    id: 4,
    firstName: "Jude",
    lastName: "Bellingham",
    image: "https://images.pexels.com/photos/1884582/pexels-photo-1884582.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop",
    info: [
      "Tug‘ilgan sanasi: 2003-yil 29-iyun",
      "Tug‘ilgan joyi: Stourbridge, Angliya",
      "Pozitsiyasi: Markaziy yarim himoyachi / Huqumkor yarim himoyachi"
    ]
  },
  {
    id: 5,
    firstName: "Thibaut",
    lastName: "Courtois",
    image: "https://images.pexels.com/photos/1884583/pexels-photo-1884583.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop",
    info: [
      "Tug‘ilgan sanasi: 1992-yil 11-may",
      "Tug‘ilgan joyi: Bree, Belgiya",
      "Pozitsiyasi: Darvozabon (goalkeeper)"
    ]
  }
];