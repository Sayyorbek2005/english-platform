import React, { useState } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import { playersData } from './data';
import './App.css';

function App() {
  const [showForm, setShowForm] = useState(false);
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [addedPlayers, setAddedPlayers] = useState([]);
  const [message, setMessage] = useState('');

  const handleAddPlayerClick = () => {
    setShowForm(!showForm);
    setMessage('');
    setFirstName('');
    setLastName('');
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
   
    const foundPlayer = playersData.find(
      player => 
        player.firstName.toLowerCase() === firstName.toLowerCase() && 
        player.lastName.toLowerCase() === lastName.toLowerCase()
    );

    if (foundPlayer) {
     
      const isAlreadyAdded = addedPlayers.some(player => player.id === foundPlayer.id);
      
      if (isAlreadyAdded) {
        setMessage('Tanla!');
      } else {
        setAddedPlayers(prev => [...prev, foundPlayer]);
        setMessage('Norm!');
      }
    } else {
      setMessage('Futbolchi nexxuya chiqmadi boshqa tanla');
    }

    
    setFirstName('');
    setLastName('');
  };

  return (
    <div className="app">
      <Header 
        onAddPlayerClick={handleAddPlayerClick} 
        showForm={showForm} 
      />
      <Hero 
        initialPlayers={playersData}
        addedPlayers={addedPlayers}
        showForm={showForm}
        onSubmit={handleSubmit}
        firstName={firstName}
        lastName={lastName}
        onFirstNameChange={(e) => setFirstName(e.target.value)}
        onLastNameChange={(e) => setLastName(e.target.value)}
        message={message}
      />
    </div>
  );
}

export default App;