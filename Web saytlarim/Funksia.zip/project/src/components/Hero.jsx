import React from 'react';

const PlayerCard = ({ player }) => {
  return (
    <div className="player-card">
      <img src={player.image} alt={`${player.firstName} ${player.lastName}`} className="player-image" />
      <div className="player-info">
        <h3 className="player-name">{player.firstName} {player.lastName}</h3>
        <ul className="player-details">
          {player.info.map((detail, index) => (
            <li key={index}>{detail}</li>
          ))}
        </ul>
      </div>
    </div>
  );
};

const AddPlayerForm = ({ onSubmit, firstName, lastName, onFirstNameChange, onLastNameChange }) => {
  return (
    <div className="add-player-form">
      <h3>Ism familia kirgiz</h3>
      <form onSubmit={onSubmit}>
        <input
          type="text"
          placeholder="First Name"
          value={firstName}
          onChange={onFirstNameChange}
          className="form-input"
          required
        />
        <input
          type="text"
          placeholder="Last Name"
          value={lastName}
          onChange={onLastNameChange}
          className="form-input"
          required
        />
        <button type="submit" className="submit-btn">Submit</button>
      </form>
    </div>
  );
};

const Hero = ({ initialPlayers, addedPlayers, showForm, onSubmit, firstName, lastName, onFirstNameChange, onLastNameChange,message }) => {
  return (
    <main className="hero">
      <div className="players-grid">
        {initialPlayers.map(player => (
          <PlayerCard key={player.id} player={player} />
        ))}
      </div>

      {showForm && (
        <AddPlayerForm
          onSubmit={onSubmit}
          firstName={firstName}
          lastName={lastName}
          onFirstNameChange={onFirstNameChange}
          onLastNameChange={onLastNameChange}
        />
      )}

      {message && (
        <div className="message">
          <p>{message}</p>
        </div>
      )}

      {addedPlayers.length > 0 && (
        <div className="added-players">
          <h3>Added Players</h3>
          <div className="players-grid">
            {addedPlayers.map(player => (
              <PlayerCard key={`added-${player.id}`} player={player} />
            ))}
          </div>
        </div>
      )}
    </main>
  );
};

export default Hero;