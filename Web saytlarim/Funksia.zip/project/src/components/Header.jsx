

const Header = ({onAddPlayerClick, showForm}) => {
  return (
    <header className="header">
      <h1 className="header-title">Real Madrid Yulduzlari</h1>
      <button 
        className="add-player-btn" 
        onClick={onAddPlayerClick}
      >
        {showForm ? 'Futbolchi tanla' : 'Tanlamading'}
      </button>
    </header>
  );
};

export default Header;