// import React from 'react'

// const servir = () => {
//   return (
//     <div className='servir'>
//       <h1>servir</h1>
//       <p>i blya</p>
//     </div>
//   )
// }

// export default servir
