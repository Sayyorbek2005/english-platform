// import React from 'react'

// const Home = () => {
//   return (
//     <div className='home'>
//       <h1>nima gap</h1>
//       <p>sedew</p>
      
//     </div>
//   )
// }

// export default Home
