// import React from 'react'

// const resume = () => {
//   return (
//     <div className='resume'>
//       <h1>resume</h1>
//       <p>xuyet qvosami bratishka</p>
//     </div>
//   )
// }

// export default resume
