// import React from 'react'

// const Work = () => {
//   return (
//     <div className='work'>
//       <h1>resume</h1>
//       <p>xaqiqatdan xuyet qilibsan lkn boru dnx bu yerdan</p>
//     </div>
//   )
// }

// export default Work
