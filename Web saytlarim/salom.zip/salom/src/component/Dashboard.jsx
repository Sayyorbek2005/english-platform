// import React from 'react'

// const Dashboard = () => {
//   return (
//     <div className='dashboard'>
//       <h1>Dashboard</h1>
//       <p>Naxxuy bu yerga utding </p>
      
//     </div>
//   )
// }

// export default Dashboard
