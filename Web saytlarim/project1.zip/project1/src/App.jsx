import { useState } from 'react'
import Header from './components/Header'
import Hero from './components/Hero'
import Modal from './components/Modal'
import './App.css'

function App() {
  const [contacts, setContacts] = useState([
    { id: 1, firstName: 'ibrohim', lastName: 'ibrohim', phoneNumber: '+998 99 837 23 33' },
    { id: 2, firstName: 'ibrohim', lastName: 'ibrohim', phoneNumber: '+998 99 837 23 33' },
    { id: 3, firstName: 'ibrohim', lastName: 'ibrohim', phoneNumber: '+998 99 837 23 33' }
  ])
  const [showModal, setShowModal] = useState(false)

  const addContact = (contact) => {
    const newContact = {
      ...contact,
      id: Date.now()
    }
    setContacts(prev => [...prev, newContact])
    setShowModal(true)
    
    // Auto-hide modal after 3 seconds
    setTimeout(() => {
      setShowModal(false)
    }, 3000)
  }

  return (
    <div className="app">
      <Header onAddContact={addContact} />
      <Hero contacts={contacts} />
      <Modal show={showModal} message="Added!" />
    </div>
  )
}

export default App