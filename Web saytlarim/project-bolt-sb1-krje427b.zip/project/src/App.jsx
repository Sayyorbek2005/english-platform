import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import HomePage from './components/HomePage';
import './App.css';
import { useState } from 'react';

function App() {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  const toggleSidebar = () => {
    setSidebarCollapsed(!sidebarCollapsed);
  };

  return (
    <Router>
      <div className="app">
        <Header onMenuClick={toggleSidebar} />
        <div className="app-body">
          <Sidebar collapsed={sidebarCollapsed} />
          <main className={`main-content ${sidebarCollapsed ? 'sidebar-collapsed' : ''}`}>
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/shorts" element={<div className="page-placeholder">Shorts Page</div>} />
              <Route path="/subscriptions" element={<div className="page-placeholder">Subscriptions Page</div>} />
              <Route path="/library" element={<div className="page-placeholder">Library Page</div>} />
            </Routes>
          </main>
        </div>
      </div>
    </Router>
  );
}

export default App;