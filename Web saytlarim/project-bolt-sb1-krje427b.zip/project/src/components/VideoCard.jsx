import './VideoCard.css';

const VideoCard = ({ video }) => {
  const handleVideoClick = () => {
    console.log('Video clicked:', video.title);
  };

  return (
    <div className="video-card" onClick={handleVideoClick}>
      <div className="video-thumbnail-container">
        <img
          src={video.thumbnail}
          alt={video.title}
          className="video-thumbnail"
          loading="lazy"
        />
        <div className="video-duration">10:24</div>
      </div>
      
      <div className="video-info">
        <div className="channel-avatar">
          <img
            src={`https://images.pexels.com/photos/${Math.floor(Math.random() * 1000000)}/pexels-photo.jpeg?auto=compress&cs=tinysrgb&w=36&h=36&fit=crop&crop=face`}
            alt={video.channel}
            className="avatar-image"
            loading="lazy"
            onError={(e) => {
              e.target.src = 'https://images.pexels.com/photos/771742/pexels-photo-771742.jpeg?auto=compress&cs=tinysrgb&w=36&h=36&fit=crop&crop=face';
            }}
          />
        </div>
        
        <div className="video-details">
          <h3 className="video-title">{video.title}</h3>
          <div className="video-metadata">
            <p className="channel-name">{video.channel}</p>
            <div className="video-stats">
              <span>{video.views}</span>
              <span className="separator">•</span>
              <span>{video.posted}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VideoCard;