import { useState, useEffect } from 'react';
import VideoGrid from './VideoGrid';
import axios from 'axios';

const HomePage = () => {
  const [videos, setVideos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Mock API endpoint - replace with your actual API
  const fetchVideos = async () => {
    setLoading(true);
    setError(null);
    
    try {
      // Simulating API call with mock data
      // In production, replace this with: const response = await axios.get('/api/videos');
      await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate network delay
      
      const mockVideos = [
        {
          id: "1",
          title: "React Full Course 2025 - Complete Tutorial for Beginners",
          channel: "Code Academy",
          views: "1.2M views",
          posted: "2 days ago",
          thumbnail: "https://images.pexels.com/photos/11035380/pexels-photo-11035380.jpeg?auto=compress&cs=tinysrgb&w=320&h=180&fit=crop"
        },
        {
          id: "2",
          title: "Amazing Nature Documentary - Wildlife Photography",
          channel: "Nature World",
          views: "850K views",
          posted: "5 days ago",
          thumbnail: "https://images.pexels.com/photos/3408744/pexels-photo-3408744.jpeg?auto=compress&cs=tinysrgb&w=320&h=180&fit=crop"
        },
        {
          id: "3",
          title: "Best Cooking Tips for Beginners - Master Chef Secrets",
          channel: "Kitchen Masters",
          views: "2.1M views",
          posted: "1 week ago",
          thumbnail: "https://images.pexels.com/photos/1279330/pexels-photo-1279330.jpeg?auto=compress&cs=tinysrgb&w=320&h=180&fit=crop"
        },
        {
          id: "4",
          title: "Travel Vlog - Exploring Tokyo Streets and Culture",
          channel: "Adventure Time",
          views: "674K views",
          posted: "3 days ago",
          thumbnail: "https://images.pexels.com/photos/2506923/pexels-photo-2506923.jpeg?auto=compress&cs=tinysrgb&w=320&h=180&fit=crop"
        },
        {
          id: "5",
          title: "Ultimate Workout Routine - Build Muscle at Home",
          channel: "Fitness Pro",
          views: "1.8M views",
          posted: "1 day ago",
          thumbnail: "https://images.pexels.com/photos/416778/pexels-photo-416778.jpeg?auto=compress&cs=tinysrgb&w=320&h=180&fit=crop"
        },
        {
          id: "6",
          title: "Space Exploration - Mars Mission Documentary",
          channel: "Space Channel",
          views: "3.2M views",
          posted: "2 weeks ago",
          thumbnail: "https://images.pexels.com/photos/2159/flight-sky-earth-space.jpg?auto=compress&cs=tinysrgb&w=320&h=180&fit=crop"
        },
        {
          id: "7",
          title: "Modern Web Development - JavaScript ES2025 Features",
          channel: "Dev Community",
          views: "445K views",
          posted: "4 days ago",
          thumbnail: "https://images.pexels.com/photos/11035471/pexels-photo-11035471.jpeg?auto=compress&cs=tinysrgb&w=320&h=180&fit=crop"
        },
        {
          id: "8",
          title: "Relaxing Music for Study - 3 Hours of Ambient Sounds",
          channel: "Zen Sounds",
          views: "892K views",
          posted: "6 days ago",
          thumbnail: "https://images.pexels.com/photos/744318/pexels-photo-744318.jpeg?auto=compress&cs=tinysrgb&w=320&h=180&fit=crop"
        },
        {
          id: "9",
          title: "Car Review - Tesla Model S 2025 Test Drive",
          channel: "Auto Reviews",
          views: "1.5M views",
          posted: "3 days ago",
          thumbnail: "https://images.pexels.com/photos/3802510/pexels-photo-3802510.jpeg?auto=compress&cs=tinysrgb&w=320&h=180&fit=crop"
        },
        {
          id: "10",
          title: "DIY Home Renovation - Bedroom Makeover on Budget",
          channel: "Home Improvement",
          views: "720K views",
          posted: "1 week ago",
          thumbnail: "https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=320&h=180&fit=crop"
        },
        {
          id: "11",
          title: "Photography Tutorial - Portrait Lighting Techniques",
          channel: "Photo Pro",
          views: "534K views",
          posted: "5 days ago",
          thumbnail: "https://images.pexels.com/photos/1983032/pexels-photo-1983032.jpeg?auto=compress&cs=tinysrgb&w=320&h=180&fit=crop"
        },
        {
          id: "12",
          title: "Gaming Review - Best Games of 2025 So Far",
          channel: "Game Central",
          views: "2.8M views",
          posted: "2 days ago",
          thumbnail: "https://images.pexels.com/photos/3945313/pexels-photo-3945313.jpeg?auto=compress&cs=tinysrgb&w=320&h=180&fit=crop"
        }
      ];
      
      setVideos(mockVideos);
    } catch (err) {
      setError('Failed to fetch videos. Please try again later.');
      console.error('Error fetching videos:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchVideos();
  }, []);

  if (error) {
    return (
      <div className="error-container">
        <p>{error}</p>
        <button onClick={fetchVideos} className="retry-button">
          Try Again
        </button>
      </div>
    );
  }

  return (
    <div className="home-page">
      <VideoGrid videos={videos} loading={loading} />
    </div>
  );
};

export default HomePage;