import VideoCard from './VideoCard';
import './VideoGrid.css';

const VideoGrid = ({ videos, loading }) => {
  if (loading) {
    return (
      <div className="video-grid">
        {Array.from({ length: 12 }).map((_, index) => (
          <div key={index} className="video-card-skeleton">
            <div className="skeleton-thumbnail"></div>
            <div className="skeleton-content">
              <div className="skeleton-avatar"></div>
              <div className="skeleton-text">
                <div className="skeleton-title"></div>
                <div className="skeleton-channel"></div>
                <div className="skeleton-metadata"></div>
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="video-grid">
      {videos.map((video) => (
        <VideoCard key={video.id} video={video} />
      ))}
    </div>
  );
};

export default VideoGrid;