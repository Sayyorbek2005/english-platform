import { useState } from 'react';
import { FiMenu, FiSearch, FiMic } from 'react-icons/fi';
import { MdVideoCall, MdNotifications } from 'react-icons/md';
import './Header.css';

const Header = ({ onMenuClick }) => {
  const [searchQuery, setSearchQuery] = useState('');

  const handleSearch = (e) => {
    e.preventDefault();
    console.log('Searching for:', searchQuery);
  };

  return (
    <header className="header">
      <div className="header-left">
        <button className="menu-button" onClick={onMenuClick} aria-label="Toggle menu">
          <FiMenu size={20} />
        </button>
        <div className="logo">
          <div className="logo-icon">
            <div className="play-button"></div>
          </div>
          <span className="logo-text">YouTube</span>
        </div>
      </div>

      <div className="header-center">
        <form className="search-form" onSubmit={handleSearch}>
          <div className="search-container">
            <input
              type="text"
              placeholder="Search"
              className="search-input"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <button type="submit" className="search-button" aria-label="Search">
              <FiSearch size={20} />
            </button>
          </div>
          <button type="button" className="mic-button" aria-label="Search with voice">
            <FiMic size={20} />
          </button>
        </form>
      </div>

      <div className="header-right">
        <button className="header-icon-button" aria-label="Create">
          <MdVideoCall size={24} />
        </button>
        <button className="header-icon-button" aria-label="Notifications">
          <MdNotifications size={24} />
        </button>
        <button className="user-avatar" aria-label="Account menu">
          <img
            src="https://images.pexels.com/photos/771742/pexels-photo-771742.jpeg?auto=compress&cs=tinysrgb&w=32&h=32&fit=crop&crop=face"
            alt="User avatar"
            className="avatar-image"
          />
        </button>
      </div>
    </header>
  );
};

export default Header;