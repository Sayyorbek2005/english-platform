import { Link, useLocation } from 'react-router-dom';
import { 
  MdHome, 
  MdSlowMotionVideo, 
  MdSubscriptions, 
  MdVideoLibrary,
  MdHistory,
  MdWatchLater,
  MdThumbUp
} from 'react-icons/md';
import './Sidebar.css';

const Sidebar = ({ collapsed }) => {
  const location = useLocation();

  const menuItems = [
    { icon: MdHome, text: 'Home', path: '/' },
    { icon: MdSlowMotionVideo, text: 'Shorts', path: '/shorts' },
    { icon: MdSubscriptions, text: 'Subscriptions', path: '/subscriptions' },
  ];

  const libraryItems = [
    { icon: MdVideoLibrary, text: 'Library', path: '/library' },
    { icon: MdHistory, text: 'History', path: '/history' },
    { icon: MdWatchLater, text: 'Watch later', path: '/watch-later' },
    { icon: MdThumbUp, text: 'Liked videos', path: '/liked' },
  ];

  const isActive = (path) => location.pathname === path;

  return (
    <nav className={`sidebar ${collapsed ? 'collapsed' : ''}`}>
      <div className="sidebar-content">
        <div className="sidebar-section">
          {menuItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={`sidebar-item ${isActive(item.path) ? 'active' : ''}`}
            >
              <item.icon size={24} className="sidebar-icon" />
              <span className="sidebar-text">{item.text}</span>
            </Link>
          ))}
        </div>

        <div className="sidebar-divider"></div>

        <div className="sidebar-section">
          {libraryItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={`sidebar-item ${isActive(item.path) ? 'active' : ''}`}
            >
              <item.icon size={24} className="sidebar-icon" />
              <span className="sidebar-text">{item.text}</span>
            </Link>
          ))}
        </div>

        <div className="sidebar-divider"></div>

        <div className="sidebar-section">
          <div className="sidebar-header">
            <span className="sidebar-text">Subscriptions</span>
          </div>
          <div className="sidebar-item">
            <img
              src="https://images.pexels.com/photos/3184338/pexels-photo-3184338.jpeg?auto=compress&cs=tinysrgb&w=24&h=24&fit=crop&crop=face"
              alt="Channel"
              className="channel-avatar"
            />
            <span className="sidebar-text">Tech Reviewer</span>
          </div>
          <div className="sidebar-item">
            <img
              src="https://images.pexels.com/photos/1559486/pexels-photo-1559486.jpeg?auto=compress&cs=tinysrgb&w=24&h=24&fit=crop&crop=face"
              alt="Channel"
              className="channel-avatar"
            />
            <span className="sidebar-text">Nature World</span>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Sidebar;