import { useState } from 'react'
import './AttendanceTable.css'

const AttendanceTable = ({ students }) => {
  const dates = ['2 aug', '5 aug', '7 aug', '9 aug', '12 aug', '14 aug', '16 aug', '19 aug', '21 aug', '23 aug', '26 aug', '28 aug', '30 aug']
  
  const [attendance, setAttendance] = useState(() => {
    const initial = {}
    students.forEach(student => {
      initial[student.name] = {}
      dates.forEach(date => {
        initial[student.name][date] = 'was'
      })
    })
    return initial
  })

  const toggleAttendance = (studentName, date) => {
    setAttendance(prev => ({
      ...prev,
      [studentName]: {
        ...prev[studentName],
        [date]: prev[studentName][date] === 'was' ? 'not' : 'was'
      }
    }))
  }

  return (
    <div className="attendance-section">
      <div className="attendance-header">
        <div className="attendance-tabs">
          <div className="tab active">Attendance</div>
          <div className="tab">Online lessons and materials</div>
          <div className="tab">Exams</div>
        </div>
        <div className="attendance-controls">
          <button className="btn-current">Current</button>
          <button className="btn-nav">&lt;</button>
          <button className="btn-nav">&gt;</button>
          <span className="month-year">aug 2025</span>
          <button className="btn-nav">&lt;</button>
          <button className="btn-nav">&gt;</button>
          <button className="btn-coins"></button>
        </div>
      </div>

      <div className="attendance-table-container">
        <table className="attendance-table">
          <thead>
            <tr>
              <th className="student-header">Name</th>
              <th className="topic-header">Topic</th>
              {dates.map(date => (
                <th key={date} className="date-header">{date}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {students.map((student) => (
              <tr key={student.name}>
                <td className="student-cell">
                  <div className="student-info">
                    <div className="student-avatar">{student.name.charAt(0)}</div>
                    <span>{student.name}</span>
                  </div>
                </td>
                <td className="topic-cell"></td>
                {dates.map(date => (
                  <td key={date} className="attendance-cell">
                    <button
                      className={`attendance-btn ${attendance[student.name][date]}`}
                      onClick={() => toggleAttendance(student.name, date)}
                    >
                      {attendance[student.name][date] === 'was' ? 'Was' : 'Not'}
                    </button>
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

export default AttendanceTable