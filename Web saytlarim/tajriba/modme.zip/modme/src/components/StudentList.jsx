import './StudentList.css'

const StudentList = ({ students, title }) => {
  return (
    <div className="student-list-card">
      <h3 className="student-list-title">{title || 'By A-Z'}</h3>
      <div className="student-list">
        {students.map((student, index) => (
          <div key={index} className="student-item">
            <div className="student-info-left">
              <span className="student-bullet">▶</span>
              <span className="student-name">{student.name}</span>
            </div>
            <span className="student-phone">{student.phone}</span>
            <span className="student-menu">⋮</span>
          </div>
        ))}
      </div>
    </div>
  )
}

export default StudentList