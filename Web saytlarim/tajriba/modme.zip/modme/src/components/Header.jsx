import './Header.css'

const Header = () => {
  return (
    <header className="header">
      <div className="header-content">
        <div className="header-left">
          <select className="language-select">
            <option value="en">en</option>
            <option value="uz">uz</option>
            <option value="ru">ru</option>
          </select>
        </div>
        <div className="header-right">
          <span className="user-icon">🔔</span>
          <span className="user-name">Sayyorbek Xoliqov</span>
          <div className="user-avatar">S</div>
        </div>
      </div>
    </header>
  )
}

export default Header