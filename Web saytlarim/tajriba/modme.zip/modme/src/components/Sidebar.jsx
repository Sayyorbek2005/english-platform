import './Sidebar.css'

const Sidebar = ({ currentPage, setCurrentPage }) => {
  const menuItems = [
    { id: 'dekabr', label: 'Dekabr 16:00'},
    { id: 'fevral', label: 'Frontend Fevral 14:00'},
    { id: 'mart', label: 'Frontend Mart 16:00'},
    { id: 'salary', label: 'Salary'},
  ]

  return (
    <div className="sidebar">
      <div className="sidebar-logo">
        <div className="logo-icon">
          <div className="logo-circle">
            <span className="logo-text">IT TAT</span>
         
          </div>
        </div>
      </div>
      
      <nav className="sidebar-nav">
        {menuItems.map((item) => (
          <div
            key={item.id}
            className={`nav-item ${currentPage === item.id ? 'active' : ''}`}
            onClick={() => setCurrentPage(item.id)}
          >
            <div className="nav-icon">{item.icon}</div>
            <span className="nav-label">{item.label}</span>
          </div>
        ))}
      </nav>
      
      <div className="sidebar-footer">
        <div className="footer-item">
          <span></span>
          <span>Support</span>
        </div>
        <div className="footer-item">
          <span> </span>
          <span>Documentation</span>
        </div>
      </div>
    </div>
  )
}

export default Sidebar