export const dekabrStudents = [
  { name: 'Alimov Bekzod', phone: '(90) 123-45-67' },
  { name: 'Boboyev Jasur', phone: '(91) 234-56-78' },
  { name: 'Davronov Umid', phone: '(93) 345-67-89' },
  { name: 'Ergashev Nodir', phone: '(94) 456-78-90' },
  { name: 'Fayzullayev Akmal', phone: '(95) 567-89-01' },
  { name: 'G\'ulomov Sardor', phone: '(97) 678-90-12' },
]

export const fevralStudents = [
  { name: 'Ismoilov Sayyor', phone: '(98) 739-99-23' },
  { name: 'Mahmudjanov Lazizjon', phone: '(97) 395-26-52' },
  { name: 'Muhammadaliyev Ibrahim', phone: '(98) 592-68-20' },
  { name: 'Sulaymonov Muhammadjon', phone: '(93) 954-24-92' },
]

export const martStudents = [
  { name: 'Abdurasulov Islom', phone: '(90) 111-22-33' },
  { name: 'Akbarov Aliasqar', phone: '(91) 222-33-44' },
  { name: 'Attoyev Faridun', phone: '(93) 333-44-55' },
  { name: 'Gulomova Zilola', phone: '(94) 444-55-66' },
  { name: 'Raxmonov Saidalixon', phone: '(95) 555-66-77' },
  { name: 'Sadullayev Sanjar', phone: '(97) 666-77-88' },
]