import './SalaryPage.css'

const SalaryPage = () => {
  const groups = [
    {
      name: 'Frontend Mart 16:00',
      type: 'Frontend',
      dates: '13.03.2025 - 31.10.2025',
      schedule: 'Even days • 16:00',
      students: 8
    },
    {
      name: 'Frontend Fevral 14:00', 
      type: 'Frontend',
      dates: '15.02.2025 - 20.09.2025',
      schedule: 'Even days • 14:00',
      students: 8
    },
    {
      name: 'Dekabr 16:00',
      type: 'Frontend [1.5]',
      dates: '20.12.2024 - 20.08.2025',
      schedule: 'Odd days • 16:00',
      students: 8
    }
  ]

  const students = [
    { name: 'Sadullayev Sanjar', phone: '(97) 514-16-72' },
    { name: 'Abdurasulov Islom', phone: '(91) 549-48-46' },
    { name: 'Raxmonov Saidislom', phone: '(97) 525-50-02' },
    { name: 'Altozov Faridun', phone: '(99) 470-35-39' },
    { name: 'Altozov Abdusor', phone: '(99) 774-73-13' },
    { name: "G'ulomova Zilola", phone: '(93) 400-10-30' }
  ]

  return (
    <div className="salary-page">
      <div className="salary-header">
        <div className="course-breadcrumb">
          <span className="course-icon"></span>
          <h1 className="course-title">Sayyorbek Xoliqov</h1>
        </div>
      </div>

      <div className="salary-content">
        <div className="teacher-profile-section">
          <div className="profile-tabs">
            <div className="tab active">PROFILE</div>
            <div className="tab">History</div>
            <div className="tab">Salary</div>
          </div>

          <div className="teacher-profile-card">
            <div className="teacher-avatar-large">
              <div className="avatar-circle"></div>
            </div>
            <div className="teacher-details">
              <h2 className="teacher-name">Sayyorbek Xoliqov</h2>
              <div className="teacher-info-grid">
                <div className="info-item">
                  <span className="info-label">Id:</span>
                  <span className="info-value">125075#1</span>
                </div>
                <div className="info-item">
                  <span className="info-label">Phone:</span>
                  <span className="info-value">(97) 935-47-07</span>
                </div>
                <div className="info-item">
                  <span className="info-label">Birthday:</span>
                  <span className="info-value">2005-06-03</span>
                </div>
                <div className="info-item">
                  <span className="info-label">Roles:</span>
                </div>
              </div>
              <div className="teacher-roles">
                <span className="role-tag">Teacher</span>
              </div>
              <div className="teacher-branches">
                <span className="branch-label">Branches:</span>
                <span className="branch-tag">IT TAT</span>
              </div>
            </div>
          </div>
        </div>

        <div className="groups-section">
          <div className="groups-header">
            <h3 className="groups-title">Groups</h3>
          </div>
          
          <div className="groups-list">
            {groups.map((group, index) => (
              <div key={index} className="group-card">
                <div className="group-info">
                  <h4 className="group-name">{group.name}</h4>
                  <p className="group-type">{group.type}</p>
                  <p className="group-dates">{group.dates}</p>
                  <p className="group-schedule">{group.schedule}</p>
                </div>
                <div className="group-students">
                  <span className="students-count">{group.students}</span>
                </div>
              </div>
            ))}
          </div>

          <div className="salary-group-detail">
            <div className="group-detail-header">
              <h4 className="group-detail-title">Frontend Mart 16:00</h4>
              <span className="group-detail-subtitle">Frontend</span>
              <div className="group-detail-meta">
                <span>Room: Room #1</span>
                <span>Start: 16:00</span>
              </div>
            </div>

            <div className="group-students-list">
              {students.map((student, index) => (
                <div key={index} className="salary-student-item">
                  <span className="student-name">{student.name}</span>
                  <span className="student-phone">{student.phone}</span>
                </div>
              ))}
              <div className="go-to-group">
                <span>Go to group →</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default SalaryPage