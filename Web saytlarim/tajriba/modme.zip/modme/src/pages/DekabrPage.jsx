import StudentList from '../components/StudentList'
import AttendanceTable from '../components/AttendanceTable'
import { dekabrStudents } from '../data/students'
import './CoursePage.css'

const DekabrPage = () => {
  return (
    <div className="course-page">
      <div className="course-header">
        <div className="course-breadcrumb">
          <span className="course-icon"></span>
          <h1 className="course-title">Frontent 16:00 • Frontend • Sayyorbek Xoliqov</h1>
        </div>
        <div className="course-actions">
          <button className="btn-show-coins">Show coins</button>
          <button className="btn-hide-coins active">Hide coins</button>
        </div>
      </div>

      <div className="course-content">
        <div className="course-sidebar">
          <div className="course-info-card">
            <div className="course-info-row">
              <span className="info-label">Course:</span>
              <span className="info-value">Frontend</span>
            </div>
            <div className="course-info-row">
              <span className="info-label">Teacher:</span>
              <span className="info-value">Sayyorbek Xoliqov</span>
            </div>
            <div className="course-info-row">
              <span className="info-label">Price:</span>
              <span className="info-value">690,000 UZS</span>
            </div>
            <div className="course-info-row">
              <span className="info-label">Time:</span>
              <span className="info-value">Even days • 16:00</span>
            </div>
            <div className="course-info-row">
              <span className="info-label">Rooms:</span>
              <span className="info-value">Room #1</span>
            </div>
            <div className="course-info-row">
              <span className="info-label">Room capacity:</span>
              <span className="info-value"></span>
            </div>
            <div className="course-info-row">
              <span className="info-label">Training dates:</span>
              <span className="info-value">15.12.2025 — 20.09.2025</span>
            </div>
            <div className="course-info-row">
              <span className="info-label">Id:</span>
              <span className="info-value">128126</span>
            </div>
            <div className="course-info-row">
              <span className="info-label">Branches:</span>
              <span className="info-value tag">IT TAT</span>
            </div>
          </div>

          <StudentList students={dekabrStudents} title="By A-Z" />

          <div className="note-section">
            <div className="note-label">Note</div>
            <div className="note-content"></div>
          </div>
        </div>

        <div className="course-main">
          <AttendanceTable students={dekabrStudents} />
        </div>
      </div>
    </div>
  )
}

export default DekabrPage