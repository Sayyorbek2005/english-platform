import { useState } from 'react'
import Sidebar from './components/Sidebar'
import Header from './components/Header'
import DekabrPage from './pages/DekabrPage'
import FevralPage from './pages/FevralPage'
import MartPage from './pages/MartPage'
import SalaryPage from './pages/SalaryPage'
import './App.css'

function App() {
  const [currentPage, setCurrentPage] = useState('dekabr')

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'dekabr':
        return <DekabrPage />
      case 'fevral':
        return <FevralPage />
      case 'mart':
        return <MartPage />
      case 'salary':
        return <SalaryPage />
      default:
        return <FevralPage />
    }
  }

  return (
    <div className="app">
      <Sidebar currentPage={currentPage} setCurrentPage={setCurrentPage} />
      <div className="main-content">
        <Header />
        {renderCurrentPage()}
      </div>
    </div>
  )
}

export default App