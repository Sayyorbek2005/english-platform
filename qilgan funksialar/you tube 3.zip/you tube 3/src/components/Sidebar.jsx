import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { AiOutlineHome, AiOutlineLike } from 'react-icons/ai';
import { FaBolt, FaGamepad } from 'react-icons/fa';
import { MdSubscriptions, MdHistory, MdWatchLater, MdPlaylistPlay, MdLiveTv, MdSportsSoccer } from 'react-icons/md';
import { GiLipstick, GiMusicalNotes } from 'react-icons/gi';
import { BiNews } from 'react-icons/bi';
import { RiGraduationCapLine } from 'react-icons/ri';
import './Sidebar.css';

const Sidebar = ({ isCollapsed }) => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const location = useLocation();

  const mainItems = [
    { icon: AiOutlineHome, text: t('sidebar.home'), path: '/' },
    { icon: FaBolt, text: t('sidebar.shorts'), path: '/shorts' },
    { icon: MdSubscriptions, text: t('sidebar.subscriptions'), path: '/subscriptions' },
  ];

  const libraryItems = [
    { icon: MdHistory, text: t('sidebar.history'), path: '/library' },
    { icon: MdPlaylistPlay, text: t('sidebar.playlists'), path: '/library' },
    { icon: MdWatchLater, text: t('sidebar.watchLater'), path: '/library' },
    { icon: AiOutlineLike, text: t('sidebar.likedVideos'), path: '/library' },
  ];

  const exploreItems = [
    { icon: GiMusicalNotes, text: t('sidebar.music'), path: '/library' },
    { icon: MdLiveTv, text: t('sidebar.live'), path: '/library' },
    { icon: FaGamepad, text: t('sidebar.gaming'), path: '/library' },
    { icon: BiNews, text: t('sidebar.news'), path: '/library' },
    { icon: MdSportsSoccer, text: t('sidebar.sports'), path: '/library' },
    { icon: RiGraduationCapLine, text: t('sidebar.learning'), path: '/library' },
    { icon: GiLipstick, text: t('sidebar.fashionBeauty'), path: '/library' },
  ];

  const isActive = (path) => location.pathname === path;

  const renderItem = (item, index) => {
    const Icon = item.icon;
    return (
      <div
        key={index}
        className={`sidebar-item ${isActive(item.path) ? 'active' : ''}`}
        onClick={() => navigate(item.path)}
      >
        <Icon className="sidebar-icon" />
        {!isCollapsed && <span className="sidebar-text">{item.text}</span>}
      </div>
    );
  };

  return (
    <nav className={`sidebar ${isCollapsed ? 'collapsed' : ''}`}>
      <div className="sidebar-section">
        {mainItems.map(renderItem)}
      </div>

      {!isCollapsed && (
        <>
          <div className="sidebar-divider"></div>
          <div className="sidebar-section">
            <div className="sidebar-title">{t('sidebar.library')}</div>
            {libraryItems.map(renderItem)}
          </div>

          <div className="sidebar-divider"></div>
          <div className="sidebar-section">
            <div className="sidebar-title">Explore</div>
            {exploreItems.map(renderItem)}
          </div>
        </>
      )}
    </nav>
  );
};

export default Sidebar;