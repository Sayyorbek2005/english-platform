import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import './VideoCard.css';

const VideoCard = ({ video }) => {
  const navigate = useNavigate();
  const [isHovering, setIsHovering] = useState(false);
  const videoRef = useRef(null);
  const hoverTimeoutRef = useRef(null);

  const handleMouseEnter = () => {
    hoverTimeoutRef.current = setTimeout(() => {
      setIsHovering(true);
      if (videoRef.current) {
        videoRef.current.play().catch(() => {});
      }
    }, 1000);
  };

  const handleMouseLeave = () => {
    if (hoverTimeoutRef.current) {
      clearTimeout(hoverTimeoutRef.current);
    }
    setIsHovering(false);
    if (videoRef.current) {
      videoRef.current.pause();
      videoRef.current.currentTime = 0;
    }
  };

  const handleClick = () => {
    navigate(`/video/${video.id}`);
  };

  return (
    <div
      className="video-card"
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      onClick={handleClick}
    >
      <div className="video-thumbnail">
        {isHovering ? (
          <video
            ref={videoRef}
            src={video.videoUrl}
            muted
            loop
            className="video-preview"
          />
        ) : (
          <img src={video.thumbnail} alt={video.title} />
        )}
        <span className="video-duration">{video.duration}</span>
      </div>

      <div className="video-info">
        <div className="video-avatar">
          <img src={video.avatar} alt={video.channel} />
        </div>
        <div className="video-details">
          <h3 className="video-title">{video.title}</h3>
          <div className="video-metadata">
            <p className="video-channel">{video.channel}</p>
            <div className="video-stats">
              <span>{video.views} views</span>
              <span>•</span>
              <span>{video.uploadDate}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VideoCard;