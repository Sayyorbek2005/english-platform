import React from 'react';
import { useTranslation } from 'react-i18next';
import './Subscriptions.css';

const Subscriptions = () => {
  const { t } = useTranslation();

  return (
    <div className="subscriptions-container">
      <div className="subscriptions-content">
        <h1>{t('sidebar.subscriptions')}</h1>
        <p>This page is coming soon...</p>
      </div>
    </div>
  );
};

export default Subscriptions;