import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { AiOutlineLike, AiOutlineDislike } from 'react-icons/ai';
import axios from 'axios';
import './VideoPage.css';

const VideoPage = () => {
  const { id } = useParams();
  const { t } = useTranslation();
  const [video, setVideo] = useState(null);
  const [loading, setLoading] = useState(true);
  const [liked, setLiked] = useState(false);
  const [disliked, setDisliked] = useState(false);
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState('');

  useEffect(() => {
    const fetchVideo = async () => {
      try {
        const response = await axios.get('/src/api/videos.json');
        const foundVideo = response.data.find(v => v.id === parseInt(id));
        setVideo(foundVideo);
        
        const savedComments = localStorage.getItem(`comments_${id}`);
        if (savedComments) {
          setComments(JSON.parse(savedComments));
        }
      } catch (error) {
        console.error('Error fetching video:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchVideo();
  }, [id]);

  const handleLike = () => {
    setLiked(!liked);
    if (disliked) setDisliked(false);
  };

  const handleDislike = () => {
    setDisliked(!disliked);
    if (liked) setLiked(false);
  };

  const handleAddComment = (e) => {
    e.preventDefault();
    if (newComment.trim()) {
      const comment = {
        id: Date.now(),
        text: newComment,
        author: localStorage.getItem('userName') || 'Sayyor',
        timestamp: new Date().toISOString(),
        avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=150'
      };
      
      const updatedComments = [comment, ...comments];
      setComments(updatedComments);
      localStorage.setItem(`comments_${id}`, JSON.stringify(updatedComments));
      setNewComment('');
    }
  };

  const formatTime = (timestamp) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInHours = Math.floor((now - date) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return 'Just now';
    if (diffInHours < 24) return `${diffInHours} hours ago`;
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays} days ago`;
  };

  if (loading) {
    return (
      <div className="video-page">
        <div className="loading">Loading video...</div>
      </div>
    );
  }

  if (!video) {
    return (
      <div className="video-page">
        <div className="error">Video not found</div>
      </div>
    );
  }

  return (
    <div className="video-page">
      <div className="video-container">
        <div className="video-player-wrapper">
          <video
            src={video.videoUrl}
            controls
            autoPlay
            className="video-player"
          />
        </div>

        <div className="video-details">
          <h1 className="video-title">{video.title}</h1>
          
          <div className="video-metadata">
            <div className="video-stats">
              <span>{video.views} {t('video.views')} • {video.uploadDate}</span>
            </div>
            
            <div className="video-actions">
              <button
                className={`action-btn ${liked ? 'liked' : ''}`}
                onClick={handleLike}
              >
                <AiOutlineLike />
                <span>Like</span>
              </button>
              
              <button
                className={`action-btn ${disliked ? 'disliked' : ''}`}
                onClick={handleDislike}
              >
                <AiOutlineDislike />
                <span>Dislike</span>
              </button>
            </div>
          </div>

          <div className="channel-info">
            <div className="channel-avatar">
              <img src={video.avatar} alt={video.channel} />
            </div>
            <div className="channel-details">
              <h3>{video.channel}</h3>
              <p>1.2M subscribers</p>
            </div>
          </div>
        </div>

        <div className="comments-section">
          <h3 className="comments-title">{comments.length} {t('video.comments')}</h3>
          
          <form className="comment-form" onSubmit={handleAddComment}>
            <div className="comment-input-wrapper">
              <img
                src="https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=150"
                alt="Your avatar"
                className="comment-avatar"
              />
              <input
                type="text"
                placeholder={t('video.addComment')}
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                className="comment-input"
              />
            </div>
            {newComment.trim() && (
              <div className="comment-actions">
                <button type="button" onClick={() => setNewComment('')}>
                  Cancel
                </button>
                <button type="submit" className="post-button">
                  {t('video.post')}
                </button>
              </div>
            )}
          </form>

          <div className="comments-list">
            {comments.map((comment) => (
              <div key={comment.id} className="comment-item">
                <img
                  src={comment.avatar}
                  alt={comment.author}
                  className="comment-avatar"
                />
                <div className="comment-content">
                  <div className="comment-header">
                    <span className="comment-author">{comment.author}</span>
                    <span className="comment-time">{formatTime(comment.timestamp)}</span>
                  </div>
                  <p className="comment-text">{comment.text}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default VideoPage;