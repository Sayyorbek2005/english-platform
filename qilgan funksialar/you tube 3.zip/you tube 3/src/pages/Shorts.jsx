import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { AiOutlineLike, AiOutlineDislike } from 'react-icons/ai';
import axios from 'axios';
import './Shorts.css';

const Shorts = () => {
  const { t } = useTranslation();
  const [shorts, setShorts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [likedShorts, setLikedShorts] = useState(new Set());

  useEffect(() => {
    const fetchShorts = async () => {
      try {
        const response = await axios.get('/src/api/shorts.json');
        setShorts(response.data);
      } catch (error) {
        console.error('Error fetching shorts:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchShorts();
  }, []);

  const handleLike = (shortId) => {
    setLikedShorts(prev => {
      const newSet = new Set(prev);
      if (newSet.has(shortId)) {
        newSet.delete(shortId);
      } else {
        newSet.add(shortId);
      }
      return newSet;
    });
  };

  if (loading) {
    return (
      <div className="shorts-container">
        <div className="loading">Loading shorts...</div>
      </div>
    );
  }

  return (
    <div className="shorts-container">
      <div className="shorts-wrapper">
        {shorts.map((short) => (
          <div key={short.id} className="short-item">
            <div className="short-video-container">
              <video
                src={short.videoUrl}
                controls
                autoPlay
                muted
                loop
                className="short-video"
              />
              
              <div className="short-actions">
                <button
                  className={`action-button like-button ${likedShorts.has(short.id) ? 'liked' : ''}`}
                  onClick={() => handleLike(short.id)}
                >
                  <AiOutlineLike />
                  <span>{short.likes + (likedShorts.has(short.id) ? 1 : 0)}</span>
                </button>
                
                <button className="action-button">
                  <AiOutlineDislike />
                </button>
              </div>
            </div>
            
            <div className="short-info">
              <div className="short-channel">
                <img src={short.avatar} alt={short.channel} />
                <div className="channel-info">
                  <h4>{short.channel}</h4>
                  <p>{short.views} {t('video.views')}</p>
                </div>
              </div>
              <h3 className="short-title">{short.title}</h3>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Shorts;