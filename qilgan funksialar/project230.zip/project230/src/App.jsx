import './App.css';

import SearchFilter from './components/searchfilter/SearchFilter';




function App() {

  return (
    <div className="App">


  <SearchFilter />

    </div>
  );
}

export default App;
