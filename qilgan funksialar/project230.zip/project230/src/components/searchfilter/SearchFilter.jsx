import React, { useState } from 'react';
import './SearchFilter.css';

function SearchFilter() {
  const fruits = [
    { 
      name: 'Olma', 
      image: 'https://images.unsplash.com/photo-1568702846914-96b305d2aaeb?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8YXBwbGV8ZW58MHx8MHx8&auto=format&fit=crop&w=500&q=60',
      description: 'Olma - vitaminlarga boy meva, sogʻliq uchun juda foydali.'
    },
    { 
      name: 'Banan', 
      image: 'https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8NHx8YmFuYW5hfGVufDB8fDB8fA%3D%3D&auto=format&fit=crop&w=500&q=60',
      description: 'Banan - energiya manbai, potashga boy.'
    },
    { 
      name: 'Anor', 
      image: 'https://kreda.pro/upload/iblock/9be/1b51pm9ckae6c9ppko8tl0wy43o0z4h1.jpg',
      description: 'Anor - antioksidantlarga boy, yurak uchun foydali.'
    },
    { 
      name: 'Uzum', 
      image: 'https://i.pinimg.com/originals/7c/fe/14/7cfe148a450bbeac0ed2a7a496f83b58.jpg',
      description: 'Uzum - shirin va shifobaxsh meva, teri uchun yaxshi.'
    },
    { 
      name: 'Shaftoli', 
      image: 'https://main-cdn.sbermegamarket.ru/big2/hlr-system/-2/02/14/78/03/86/9/100026736790b5.jpg ',
      description: 'Shaftoli - yozgi shirin meva, A vitamini boyligi.'
    },
    { 
      name: 'Qulupnay', 
      image: 'https://images.unsplash.com/photo-1543528176-61b239494933?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8NHx8c3RyYXdiZXJyeXxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60',
      description: 'Qulupnay - antioxidantlar va C vitamini boyligi.'
    },
    { 
      name: 'Apelsin', 
      image: 'https://images.unsplash.com/photo-1547514701-42782101795e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8NHx8b3JhbmdlfGVufDB8fDB8fA%3D%3D&auto=format&fit=crop&w=500&q=60',
      description: 'Apelsin - C vitamini manbai, immunitetni mustahkamlaydi.'
    },
    { 
      name: 'Limon', 
      image: 'https://images.unsplash.com/photo-1590502593747-42a996133562?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8NHx8bGVtb258ZW58MHx8MHx8&auto=format&fit=crop&w=500&q=60',
      description: 'Limon - vitamin boyligi, detoksifikatsiya qiladi.'
    }
  ];
  
  const [search, setSearch] = useState('');

  const filteredItems = fruits.filter((fruit) =>
    fruit.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="search-filter-container">
      <div className="search-filter-card">
        <div className="search-header">
          <h2><i className="fas fa-search"></i> Mevalarni Qidirish</h2>
          <p>Sevimli mevangizni toping va uning foydali xususiyatlari haqida biling</p>
        </div>
        
        <div className="search-input-container">
          <i className="fas fa-search search-icon"></i>
          <input
            className="search-input"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Meva nomini yozing..."
          />
        </div>
        
        <div className="results-count">
          {filteredItems.length} ta meva topildi
        </div>
        
        <div className="fruits-container">
          {filteredItems.length > 0 ? (
            filteredItems.map((fruit, index) => (
              <div key={index} className="fruit-card">
                <div className="fruit-image">
                  <img src={fruit.image} alt={fruit.name} />
                  <div className="fruit-overlay">
                    <button className="view-button">Batafsil</button>
                  </div>
                </div>
                <div className="fruit-content">
                  <h3>{fruit.name}</h3>
                  <p>{fruit.description}</p>
                  <div className="fruit-actions">
                    <button className="like-btn">
                      <i className="far fa-heart"></i>
                    </button>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="no-results">
              <i className="fas fa-search fa-3x"></i>
              <h3>Hech narsa topilmadi</h3>
              <p>Boshqa so'zlar bilan qayta urunib ko'ring</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default SearchFilter;