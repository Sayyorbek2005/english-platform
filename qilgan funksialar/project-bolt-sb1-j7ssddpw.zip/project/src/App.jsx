import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { ThemeProvider } from './contexts/ThemeContext';
import { LanguageProvider } from './contexts/LanguageContext';
import './i18n';

import Header from './components/Header';
import Sidebar from './components/Sidebar';
import Login from './pages/Login';
import Home from './pages/Home';
import Shorts from './pages/Shorts';
import VideoPage from './pages/VideoPage';
import Subscriptions from './pages/Subscriptions';

import './App.css';

// Protected Route Component
const ProtectedRoute = ({ children }) => {
  const user = localStorage.getItem('user');
  return user ? children : <Navigate to="/login" />;
};

// Placeholder components for other routes
const PlaceholderPage = ({ title }) => (
  <div className="placeholder-page">
    <div className="placeholder-content">
      <h1>{title}</h1>
      <p>This page is coming soon!</p>
    </div>
  </div>
);

const App = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  useEffect(() => {
    const user = localStorage.getItem('user');
    setIsAuthenticated(!!user);
  }, []);

  return (
    <ThemeProvider>
      <LanguageProvider>
        <Router>
          <div className="app">
            <Routes>
              <Route path="/login" element={<Login />} />
              <Route path="/*" element={
                <ProtectedRoute>
                  <Header />
                  <Sidebar 
                    isCollapsed={sidebarCollapsed}
                    onToggle={() => setSidebarCollapsed(!sidebarCollapsed)}
                  />
                  <main className={`main-content ${sidebarCollapsed ? 'sidebar-collapsed' : ''}`}>
                    <Routes>
                      <Route path="/" element={<Home />} />
                      <Route path="/shorts" element={<Shorts />} />
                      <Route path="/video/:id" element={<VideoPage />} />
                      <Route path="/subscriptions" element={<Subscriptions />} />
                      <Route path="/history" element={<PlaceholderPage title="History" />} />
                      <Route path="/playlists" element={<PlaceholderPage title="Playlists" />} />
                      <Route path="/watch-later" element={<PlaceholderPage title="Watch Later" />} />
                      <Route path="/liked" element={<PlaceholderPage title="Liked Videos" />} />
                      <Route path="/music" element={<PlaceholderPage title="Music" />} />
                      <Route path="/live" element={<PlaceholderPage title="Live" />} />
                      <Route path="/gaming" element={<PlaceholderPage title="Gaming" />} />
                      <Route path="/news" element={<PlaceholderPage title="News" />} />
                      <Route path="/sports" element={<PlaceholderPage title="Sports" />} />
                      <Route path="/learning" element={<PlaceholderPage title="Learning" />} />
                      <Route path="/fashion" element={<PlaceholderPage title="Fashion" />} />
                      <Route path="/favorites" element={<PlaceholderPage title="Favorites" />} />
                      <Route path="/settings" element={<PlaceholderPage title="Settings" />} />
                      <Route path="*" element={<Navigate to="/" />} />
                    </Routes>
                  </main>
                </ProtectedRoute>
              } />
            </Routes>
          </div>
        </Router>
      </LanguageProvider>
    </ThemeProvider>
  );
};

export default App;