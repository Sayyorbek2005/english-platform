import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import VideoCard from '../components/VideoCard';
import './Subscriptions.css';

const Subscriptions = () => {
  const { t } = useTranslation();
  const [subscriptions, setSubscriptions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadSubscriptions = () => {
      const subs = JSON.parse(localStorage.getItem('subscriptions') || '[]');
      // Sort by watched date (newest first)
      subs.sort((a, b) => new Date(b.watchedAt) - new Date(a.watchedAt));
      setSubscriptions(subs);
      setLoading(false);
    };

    loadSubscriptions();
  }, []);

  if (loading) {
    return (
      <div className="subscriptions-page">
        <div className="loading">
          {t('common.loading')}
        </div>
      </div>
    );
  }

  return (
    <div className="subscriptions-page">
      <div className="page-header">
        <h1>{t('sidebar.subscriptions')}</h1>
        <p className="page-subtitle">
          {subscriptions.length > 0 
            ? `${subscriptions.length} watched videos`
            : 'No watched videos yet'
          }
        </p>
      </div>

      {subscriptions.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">
            <svg width="120" height="120" viewBox="0 0 24 24" fill="currentColor">
              <path d="M10 16.5l6-4.5-6-4.5v9zM12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z"/>
            </svg>
          </div>
          <h2>Start watching videos</h2>
          <p>Videos you watch will appear here automatically</p>
        </div>
      ) : (
        <div className="videos-grid">
          {subscriptions.map(video => (
            <VideoCard 
              key={`${video.id}_${video.watchedAt}`} 
              video={video} 
              showSaveButton={true}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default Subscriptions;