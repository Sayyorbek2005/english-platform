import React, { useState, useEffect } from 'react';
import { RotateCcw, Trophy, Target } from 'lucide-react';

type Choice = 'rock' | 'paper' | 'scissors' | null;
type Result = 'win' | 'lose' | 'draw' | null;

interface GameState {
  playerChoice: Choice;
  computerChoice: Choice;
  result: Result;
  playerScore: number;
  computerScore: number;
  isAnimating: boolean;
}

const choices = {
  rock: { emoji: '🪨', name: 'Rock' },
  paper: { emoji: '📄', name: 'Paper' },
  scissors: { emoji: '✂️', name: 'Scissors' }
};

function App() {
  const [gameState, setGameState] = useState<GameState>({
    playerChoice: null,
    computerChoice: null,
    result: null,
    playerScore: 0,
    computerScore: 0,
    isAnimating: false
  });

  const getComputerChoice = (): Choice => {
    const choiceArray: Choice[] = ['rock', 'paper', 'scissors'];
    return choiceArray[Math.floor(Math.random() * choiceArray.length)];
  };

  const determineWinner = (player: Choice, computer: Choice): Result => {
    if (player === computer) return 'draw';
    
    if (
      (player === 'rock' && computer === 'scissors') ||
      (player === 'paper' && computer === 'rock') ||
      (player === 'scissors' && computer === 'paper')
    ) {
      return 'win';
    }
    
    return 'lose';
  };

  const playGame = (playerChoice: Choice) => {
    if (gameState.isAnimating || !playerChoice) return;

    setGameState(prev => ({ ...prev, isAnimating: true, result: null }));

    // Add delay for suspense
    setTimeout(() => {
      const computerChoice = getComputerChoice();
      const result = determineWinner(playerChoice, computerChoice);
      
      setGameState(prev => ({
        ...prev,
        playerChoice,
        computerChoice,
        result,
        playerScore: result === 'win' ? prev.playerScore + 1 : prev.playerScore,
        computerScore: result === 'lose' ? prev.computerScore + 1 : prev.computerScore,
        isAnimating: false
      }));
    }, 1000);
  };

  const resetGame = () => {
    setGameState({
      playerChoice: null,
      computerChoice: null,
      result: null,
      playerScore: 0,
      computerScore: 0,
      isAnimating: false
    });
  };

  const getResultMessage = (result: Result) => {
    switch (result) {
      case 'win': return 'You Win! 🎉';
      case 'lose': return 'Computer Wins! 🤖';
      case 'draw': return "It's a Draw! 🤝";
      default: return '';
    }
  };

  const getResultColor = (result: Result) => {
    switch (result) {
      case 'win': return 'text-green-600 bg-green-50 border-green-200';
      case 'lose': return 'text-red-600 bg-red-50 border-red-200';
      case 'draw': return 'text-blue-600 bg-blue-50 border-blue-200';
      default: return '';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 py-8 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-800 mb-2">
            Rock Paper Scissors
          </h1>
          <p className="text-gray-600 text-lg">
            Choose your weapon and challenge the computer!
          </p>
        </div>

        {/* Score Board */}
        <div className="bg-white rounded-2xl shadow-lg p-6 mb-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                <Target className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-800">You</h3>
                <p className="text-2xl font-bold text-blue-600">{gameState.playerScore}</p>
              </div>
            </div>
            
            <div className="text-center">
              <div className="text-sm text-gray-500 mb-1">Score</div>
              <div className="text-3xl font-bold text-gray-400">VS</div>
            </div>
            
            <div className="flex items-center space-x-3">
              <div>
                <h3 className="font-semibold text-gray-800 text-right">Computer</h3>
                <p className="text-2xl font-bold text-purple-600 text-right">{gameState.computerScore}</p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                <Trophy className="w-6 h-6 text-purple-600" />
              </div>
            </div>
          </div>
        </div>

        {/* Game Area */}
        <div className="bg-white rounded-2xl shadow-lg p-8 mb-8">
          {/* Choice Display */}
          <div className="grid md:grid-cols-3 gap-8 mb-8">
            {/* Player Choice */}
            <div className="text-center">
              <h3 className="text-lg font-semibold text-gray-700 mb-4">Your Choice</h3>
              <div className="w-24 h-24 mx-auto bg-blue-50 rounded-full flex items-center justify-center border-4 border-blue-200 transition-all duration-300">
                {gameState.playerChoice ? (
                  <span className="text-4xl animate-bounce">
                    {choices[gameState.playerChoice].emoji}
                  </span>
                ) : (
                  <span className="text-2xl text-gray-400">?</span>
                )}
              </div>
              {gameState.playerChoice && (
                <p className="mt-2 text-sm text-gray-600 animate-fade-in">
                  {choices[gameState.playerChoice].name}
                </p>
              )}
            </div>

            {/* VS */}
            <div className="flex items-center justify-center">
              <div className="text-center">
                <div className="text-4xl font-bold text-gray-300 mb-2">VS</div>
                {gameState.result && (
                  <div className={`px-4 py-2 rounded-full text-sm font-semibold border animate-slide-in ${getResultColor(gameState.result)}`}>
                    {getResultMessage(gameState.result)}
                  </div>
                )}
              </div>
            </div>

            {/* Computer Choice */}
            <div className="text-center">
              <h3 className="text-lg font-semibold text-gray-700 mb-4">Computer's Choice</h3>
              <div className="w-24 h-24 mx-auto bg-purple-50 rounded-full flex items-center justify-center border-4 border-purple-200 transition-all duration-300">
                {gameState.isAnimating ? (
                  <div className="animate-spin">
                    <span className="text-2xl">🎲</span>
                  </div>
                ) : gameState.computerChoice ? (
                  <span className="text-4xl animate-bounce">
                    {choices[gameState.computerChoice].emoji}
                  </span>
                ) : (
                  <span className="text-2xl text-gray-400">?</span>
                )}
              </div>
              {gameState.computerChoice && !gameState.isAnimating && (
                <p className="mt-2 text-sm text-gray-600 animate-fade-in">
                  {choices[gameState.computerChoice].name}
                </p>
              )}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="grid grid-cols-3 gap-4 mb-6">
            {Object.entries(choices).map(([key, choice]) => (
              <button
                key={key}
                onClick={() => playGame(key as Choice)}
                disabled={gameState.isAnimating}
                className="group relative p-6 bg-gradient-to-b from-white to-gray-50 border-2 border-gray-200 rounded-xl hover:border-blue-300 hover:shadow-lg transition-all duration-200 hover:scale-105 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <div className="text-center">
                  <div className="text-5xl mb-3 group-hover:scale-110 transition-transform duration-200">
                    {choice.emoji}
                  </div>
                  <div className="text-lg font-semibold text-gray-700 group-hover:text-blue-600 transition-colors">
                    {choice.name}
                  </div>
                </div>
                <div className="absolute inset-0 bg-blue-50 opacity-0 group-hover:opacity-20 transition-opacity rounded-xl"></div>
              </button>
            ))}
          </div>

          {/* Reset Button */}
          <div className="text-center">
            <button
              onClick={resetGame}
              className="inline-flex items-center space-x-2 px-6 py-3 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl transition-all duration-200 hover:scale-105 active:scale-95"
            >
              <RotateCcw className="w-4 h-4" />
              <span className="font-medium">Reset Game</span>
            </button>
          </div>
        </div>

        {/* Game Instructions */}
        <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-2xl p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-3">How to Play</h3>
          <div className="grid md:grid-cols-3 gap-4 text-sm text-gray-600">
            <div className="flex items-start space-x-2">
              <span className="text-lg">🪨</span>
              <div>
                <strong>Rock</strong> crushes Scissors
              </div>
            </div>
            <div className="flex items-start space-x-2">
              <span className="text-lg">📄</span>
              <div>
                <strong>Paper</strong> covers Rock
              </div>
            </div>
            <div className="flex items-start space-x-2">
              <span className="text-lg">✂️</span>
              <div>
                <strong>Scissors</strong> cuts Paper
              </div>
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes fade-in {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        
        @keyframes slide-in {
          from { opacity: 0; transform: translateX(-10px); }
          to { opacity: 1; transform: translateX(0); }
        }
        
        .animate-fade-in {
          animation: fade-in 0.5s ease-out;
        }
        
        .animate-slide-in {
          animation: slide-in 0.5s ease-out;
        }
      `}</style>
    </div>
  );
}

export default App;