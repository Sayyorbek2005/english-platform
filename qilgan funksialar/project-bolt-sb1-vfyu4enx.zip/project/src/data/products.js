export const products = [
  {
    id: 1,
    title: "Premium Wireless Headphones",
    price: 199.99,
    description: "High-quality wireless headphones with noise cancellation",
    image: "https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg?auto=compress&cs=tinysrgb&w=400"
  },
  {
    id: 2,
    title: "Smart Fitness Watch",
    price: 299.99,
    description: "Advanced fitness tracking with heart rate monitor",
    image: "https://images.pexels.com/photos/437037/pexels-photo-437037.jpeg?auto=compress&cs=tinysrgb&w=400"
  },
  {
    id: 3,
    title: "Laptop Backpack",
    price: 79.99,
    description: "Durable laptop backpack with multiple compartments",
    image: "https://images.pexels.com/photos/2905238/pexels-photo-2905238.jpeg?auto=compress&cs=tinysrgb&w=400"
  },
  {
    id: 4,
    title: "Wireless Mouse",
    price: 49.99,
    description: "Ergonomic wireless mouse with precision tracking",
    image: "https://images.pexels.com/photos/2115256/pexels-photo-2115256.jpeg?auto=compress&cs=tinysrgb&w=400"
  },
  {
    id: 5,
    title: "Bluetooth Speaker",
    price: 129.99,
    description: "Portable bluetooth speaker with premium sound quality",
    image: "https://images.pexels.com/photos/1841841/pexels-photo-1841841.jpeg?auto=compress&cs=tinysrgb&w=400"
  },
  {
    id: 6,
    title: "Smartphone Case",
    price: 24.99,
    description: "Protective smartphone case with wireless charging support",
    image: "https://images.pexels.com/photos/788946/pexels-photo-788946.jpeg?auto=compress&cs=tinysrgb&w=400"
  },
  {
    id: 7,
    title: "USB-C Cable",
    price: 19.99,
    description: "Fast charging USB-C cable with data sync",
    image: "https://images.pexels.com/photos/4393668/pexels-photo-4393668.jpeg?auto=compress&cs=tinysrgb&w=400"
  },
  {
    id: 8,
    title: "Desk Lamp",
    price: 89.99,
    description: "Adjustable LED desk lamp with touch controls",
    image: "https://images.pexels.com/photos/1112598/pexels-photo-1112598.jpeg?auto=compress&cs=tinysrgb&w=400"
  },
  {
    id: 9,
    title: "Coffee Mug",
    price: 14.99,
    description: "Ceramic coffee mug with heat retention technology",
    image: "https://images.pexels.com/photos/302899/pexels-photo-302899.jpeg?auto=compress&cs=tinysrgb&w=400"
  },
  {
    id: 10,
    title: "Notebook Set",
    price: 34.99,
    description: "Premium notebook set with dotted pages",
    image: "https://images.pexels.com/photos/159832/book-address-book-learning-learn-159832.jpeg?auto=compress&cs=tinysrgb&w=400"
  },
  {
    id: 11,
    title: "Mechanical Keyboard",
    price: 159.99,
    description: "RGB mechanical keyboard with blue switches",
    image: "https://images.pexels.com/photos/2148216/pexels-photo-2148216.jpeg?auto=compress&cs=tinysrgb&w=400"
  },
  {
    id: 12,
    title: "Monitor Stand",
    price: 69.99,
    description: "Adjustable monitor stand with storage space",
    image: "https://images.pexels.com/photos/1279813/pexels-photo-1279813.jpeg?auto=compress&cs=tinysrgb&w=400"
  },
  {
    id: 13,
    title: "Phone Charger",
    price: 39.99,
    description: "Fast wireless charging pad for smartphones",
    image: "https://images.pexels.com/photos/4498362/pexels-photo-4498362.jpeg?auto=compress&cs=tinysrgb&w=400"
  },
  {
    id: 14,
    title: "Gaming Mouse Pad",
    price: 29.99,
    description: "Large gaming mouse pad with RGB lighting",
    image: "https://images.pexels.com/photos/777001/pexels-photo-777001.jpeg?auto=compress&cs=tinysrgb&w=400"
  },
  {
    id: 15,
    title: "Webcam HD",
    price: 119.99,
    description: "1080p HD webcam with auto-focus and noise reduction",
    image: "https://images.pexels.com/photos/4226140/pexels-photo-4226140.jpeg?auto=compress&cs=tinysrgb&w=400"
  },
  {
    id: 16,
    title: "Tablet Stand",
    price: 54.99,
    description: "Adjustable tablet stand for comfortable viewing",
    image: "https://images.pexels.com/photos/1334597/pexels-photo-1334597.jpeg?auto=compress&cs=tinysrgb&w=400"
  },
  {
    id: 17,
    title: "Power Bank",
    price: 79.99,
    description: "20000mAh portable power bank with fast charging",
    image: "https://images.pexels.com/photos/4526430/pexels-photo-4526430.jpeg?auto=compress&cs=tinysrgb&w=400"
  },
  {
    id: 18,
    title: "Cable Organizer",
    price: 16.99,
    description: "Magnetic cable organizer for desk setup",
    image: "https://images.pexels.com/photos/1181467/pexels-photo-1181467.jpeg?auto=compress&cs=tinysrgb&w=400"
  },
  {
    id: 19,
    title: "Phone Stand",
    price: 25.99,
    description: "Adjustable phone stand for video calls and content",
    image: "https://images.pexels.com/photos/887751/pexels-photo-887751.jpeg?auto=compress&cs=tinysrgb&w=400"
  },
  {
    id: 20,
    title: "Desk Organizer",
    price: 45.99,
    description: "Wooden desk organizer with multiple compartments",
    image: "https://images.pexels.com/photos/6956350/pexels-photo-6956350.jpeg?auto=compress&cs=tinysrgb&w=400"
  }
];