import React, { createContext, useContext, useState } from 'react';

const LanguageContext = createContext();

const translations = {
  en: {
    // Header
    catalog: 'Catalog',
    cart: 'Cart',
    language: 'Language',
    
    // Product
    addToCart: 'Add to Cart',
    inStock: 'In Stock',
    
    // Cart
    yourCart: 'Your Cart',
    emptyCart: 'Your cart is empty',
    continueShopping: 'Continue Shopping',
    quantity: 'Quantity',
    remove: 'Remove',
    total: 'Total',
    totalItems: 'Total Items',
    
    // Common
    price: 'Price',
    item: 'item',
    items: 'items'
  },
  uz: {
    // Header
    catalog: 'Katalog',
    cart: 'Savatcha',
    language: 'Til',
    
    // Product
    addToCart: 'Savatchaga qo\'shish',
    inStock: 'Mavjud',
    
    // Cart
    yourCart: 'Sizning savatchangiz',
    emptyCart: 'Savatchangiz bo\'sh',
    continueShopping: 'Xaridni davom ettirish',
    quantity: 'Miqdor',
    remove: 'O\'chirish',
    total: 'Jami',
    totalItems: 'Jami mahsulotlar',
    
    // Common
    price: 'Narx',
    item: 'mahsulot',
    items: 'mahsulotlar'
  },
  ru: {
    // Header
    catalog: 'Каталог',
    cart: 'Корзина',
    language: 'Язык',
    
    // Product
    addToCart: 'В корзину',
    inStock: 'В наличии',
    
    // Cart
    yourCart: 'Ваша корзина',
    emptyCart: 'Ваша корзина пуста',
    continueShopping: 'Продолжить покупки',
    quantity: 'Количество',
    remove: 'Удалить',
    total: 'Итого',
    totalItems: 'Всего товаров',
    
    // Common
    price: 'Цена',
    item: 'товар',
    items: 'товаров'
  }
};

export const LanguageProvider = ({ children }) => {
  const [currentLanguage, setCurrentLanguage] = useState('en');

  const switchLanguage = (lang) => {
    setCurrentLanguage(lang);
  };

  const t = (key) => {
    return translations[currentLanguage][key] || key;
  };

  return (
    <LanguageContext.Provider value={{
      currentLanguage,
      switchLanguage,
      t,
      translations
    }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};