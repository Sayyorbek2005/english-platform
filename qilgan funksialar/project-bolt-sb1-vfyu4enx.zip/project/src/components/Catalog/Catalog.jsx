import React from 'react';
import ProductCard from '../ProductCard/ProductCard';
import { products } from '../../data/products';
import { useLanguage } from '../../contexts/LanguageContext';
import './Catalog.css';

const Catalog = () => {
  const { t } = useLanguage();

  return (
    <div className="catalog">
      <div className="catalog-container">
        <div className="catalog-header">
          <h1 className="catalog-title">{t('catalog')}</h1>
          <p className="catalog-subtitle">
            Discover our collection of premium products
          </p>
        </div>
        
        <div className="products-grid">
          {products.map(product => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </div>
  );
};

export default Catalog;