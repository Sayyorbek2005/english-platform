function Header({ totalPrice, onDouble, onHalve }) {
  return (
    <header className="header">
      <div className="container">
        <div className="cart-section">
          <div className="cart-icon"></div>
          <div className="cart-info">
            <span className="cart-total">${totalPrice.toFixed(2)}</span>
            <div className="cart-controls">
              <button className="cart-btn" onClick={onDouble}>+</button>
              <button className="cart-btn" onClick={onHalve}>−</button>
            </div>
          </div>
        </div>
      </div>
    </header>
  )
}

export default Header