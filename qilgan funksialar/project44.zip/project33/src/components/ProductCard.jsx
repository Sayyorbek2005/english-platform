function ProductCard({ product, onAddToCart }) {
  return (
    <div className="product-card">
      <h3 className="product-name">{product.name}</h3>
      <button 
        className="price-btn"
        onClick={() => onAddToCart(product)}
      >
        ${product.price}
      </button>
    </div>
  )
}

export default ProductCard