import { useState } from 'react'
import './App.css'

function App() {
  const [isDarkMode, setIsDarkMode] = useState(false)
  const [heroTextColor, setHeroTextColor] = useState('#000000')
  const [showColorPicker, setShowColorPicker] = useState(false)

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode)
  }

  const toggleColorPicker = () => {
    setShowColorPicker(!showColorPicker)
  }












  const selectColor = (color) => {
    setHeroTextColor(color)
    setShowColorPicker(false)
  }

  return (
    <div className={`app ${isDarkMode ? 'dark' : 'light'}`}>
    
      <header className="header">
        <div className="header-content">
          <div className="logo"> 
          </div>
          
          <div className="header-controls">
            <button 
              className="toggle-btn"
              onClick={toggleDarkMode}
              >
              {isDarkMode ? 'light' : 'dark'}
            </button>
            
            <div className="settings-container">
              <button 
                className="settings-btn"
                onClick={toggleColorPicker}
              >
                nastroyka
              </button>
              
              {showColorPicker && (
                <div className="color-picker">
                  <button 
                    className="color-circle red"
                    onClick={() => selectColor('#ff0000')}
                  ></button>
                  <button 
                    className="color-circle yellow"
                    onClick={() => selectColor('#ffff00')}
                  ></button>
                  <button 
                    className="color-circle green"
                    onClick={() => selectColor('#00ff00')}
                  ></button>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="hero">
        <h1 className="hero-text" style={{ color: heroTextColor }}>
         Salom
        </h1>
        <p className="hero-subtitle" style={{ color: heroTextColor }}>
          Mening ismim Sayyor
        </p>
      </section>
    </div>
  )
}

export default App