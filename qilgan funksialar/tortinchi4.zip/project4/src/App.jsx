import { useState } from 'react'
import './App.css'

function App() {
  const [isDarkMode, setIsDarkMode] = useState(false)
  const [showColorPicker, setShowColorPicker] = useState(false)
  const [selectedColor, setSelectedColor] = useState('')

  const colors = [
    { name: 'red', value: '#ef4444' },
    { name: 'yellow', value: '#eab308' },
    { name: 'green', value: '#22c55e' },
    { name: 'blue', value: '#3b82f6' },
    { name: 'pink', value: '#ec4899' }
  ]

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode)
  }

  const toggleColorPicker = () => {
    setShowColorPicker(!showColorPicker)
  }

  const selectColor = (colorName) => {
    setSelectedColor(colorName)
    setShowColorPicker(false)
  }

  const getColorValue = (colorName) => {
    const color = colors.find(c => c.name === colorName)
    return color ? color.value : ''
  }

  return (
    <div className={`app ${isDarkMode ? 'dark' : 'light'}`}>
     
      <header className="header">
        <div className="header-content">
          <h1 className="logo"> MY Portfolio</h1>
          
          <div className="header-controls">
          
            <div className="color-picker-container">
              <button 
                className="settings-btn"
                onClick={toggleColorPicker}
                aria-label="Color settings"
              >
                Ranglar
              </button>
              
              {showColorPicker && (
                <div className="color-picker">
                  {colors.map((color) => (
                    <button
                      key={color.name}
                      className={`color-option ${selectedColor === color.name ? 'active' : ''}`}
                      style={{ backgroundColor: color.value }}
                      onClick={() => selectColor(color.name)}
                      aria-label={`Select ${color.name} color`}
                    />
                  ))}
                </div>
              )}
            </div>

            <button 
              className="theme-toggle"
              onClick={toggleDarkMode}
              aria-label="Toggle theme"
            >
              {isDarkMode ? 'Light' : 'Dark'}
            </button>
          </div>
        </div>
      </header>

      
      <main className="hero">
        <h1 
          className="hero-text"
          style={{ color: getColorValue(selectedColor) }}
        >
          Hello my name is Sayyor
        </h1>
      </main>
    </div>
  )
}

export default App