import React, { useState, useEffect, useMemo } from 'react';
import { Users, Bomb, Trophy, RotateCcw, Play } from 'lucide-react';

const GRID_SIZE = 8;
const BOMB_BASE = 5;
const BOMB_MULTIPLIER = 3;

function App() {
  const [gameState, setGameState] = useState('lobby'); // 'lobby', 'playing', 'gameOver'
  const [playerCount, setPlayerCount] = useState(2);
  const [currentPlayer, setCurrentPlayer] = useState(0);
  const [players, setPlayers] = useState([]);
  const [grid, setGrid] = useState([]);
  const [revealed, setRevealed] = useState([]);
  const [bombs, setBombs] = useState([]);
  const [winners, setWinners] = useState([]);
  const [explodedBomb, setExplodedBomb] = useState(null);

  const bombCount = useMemo(() => {
    return BOMB_BASE + (playerCount - 1) * BOMB_MULTIPLIER;
  }, [playerCount]);

  const initializeGame = () => {
    // Create players
    const newPlayers = Array.from({ length: playerCount }, (_, i) => ({
      id: i,
      name: `Player ${i + 1}`,
      isActive: true,
      color: `hsl(${(i * 360) / playerCount}, 70%, 50%)`
    }));
    
    setPlayers(newPlayers);
    setCurrentPlayer(0);
    
    // Generate bomb positions
    const bombPositions = new Set();
    while (bombPositions.size < bombCount) {
      const row = Math.floor(Math.random() * GRID_SIZE);
      const col = Math.floor(Math.random() * GRID_SIZE);
      bombPositions.add(`${row}-${col}`);
    }
    setBombs(bombPositions);
    
    // Initialize grid with numbers
    const newGrid = Array(GRID_SIZE).fill(null).map(() => Array(GRID_SIZE).fill(0));
    const newRevealed = Array(GRID_SIZE).fill(null).map(() => Array(GRID_SIZE).fill(false));
    
    // Calculate numbers for each cell
    for (let row = 0; row < GRID_SIZE; row++) {
      for (let col = 0; col < GRID_SIZE; col++) {
        if (bombPositions.has(`${row}-${col}`)) {
          newGrid[row][col] = -1; // -1 represents bomb
        } else {
          let count = 0;
          for (let i = -1; i <= 1; i++) {
            for (let j = -1; j <= 1; j++) {
              const newRow = row + i;
              const newCol = col + j;
              if (newRow >= 0 && newRow < GRID_SIZE && newCol >= 0 && newCol < GRID_SIZE) {
                if (bombPositions.has(`${newRow}-${newCol}`)) {
                  count++;
                }
              }
            }
          }
          newGrid[row][col] = count;
        }
      }
    }
    
    setGrid(newGrid);
    setRevealed(newRevealed);
    setGameState('playing');
    setWinners([]);
    setExplodedBomb(null);
  };

  const revealCell = (row, col) => {
    if (revealed[row][col] || gameState !== 'playing') return;
    
    const newRevealed = revealed.map(r => [...r]);
    const activePlayers = players.filter(p => p.isActive);
    
    if (grid[row][col] === -1) {
      // Bomb hit - eliminate current player
      setExplodedBomb({ row, col });
      const newPlayers = [...players];
      newPlayers[currentPlayer].isActive = false;
      setPlayers(newPlayers);
      
      const remainingPlayers = newPlayers.filter(p => p.isActive);
      
      if (remainingPlayers.length <= 1) {
        // Game over
        setWinners(remainingPlayers);
        setGameState('gameOver');
        return;
      }
      
      // Move to next active player
      let nextPlayer = (currentPlayer + 1) % players.length;
      while (!newPlayers[nextPlayer].isActive) {
        nextPlayer = (nextPlayer + 1) % players.length;
      }
      setCurrentPlayer(nextPlayer);
    } else {
      // Safe cell - reveal it and potentially flood fill
      const toReveal = [[row, col]];
      const visited = new Set();
      
      while (toReveal.length > 0) {
        const [r, c] = toReveal.pop();
        const key = `${r}-${c}`;
        
        if (visited.has(key) || r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE) continue;
        if (newRevealed[r][c]) continue;
        
        visited.add(key);
        newRevealed[r][c] = true;
        
        // If it's a zero, reveal adjacent cells
        if (grid[r][c] === 0) {
          for (let i = -1; i <= 1; i++) {
            for (let j = -1; j <= 1; j++) {
              toReveal.push([r + i, c + j]);
            }
          }
        }
      }
      
      setRevealed(newRevealed);
      
      // Check win condition - all safe cells revealed
      let safeCellsRevealed = 0;
      let totalSafeCells = GRID_SIZE * GRID_SIZE - bombCount;
      
      for (let i = 0; i < GRID_SIZE; i++) {
        for (let j = 0; j < GRID_SIZE; j++) {
          if (newRevealed[i][j] && grid[i][j] !== -1) {
            safeCellsRevealed++;
          }
        }
      }
      
      if (safeCellsRevealed === totalSafeCells) {
        // All safe cells revealed - remaining players win
        setWinners(activePlayers);
        setGameState('gameOver');
        return;
      }
      
      // Move to next active player
      let nextPlayer = (currentPlayer + 1) % players.length;
      while (!players[nextPlayer].isActive) {
        nextPlayer = (nextPlayer + 1) % players.length;
      }
      setCurrentPlayer(nextPlayer);
    }
  };

  const resetGame = () => {
    setGameState('lobby');
    setPlayers([]);
    setGrid([]);
    setRevealed([]);
    setBombs(new Set());
    setWinners([]);
    setExplodedBomb(null);
  };

  if (gameState === 'lobby') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-900 via-purple-900 to-pink-900 flex items-center justify-center p-4">
        <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 shadow-2xl border border-white/20 max-w-md w-full">
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-yellow-500 rounded-full mb-4">
              <Bomb className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-white mb-2">Multiplayer Mines</h1>
            <p className="text-white/70">Turn-based minesweeper battle</p>
          </div>
          
          <div className="space-y-6">
            <div>
              <label className="block text-white text-sm font-medium mb-2">
                Number of Players
              </label>
              <select 
                value={playerCount} 
                onChange={(e) => setPlayerCount(parseInt(e.target.value))}
                className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent"
              >
                {[1, 2, 3, 4, 5].map(num => (
                  <option key={num} value={num} className="bg-gray-800">
                    {num} Player{num !== 1 ? 's' : ''}
                  </option>
                ))}
              </select>
            </div>
            
            <div className="bg-white/5 rounded-lg p-4 border border-white/10">
              <div className="flex items-center justify-between">
                <span className="text-white/70">Bombs on board:</span>
                <span className="text-yellow-400 font-bold text-lg">{bombCount}</span>
              </div>
            </div>
            
            <button 
              onClick={initializeGame}
              className="w-full bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white font-semibold py-3 px-6 rounded-lg transition-all duration-200 flex items-center justify-center gap-2 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
            >
              <Play className="w-5 h-5" />
              Start Game
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (gameState === 'playing') {
    const activePlayers = players.filter(p => p.isActive);
    const currentPlayerData = players[currentPlayer];
    
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900 p-4">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="mb-6 text-center">
            <h1 className="text-3xl font-bold text-white mb-4">Multiplayer Mines</h1>
            
            {/* Current Player */}
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-4 mb-4 border border-white/20">
              <div className="flex items-center justify-center gap-3">
                <div 
                  className="w-4 h-4 rounded-full"
                  style={{ backgroundColor: currentPlayerData.color }}
                ></div>
                <span className="text-white font-semibold">
                  {currentPlayerData.name}'s Turn
                </span>
              </div>
            </div>
            
            {/* Players Status */}
            <div className="flex flex-wrap justify-center gap-2">
              {players.map((player) => (
                <div 
                  key={player.id}
                  className={`px-3 py-1 rounded-full text-sm font-medium border-2 transition-all ${
                    player.isActive 
                      ? 'bg-white/10 border-white/30 text-white' 
                      : 'bg-red-500/20 border-red-500/50 text-red-300 line-through'
                  }`}
                  style={{ 
                    borderColor: player.isActive ? player.color : undefined,
                    backgroundColor: player.isActive ? `${player.color}20` : undefined
                  }}
                >
                  <Users className="w-3 h-3 inline mr-1" />
                  {player.name}
                </div>
              ))}
            </div>
          </div>
          
          {/* Game Grid */}
          <div className="flex justify-center">
            <div className="grid grid-cols-8 gap-1 bg-white/10 backdrop-blur-lg p-4 rounded-xl border border-white/20">
              {grid.map((row, rowIndex) => 
                row.map((cell, colIndex) => (
                  <button
                    key={`${rowIndex}-${colIndex}`}
                    onClick={() => revealCell(rowIndex, colIndex)}
                    disabled={revealed[rowIndex][colIndex]}
                    className={`
                      w-12 h-12 text-sm font-bold border border-white/20 transition-all duration-200 rounded-lg
                      ${revealed[rowIndex][colIndex] 
                        ? cell === -1 
                          ? 'bg-red-500 text-white' 
                          : 'bg-white/80 text-gray-800'
                        : 'bg-white/10 hover:bg-white/20 text-white hover:scale-105'
                      }
                      ${explodedBomb && explodedBomb.row === rowIndex && explodedBomb.col === colIndex 
                        ? 'animate-pulse bg-red-600' 
                        : ''
                      }
                    `}
                  >
                    {revealed[rowIndex][colIndex] ? (
                      cell === -1 ? '💣' : cell === 0 ? '' : cell
                    ) : ''}
                  </button>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (gameState === 'gameOver') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-pink-900 flex items-center justify-center p-4">
        <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 shadow-2xl border border-white/20 max-w-md w-full text-center">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-yellow-500 rounded-full mb-6">
            <Trophy className="w-10 h-10 text-white" />
          </div>
          
          <h2 className="text-3xl font-bold text-white mb-4">Game Over!</h2>
          
          {winners.length > 0 ? (
            <div>
              <p className="text-white/70 mb-4">
                {winners.length === 1 ? 'Winner:' : 'Winners:'}
              </p>
              <div className="space-y-2 mb-6">
                {winners.map((winner) => (
                  <div 
                    key={winner.id}
                    className="bg-white/10 rounded-lg p-3 border-2"
                    style={{ borderColor: winner.color }}
                  >
                    <span className="text-white font-semibold text-lg">
                      🎉 {winner.name}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <p className="text-white/70 mb-6">All players eliminated!</p>
          )}
          
          <button 
            onClick={resetGame}
            className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-semibold py-3 px-6 rounded-lg transition-all duration-200 flex items-center justify-center gap-2 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
          >
            <RotateCcw className="w-5 h-5" />
            Play Again
          </button>
        </div>
      </div>
    );
  }

  return null;
}

export default App;