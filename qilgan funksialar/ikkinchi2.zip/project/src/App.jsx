import { useState, useEffect } from 'react'
import './App.css'

function App() {
  
  const [headerData, setHeaderData] = useState(null)
  

  const [productsData, setProductsData] = useState([])
  
  
  const [loading, setLoading] = useState(true)
  
 
  const [error, setError] = useState(null)

  
  const fetchData = async () => {
    try {
      setLoading(true)
      
      
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      
      const mockApiResponse = {
        "header": {
          "logoText": "Nima gap brother",
          "navLinks": ["Home", "Products", "Contact"]
        },
        "products": [
          {
            "id": 1,
            "name": "1-product",
            "description": "This is the first product.",
            "price": "$29.99"
          },
          {
            "id": 2,
            "name": "2-product",
            "description": "This is the second product.",
            "price": "$49.99"
          },
          {
            "id": 3,
            "name": "3-product",
            "description": "This is the third product with more features.",
            "price": "$79.99"
          }
        ]
      }
      
     
      setHeaderData(mockApiResponse.header)
      setProductsData(mockApiResponse.products)
      setError(null)
      
    } catch (err) {
      
      setError('Failed to fetch data from API')
      console.error('API fetch error:', err)
    } finally {
      setLoading(false)
    }
  }

  
  useEffect(() => {
    fetchData()
  }, []) 

  if (loading) {
    return (
      <div className="loading-container">
        <div className="loading-message">Loading...</div>
      </div>
    )
  }

  
  if (error) {
    return (
      <div className="error-container">
        <div className="error-message">{error}</div>
        <button onClick={fetchData} className="retry-button">
          Retry
        </button>
      </div>
    )
  }

  
  return (
    <div className="app">
      
      <header className="header">
        <div className="header-container">
      
          <div className="logo">
            {headerData?.logoText}
          </div>
          
        
          <nav className="nav">
            <ul className="nav-list">
              {headerData?.navLinks.map((link, index) => (
                <li key={index} className="nav-item">
                  <a href="#" className="nav-link">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="hero">
        <div className="hero-container">
          <h1 className="hero-title">Sizning productangiz</h1>
          <p className="hero-subtitle">Discover our amazing collection of products</p>
          
         
          <div className="products-grid">
            {productsData.map((product) => (
              <div key={product.id} className="product-card">
                <h3 className="product-name">{product.name}</h3>
                <p className="product-description">{product.description}</p>
                <div className="product-price">{product.price}</div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}

export default App