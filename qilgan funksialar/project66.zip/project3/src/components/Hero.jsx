import ProductCard from './ProductCard'

function Hero({ products, onAddToCart }) {
  return (
    <section className="hero">
      <div className="container">
        <h1 className="hero-title">MAxsulotlar</h1>
        <div className="products-grid">
          {products.map(product => (
            <ProductCard
              key={product.id}
              product={product}
              onAddToCart={onAddToCart}
            />
          ))}
        </div>
      </div>
    </section>
  )
}

export default Hero