import { useState } from 'react'
import Header from './components/Header'
import Hero from './components/Hero'
import './App.css'

function App() {
  const [cartItems, setCartItems] = useState([])
  const [totalPrice, setTotalPrice] = useState(0)

  const products = [
    { id: 1, name: 'Phone', price: 10 },
    { id: 2, name: 'Naushnik', price: 15 },
    { id: 3, name: 'Comp', price: 20 }
  ]

  const addToCart = (product) => {
    setCartItems(prev => [...prev, product])
    setTotalPrice(prev => prev + product.price)
  }

  const doubleTotalPrice = () => {
    setTotalPrice(prev => prev * 2)
  }

  const halveTotalPrice = () => {
    setTotalPrice(prev => prev / 2)
  }

  return (
    <div className="app">
      <Header 
        totalPrice={totalPrice}
        onDouble={doubleTotalPrice}
        onHalve={halveTotalPrice}
      />
      <Hero 
        products={products}
        onAddToCart={addToCart}
      />
    </div>
  )
}

export default App