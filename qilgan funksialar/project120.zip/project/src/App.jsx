import './App.css';
import YulduzliReyting from './components/YulduzliReyting';

function App() {

  return (
    <div className="App">
      <YulduzliReyting />
    </div>
  );
}

export default App;
