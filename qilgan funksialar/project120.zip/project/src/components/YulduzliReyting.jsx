import React, { useState } from 'react';

function YulduzliReyting({ maksReyting = 5 }) {
  const [reyting, setReyting] = useState(0);
  const [vaqtinchalikReyting, setVaqtinchalikReyting] = useState(0);

  return (
    <div style={{ display: 'flex', alignItems: 'center', padding: '20px' }}>
      {Array.from({ length: maksReyting }, (_, index) => {
        const yulduzQiymati = index + 1;
        return (
          <span
            key={index}
            onClick={() => setReyting(yulduzQiymati)}
            onMouseEnter={() => setVaqtinchalikReyting(yulduzQiymati)}
            onMouseLeave={() => setVaqtinchalikReyting(0)}
            style={{
              cursor: 'pointer',
              fontSize: '30px',
              color: yulduzQiymati <= (vaqtinchalikReyting || reyting) ? '#ffc107' : '#e4e5e9',
            }}
          >
            ★
          </span>
        );
      })}
      <p style={{ marginLeft: '10px' }}>Reyting: {reyting} / {maksReyting}</p>
    </div>
  );
}

export default YulduzliReyting;