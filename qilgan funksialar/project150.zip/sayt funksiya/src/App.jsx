import React, { useEffect, useMemo, useState, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ShoppingCart, Heart, Search, Moon, SunMedium, X, Trash2, Plus, Minus, Star, Filter as FilterIcon, Info, Check, Menu } from "lucide-react";
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts";
import './App.css'



const CATEGORIES = ["Hammasi", "Elektronika", "Uy-ro'zg'or", "Moda", "Sport", "Kitoblar"];

const PRODUCTS = [
  { id: 1, title: "Simsiz Quloqchinlar", price: 59.99, rating: 4.4, category: "Elektronika", stock: 18, image: "https://picsum.photos/seed/headphones/400/260", desc: "Bluetooth 5.3, 40 soat batareya, shovqin kamaytirish." },
  { id: 2, title: "Aqlli Soat", price: 89.99, rating: 4.1, category: "Elektronika", stock: 9, image: "https://picsum.photos/seed/smartwatch/400/260", desc: "Yurak urishi, GPS, 5ATM suvga chidamli." },
  { id: 3, title: "Ergonomik Kreslo", price: 149.0, rating: 4.7, category: "Uy-ro'zg'or", stock: 5, image: "https://picsum.photos/seed/chair/400/260", desc: "Belni qo'llab-quvvatlash, nafas oladigan to'r, egilish qulfi." },
  { id: 4, title: "Yugurish Poyabzali", price: 72.5, rating: 4.2, category: "Sport", stock: 22, image: "https://picsum.photos/seed/shoes/400/260", desc: "Yengil ko'pik, chidamli taglik, yaxshi ushlash." },
  { id: 5, title: "Minimal Kapushonli Kofta", price: 39.99, rating: 4.0, category: "Moda", stock: 15, image: "https://picsum.photos/seed/hoodie/400/260", desc: "Yumshoq jun, oddiy kesim, 100% paxta." },
  { id: 6, title: "Zanglamaydigan Choynak", price: 29.5, rating: 4.3, category: "Uy-ro'zg'or", stock: 31, image: "https://picsum.photos/seed/kettle/400/260", desc: "1.7L, avto o'chirish, tez qaynash." },
  { id: 7, title: "O'yin Sichqonchasi", price: 24.99, rating: 4.5, category: "Elektronika", stock: 40, image: "https://picsum.photos/seed/mouse/400/260", desc: "6 dasturlanadigan tugma, 12K DPI sensor." },
  { id: 8, title: "Qattiq Muqovali Daftar", price: 8.99, rating: 4.8, category: "Kitoblar", stock: 60, image: "https://picsum.photos/seed/notebook/400/260", desc: "A5 nuqtali to'r, 160 sahifa, yassi ochiladi." },
  { id: 9, title: "Kompakt Blender", price: 54.75, rating: 4.1, category: "Uy-ro'zg'or", stock: 13, image: "https://picsum.photos/seed/blender/400/260", desc: "600W, 2 stakan, oson tozalanadigan pichoqlar." },
  { id: 10, title: "Kanvas Ryukzak", price: 44.0, rating: 4.6, category: "Moda", stock: 17, image: "https://picsum.photos/seed/backpack/400/260", desc: "15.6\" noutbuk, suvga chidamli, ko'p cho'ntak." },
];

const SALES = [
  { name: "Du", sales: 12 },
  { name: "Se", sales: 18 },
  { name: "Cho", sales: 8 },
  { name: "Pa", sales: 13 },
  { name: "Ju", sales: 20 },
  { name: "Sha", sales: 15 },
  { name: "Ya", sales: 10 },
];

// --- Helpers ---------------------------------------------------------------
const currency = (n) => `$${n.toFixed(2)}`;

function useLocalStorage(key, initial) {
  const [state, setState] = useState(() => {
    try {
      const saved = localStorage.getItem(key);
      return saved ? JSON.parse(saved) : initial;
    } catch (e) {
      console.warn(`localStorage xatosi: ${e.message}`);
      return initial;
    }
  });
  useEffect(() => {
    try {
      localStorage.setItem(key, JSON.stringify(state));
    } catch (e) {
      console.warn(`localStorage saqlash xatosi: ${e.message}`);
    }
  }, [key, state]);
  return [state, setState];
}

function Rating({ value }) {
  const full = Math.round(value);
  return (
    <div className="row" aria-label={`Reyting ${value}`}>
      {Array.from({ length: 5 }).map((_, i) => (
        <Star key={i} className={`h-4 w-4 ${i < full ? "fill-current" : "stroke-current"}`} />
      ))}
    </div>
  );
}

// --- UI: Toast -------------------------------------------------------------
function useToast() {
  const [toasts, setToasts] = useState([]);
  const notify = (title, desc) => {
    const id = Math.random().toString(36).slice(2);
    setToasts((t) => [...t, { id, title, desc }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 2400);
  };
  const view = (
    <div className="toast-wrap">
      <AnimatePresence>
        {toasts.map((t) => (
          <motion.div
            key={t.id}
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            className="toast"
            role="alert"
            aria-live="polite"
          >
            <div className="row">
              <Check className="h-5 w-5" />
              <div>
                <div className="font-semibold leading-tight">{t.title}</div>
                {t.desc && <div className="text-sm muted">{t.desc}</div>}
              </div>
            </div>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
  return { notify, view };
}

// --- Main App --------------------------------------------------------------
export default function App() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("Hammasi");
  const [sortBy, setSortBy] = useState("relevance");
  const [price, setPrice] = useState([0, 200]);
  const [dark, setDark] = useLocalStorage("demo.theme.dark", false);
  const [cart, setCart] = useLocalStorage("demo.cart", []);
  const [fav, setFav] = useLocalStorage("demo.fav", []); 
  const [details, setDetails] = useState(null); 
  const [cartOpen, setCartOpen] = useState(false);
  const [favOpen, setFavOpen] = useState(false);
  const [email, setEmail] = useState("");
  const [menuOpen, setMenuOpen] = useState(false); 
  const { notify, view: toastView } = useToast();
  const modalRef = useRef(null);
  const cartDrawerRef = useRef(null);
  const favDrawerRef = useRef(null);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", !!dark);
  }, [dark]);

  useEffect(() => {
    if (cartOpen && cartDrawerRef.current) cartDrawerRef.current.focus();
    if (favOpen && favDrawerRef.current) favDrawerRef.current.focus();
    if (details && modalRef.current) modalRef.current.focus();
  }, [cartOpen, favOpen, details]);

  const filtered = useMemo(() => {
    let items = PRODUCTS.filter((p) =>
      (category === "Hammasi" || p.category === category) &&
      p.price >= price[0] && p.price <= price[1] &&
      p.title.toLowerCase().includes(query.toLowerCase())
    );
    if (sortBy === "price-asc") return [...items].sort((a, b) => a.price - b.price);
    if (sortBy === "price-desc") return [...items].sort((a, b) => b.price - a.price);
    if (sortBy === "rating-desc") return [...items].sort((a, b) => b.rating - a.rating);
    return items;
  }, [query, category, sortBy, price]);

  const cartCount = cart.reduce((sum, i) => sum + i.qty, 0);
  const toggleFav = (id) => {
    setFav((f) => (f.includes(id) ? f.filter((x) => x !== id) : [...f, id]));
    notify(isFav(id) ? "Sevimlilardan olindi" : "Sevimlilarga qo'shildi", PRODUCTS.find((p) => p.id === id)?.title);
  };
  const addToCart = (id) => {
    const product = PRODUCTS.find((p) => p.id === id);
    if (!product || product.stock === 0) {
      notify("Omborda mavjud emas", product?.title);
      return;
    }
    setCart((c) => {
      const found = c.find((x) => x.id === id);
      if (found && found.qty >= product.stock) {
        notify("Omborda yetarli mahsulot yo'q", product.title);
        return c;
      }
      const next = found ? c.map((x) => x.id === id ? { ...x, qty: x.qty + 1 } : x) : [...c, { id, qty: 1 }];
      notify("Savatga qo'shildi", product.title);
      return next;
    });
  };
  const setQty = (id, qty) => {
    const product = PRODUCTS.find((p) => p.id === id);
    if (qty > product.stock) {
      notify("Omborda yetarli mahsulot yo'q", product.title);
      return;
    }
    setCart((c) => c.map((x) => x.id === id ? { ...x, qty: Math.max(1, qty) } : x));
  };
  const removeCart = (id) => {
    setCart((c) => c.filter((x) => x.id !== id));
    notify("Savatdan olindi", PRODUCTS.find((p) => p.id === id)?.title);
  };

  const inCart = (id) => cart.some((x) => x.id === id);
  const isFav = (id) => fav.includes(id);

  const cartLines = cart.map((line) => ({ ...PRODUCTS.find((p) => p.id === line.id), qty: line.qty }));
  const cartTotal = cartLines.reduce((s, l) => s + l.price * l.qty, 0);

  const submitEmail = (e) => {
    e.preventDefault();
    const ok = /.+@.+\..+/.test(email);
    if (!ok) return notify("Xato email", "Iltimos, to'g'ri email kiriting");
    setEmail("");
    notify("Obuna bo'ldingiz", "Yangiliklar xabar qilib boramiz!");
  };

  return (
    <div className="app-wrapper">
      {toastView}

      {/* Header */}
      <div className="site-header">
        <div className="container">
          <div className="inner">
            <motion.div initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }} className="brand">
              Smart<span className="text-[var(--accent)]">Shop</span>
            </motion.div>
            <div className="header-controls hidden md:flex">
              <button
                onClick={() => setDark((d) => !d)}
                className="icon-btn"
                aria-label={dark ? "Yorug'lik rejimiga o'tish" : "Qorong'i rejimiga o'tish"}
              >
                {dark ? <SunMedium className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
              </button>
              <button
                onClick={() => setFavOpen(true)}
                className="icon-btn badge-counter"
                aria-label={`Sevimlilar (${fav.length} mahsulot)`}
              >
                <Heart className="h-5 w-5" />
                {fav.length > 0 && <span className="count">{fav.length}</span>}
              </button>
              <button
                onClick={() => setCartOpen(true)}
                className="icon-btn badge-counter"
                aria-label={`Savat (${cartCount} mahsulot)`}
              >
                <ShoppingCart className="h-5 w-5" />
                {cartCount > 0 && <span className="count">{cartCount}</span>}
              </button>
            </div>
            <button
              onClick={() => setMenuOpen(!menuOpen)}
              className="icon-btn md:hidden"
              aria-label="Menyuni ochish/yopish"
            >
              <Menu className="h-5 w-5" />
            </button>
          </div>
          {menuOpen && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="mobile-menu md:hidden"
            >
              <button
                onClick={() => setDark((d) => !d)}
                className="mobile-menu-item"
                aria-label={dark ? "Yorug'lik rejimiga o'tish" : "Qorong'i rejimiga o'tish"}
              >
                {dark ? <SunMedium className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
                {dark ? "Yorug'lik rejimi" : "Qorong'i rejim"}
              </button>
              <button
                onClick={() => { setFavOpen(true); setMenuOpen(false); }}
                className="mobile-menu-item badge-counter"
                aria-label={`Sevimlilar (${fav.length} mahsulot)`}
              >
                <Heart className="h-5 w-5" />
                Sevimlilar {fav.length > 0 && <span className="count">{fav.length}</span>}
              </button>
              <button
                onClick={() => { setCartOpen(true); setMenuOpen(false); }}
                className="mobile-menu-item badge-counter"
                aria-label={`Savat (${cartCount} mahsulot)`}
              >
                <ShoppingCart className="h-5 w-5" />
                Savat {cartCount > 0 && <span className="count">{cartCount}</span>}
              </button>
            </motion.div>
          )}
        </div>
      </div>

      {/* Hero / Search */}
      <section className="hero container">
        <div className="search-card">
          <div className="search-row">
            <div className="center p-2 rounded-[var(--radius-md)] bg-[var(--card)]">
              <Search className="h-5 w-5" />
            </div>
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Qidirish... (masalan, poyabzal)"
              className="search-input"
              aria-label="Mahsulot qidirish"
            />
          </div>
          <div className="filters">
            <span className="row small-btn bg-[var(--accent)]/10 text-[var(--accent)]">
              <FilterIcon className="h-4 w-4" /> Filterlar
            </span>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="small-btn"
              aria-label="Kategoriyani tanlash"
            >
              {CATEGORIES.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="small-btn"
              aria-label="Saralash usulini tanlash"
            >
              <option value="relevance">Tegishli</option>
              <option value="price-asc">Narx: pastdan</option>
              <option value="price-desc">Narx: yuqoridan</option>
              <option value="rating-desc">Reyting: yuqori</option>
            </select>
            <div className="row price-filter">
              <span className="text-xs muted">Narx:</span>
              <input
                type="number"
                value={price[0]}
                min={0}
                max={price[1]}
                onChange={(e) => setPrice([+e.target.value, price[1]])}
                className="small-btn w-20"
                aria-label="Minimal narx"
              />
              <br />
              <span>–</span>
              <input
                type="number"
                value={price[1]}
                min={price[0]}
                max={500}
                onChange={(e) => setPrice([price[0], +e.target.value])}
                className="small-btn w-20"
                aria-label="Maksimal narx"
              />
            </div>
          </div>
        </div>
        <div className="stats-card">
          <div className="text-sm font-semibold mb-3">Haftalik savdo statistikasi</div>
          <div className="h-40">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={SALES}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="sales" fill="var(--accent)" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </section>

      {/* Products */}
      <section className="products-grid container">
        {filtered.map((p) => (
          <motion.div
            key={p.id}
            layout
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="product-card"
          >
            <div className="relative">
              <img src={p.image} alt={p.title} className="product-image" loading="lazy" />
              <button
                onClick={() => toggleFav(p.id)}
                className="absolute top-3 right-3 p-2 bg-[var(--card)]/80 rounded-full"
                aria-label={isFav(p.id) ? "Sevimlilardan olib tashlash" : "Sevimlilarga qo'shish"}
              >
                <Heart className={`h-5 w-5 ${isFav(p.id) ? "fill-pink-600 stroke-pink-600" : ""}`} />
              </button>
            </div>
            <div className="product-body">
              <div className="top">
                <div>
                  <div className="title">{p.title}</div>
                  <div className="meta">{p.category}</div>
                </div>
                <div className="price">{currency(p.price)}</div>
              </div>
              <div className="rating-row">
                <Rating value={p.rating} />
                <span className={`stock-badge ${p.stock > 10 ? "instock" : "limited"}`}>
                  {p.stock > 10 ? "Omborda bor" : "Cheklangan"}
                </span>
              </div>
              <div className="card-actions">
                <button
                  onClick={() => addToCart(p.id)}
                  className="btn-primary flex-1"
                  aria-label={`${p.title} ni savatga qo'shish`}
                >
                  <ShoppingCart className="h-4 w-4" /> Savatga
                </button>
                <button
                  onClick={() => setDetails(p)}
                  className="btn-outline"
                  aria-label={`${p.title} haqida batafsil ma'lumot`}
                >
                  <Info className="h-4 w-4" /> Batafsil
                </button>
              </div>
            </div>
          </motion.div>
        ))}
      </section>

      {/* Newsletter & Footer */}
      <section className="newsletter">
        <div className="container">
          <div className="newsletter-content">
            <div>
              <div className="text-2xl font-bold">Yangiliklardan xabardor bo'ling</div>
              <p className="muted">Chegirmalar, yangi mahsulotlar va maslahatlar — haftasiga 1 marta.</p>
            </div>
            <form onSubmit={submitEmail} className="newsletter-form">
              <input
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Email kiriting"
                className="small-btn"
                aria-label="Email obunasi"
              />
              <button className="btn-primary" type="submit">Obuna</button>
            </form>
          </div>
        </div>
      </section>

      {/* Drawers & Modals */}
      <AnimatePresence>
        {cartOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="drawer-backdrop"
          >
            <div className="drawer-backdrop" onClick={() => setCartOpen(false)} />
            <motion.div
              initial={{ x: 420 }}
              animate={{ x: 0 }}
              exit={{ x: 420 }}
              transition={{ type: "spring", stiffness: 300, damping: 30 }}
              className="drawer-panel"
              tabIndex={-1}
              ref={cartDrawerRef}
              role="dialog"
              aria-label="Savat"
            >
              <div className="heading">
                <div className="font-bold text-lg">Savat</div>
                <button
                  onClick={() => setCartOpen(false)}
                  className="icon-btn"
                  aria-label="Savatni yopish"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
              <div className="mt-4 space-y-3">
                {cartLines.length === 0 && <div className="muted">Savat bo'sh.</div>}
                {cartLines.map((l) => (
                  <div key={l.id} className="cart-item">
                    <img src={l.image} alt={l.title} className="cart-item-img" />
                    <div className="meta">
                      <div className="font-medium leading-tight">{l.title}</div>
                      <div className="text-sm muted">{currency(l.price)}</div>
                      <div className="controls mt-2">
                        <button
                          onClick={() => setQty(l.id, l.qty - 1)}
                          className="small-btn"
                          aria-label="Miqdorni kamaytirish"
                        >
                          <Minus className="h-4 w-4" />
                        </button>
                        <span className="min-w-[2ch] text-center">{l.qty}</span>
                        <button
                          onClick={() => setQty(l.id, l.qty + 1)}
                          className="small-btn"
                          aria-label="Miqdorni oshirish"
                        >
                          <Plus className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-semibold">{currency(l.price * l.qty)}</div>
                      <button
                        onClick={() => removeCart(l.id)}
                        className="text-sm row muted hover:text-[var(--accent)] mt-1"
                        aria-label={`${l.title} ni savatdan olib tashlash`}
                      >
                        <Trash2 className="h-4 w-4" /> O'chirish
                      </button>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-5 border-t border-[var(--muted)]/20 pt-4">
                <div className="row justify-between font-semibold">
                  <span>Jami</span>
                  <span>{currency(cartTotal)}</span>
                </div>
                <button
                  disabled={cartLines.length === 0}
                  className="btn-primary w-full mt-3"
                  onClick={() => notify("Buyurtma berildi", "Tez orada aloqaga chiqamiz")}
                >
                  Buyurtma berish
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {favOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="drawer-backdrop"
          >
            <div className="drawer-backdrop" onClick={() => setFavOpen(false)} />
            <motion.div
              initial={{ x: 420 }}
              animate={{ x: 0 }}
              exit={{ x: 420 }}
              transition={{ type: "spring", stiffness: 300, damping: 30 }}
              className="drawer-panel"
              tabIndex={-1}
              ref={favDrawerRef}
              role="dialog"
              aria-label="Sevimlilar"
            >
              <div className="heading">
                <div className="font-bold text-lg">Sevimlilar</div>
                <button
                  onClick={() => setFavOpen(false)}
                  className="icon-btn"
                  aria-label="Sevimlilarni yopish"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
              <div className="mt-4 space-y-3">
                {fav.length === 0 && <div className="muted">Sevimlilar yo'q.</div>}
                {fav.map((id) => {
                  const p = PRODUCTS.find((x) => x.id === id);
                  return (
                    <div key={id} className="cart-item">
                      <img src={p.image} alt={p.title} className="cart-item-img" />
                      <div className="meta">
                        <div className="font-medium leading-tight">{p.title}</div>
                        <div className="text-sm muted">{currency(p.price)}</div>
                      </div>
                      <button
                        onClick={() => addToCart(id)}
                        className="btn-primary small-btn"
                        aria-label={`${p.title} ni savatga qo'shish`}
                      >
                        Savatga
                      </button>
                      <button
                        onClick={() => toggleFav(id)}
                        className="btn-outline small-btn"
                        aria-label={`${p.title} ni sevimlilardan olib tashlash`}
                      >
                        Olib tashlash
                      </button>
                    </div>
                  );
                })}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {!!details && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="modal-wrap"
          >
            <div className="modal-backdrop" onClick={() => setDetails(null)} />
            <motion.div
              initial={{ scale: 0.92 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.92 }}
              className="modal-panel"
              tabIndex={-1}
              ref={modalRef}
              role="dialog"
              aria-label={`${details.title} haqida ma'lumot`}
            >
              <div className="relative">
                <img src={details.image} alt={details.title} className="modal-image" />
                <button
                  onClick={() => setDetails(null)}
                  className="icon-btn absolute top-3 right-3 bg-[var(--card)]/80"
                  aria-label="Modalni yopish"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
              <div className="modal-body">
                <div className="row justify-between">
                  <div>
                    <div className="text-xl font-bold">{details.title}</div>
                    <div className="text-sm muted">{details.category}</div>
                  </div>
                  <div className="text-xl font-extrabold">{currency(details.price)}</div>
                </div>
                <div className="mt-2"><Rating value={details.rating} /></div>
                <p className="mt-3 muted">{details.desc}</p>
                <div className="card-actions">
                  <button
                    onClick={() => addToCart(details.id)}
                    className="btn-primary flex-1"
                    aria-label={`${details.title} ni savatga qo'shish`}
                  >
                    <ShoppingCart className="h-4 w-4" /> Savatga
                  </button>
                  <button
                    onClick={() => toggleFav(details.id)}
                    className="btn-outline"
                    aria-label={isFav(details.id) ? "Sevimlilardan olib tashlash" : "Sevimlilarga qo'shish"}
                  >
                    <Heart className="h-4 w-4" /> {isFav(details.id) ? "Saqlangan" : "Sevimli"}
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}




