import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import VideoCard from '../components/VideoCard';
import videosData from '../api/videos.json';
import './Home.css';

const Home = () => {
  const { t } = useTranslation();
  const [videos, setVideos] = useState([]);
  const [filteredVideos, setFilteredVideos] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate API call
    setTimeout(() => {
      setVideos(videosData);
      setFilteredVideos(videosData);
      setLoading(false);
    }, 500);
  }, []);

  useEffect(() => {
    const handleSearch = (event) => {
      const searchTerm = event.detail.toLowerCase();
      if (searchTerm) {
        const filtered = videos.filter(video => 
          video.title.toLowerCase().includes(searchTerm) ||
          video.channel.toLowerCase().includes(searchTerm)
        );
        setFilteredVideos(filtered);
      } else {
        setFilteredVideos(videos);
      }
    };

    window.addEventListener('search', handleSearch);
    return () => window.removeEventListener('search', handleSearch);
  }, [videos]);

  if (loading) {
    return (
      <div className="home-page">
        <div className="loading">
          {t('common.loading')}
        </div>
      </div>
    );
  }

  return (
    <div className="home-page">
      <div className="videos-grid">
        {filteredVideos.length === 0 ? (
          <div className="no-results">
            <p>No videos found</p>
          </div>
        ) : (
          filteredVideos.map(video => (
            <VideoCard key={video.id} video={video} />
          ))
        )}
      </div>
    </div>
  );
};

export default Home;