import { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { AiOutlineLike } from 'react-icons/ai';
import videosData from '../api/videos.json';
import './VideoPage.css';

const VideoPage = () => {
  const { t } = useTranslation();
  const { id } = useParams();
  const navigate = useNavigate();
  const [video, setVideo] = useState(null);
  const [loading, setLoading] = useState(true);
  const [liked, setLiked] = useState(false);
  const [disliked, setDisliked] = useState(false);
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState('');
  const [user, setUser] = useState(null);
  const videoRef = useRef(null);

  useEffect(() => {
    const userData = localStorage.getItem('user');
    if (userData) {
      setUser(JSON.parse(userData));
    }

    const foundVideo = videosData.find(v => v.id === id);
    if (foundVideo) {
      setVideo(foundVideo);
      
      const subscriptions = JSON.parse(localStorage.getItem('subscriptions') || '[]');
      if (!subscriptions.some(sub => sub.id === foundVideo.id)) {
        subscriptions.push({
          ...foundVideo,
          watchedAt: new Date().toISOString()
        });
        localStorage.setItem('subscriptions', JSON.stringify(subscriptions));
      }
      
      const videoComments = JSON.parse(localStorage.getItem(`comments_${id}`) || '[]');
      setComments(videoComments);
    } else {
      navigate('/');
    }
    setLoading(false);
  }, [id, navigate]);

  const handleLike = () => {
    setLiked(!liked);
    if (disliked) setDisliked(false);
  };

  const handleDislike = () => {
    setDisliked(!disliked);
    if (liked) setLiked(false);
  };

  const handleAddComment = (e) => {
    e.preventDefault();
    if (!newComment.trim() || !user) return;

    const comment = {
      id: Date.now().toString(),
      text: newComment.trim(),
      author: user.name,
      avatar: "https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=50",
      timestamp: new Date().toISOString(),
      likes: 0
    };

    const updatedComments = [comment, ...comments];
    setComments(updatedComments);
    localStorage.setItem(`comments_${id}`, JSON.stringify(updatedComments));
    setNewComment('');
  };

  const formatViews = (views) => {
    return views;
  };

  if (loading) {
    return (
      <div className="video-page">
        <div className="loading">
          {t('common.loading')}
        </div>
      </div>
    );
  }

  if (!video) {
    return (
      <div className="video-page">
        <div className="error">
          {t('common.error')}
        </div>
      </div>
    );
  }

  return (
    <div className="video-page">
      <div className="video-content">
        <div className="video-player-container">
          <video
            ref={videoRef}
            src={video.video}
            poster={video.thumbnail}
            controls
            className="video-player"
            autoPlay
          />
        </div>

        <div className="video-info-section">
          <h1 className="video-title">{video.title}</h1>
          
          <div className="video-stats">
            <div className="video-meta">
              <span>{formatViews(video.views)} {t('video.views')}</span>
              <span className="meta-separator">•</span>
              <span>{video.date}</span>
            </div>

            <div className="video-actions">
              <button 
                className={`action-btn ${liked ? 'liked' : ''}`}
                onClick={handleLike}
              >
                <AiOutlineLike />
                <span>{t('video.like')}</span>
              </button>
              
              <button 
                className={`action-btn ${disliked ? 'disliked' : ''}`}
                onClick={handleDislike}
              >
                <AiOutlineLike style={{ transform: 'rotate(180deg)' }} />
                <span>{t('video.dislike')}</span>
              </button>
              
              <button className="action-btn">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M18 16.08c-.76 0-1.44.3-1.96.77L8.91 12.7c.05-.23.09-.46.09-.7s-.04-.47-.09-.7l7.05-4.11c.54.5 1.25.81 2.04.81 1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3c0 .24.04.47.09.7L8.04 9.81C7.5 9.31 6.79 9 6 9c-1.66 0-3 1.34-3 3s1.34 3 3 3c.79 0 1.50-.31 2.04-.81l7.12 4.16c-.05.21-.08.43-.08.65 0 1.61 1.31 2.92 2.92 2.92s2.92-1.31 2.92-2.92S19.61 16.08 18 16.08z"/>
                </svg>
                <span>{t('video.share')}</span>
              </button>
              
              <button className="action-btn">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M14 10H2v2h12v-2zm0-4H2v2h12V6zm4 8v-4h-2v4h-4l3 3 3-3h-4zM2 16h8v-2H2v2z"/>
                </svg>
                <span>{t('video.save')}</span>
              </button>
            </div>
          </div>

          <div className="channel-info">
            <div className="channel-avatar">
              <img src={video.avatar} alt={video.channel} />
            </div>
            <div className="channel-details">
              <h3 className="channel-name">{video.channel}</h3>
              <p className="channel-subscribers">1.2M subscribers</p>
            </div>
            <button className="subscribe-btn">Subscribe</button>
          </div>
        </div>

        <div className="comments-section">
          <h3 className="comments-title">
            {comments.length} {t('video.comments')}
          </h3>

          {user && (
            <form className="comment-form" onSubmit={handleAddComment}>
              <div className="comment-input-container">
                <img 
                  src="https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=40" 
                  alt="Your avatar" 
                  className="comment-avatar"
                />
                <input
                  type="text"
                  placeholder={t('video.addComment')}
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  className="comment-input"
                />
              </div>
              <div className="comment-actions">
                <button 
                  type="button"
                  className="cancel-btn"
                  onClick={() => setNewComment('')}
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  className="post-btn"
                  disabled={!newComment.trim()}
                >
                  {t('video.post')}
                </button>
              </div>
            </form>
          )}

          <div className="comments-list">
            {comments.map(comment => (
              <div key={comment.id} className="comment">
                <img 
                  src={comment.avatar} 
                  alt={comment.author}
                  className="comment-avatar"
                />
                <div className="comment-content">
                  <div className="comment-header">
                    <span className="comment-author">{comment.author}</span>
                    <span className="comment-time">
                      {new Date(comment.timestamp).toLocaleDateString()}
                    </span>
                  </div>
                  <p className="comment-text">{comment.text}</p>
                  <div className="comment-actions">
                    <button className="comment-like">
                      <AiOutlineLike />
                      <span>{comment.likes}</span>
                    </button>
                    <button className="comment-dislike">
                      <AiOutlineLike style={{ transform: 'rotate(180deg)' }} />
                    </button>
                    <button className="comment-reply">Reply</button>
                  </div>
                </div>
              </div>
            ))}
            
            {comments.length === 0 && (
              <div className="no-comments">
                <p>No comments yet. Be the first to comment!</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default VideoPage;