import { useState, useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { AiOutlineLike } from 'react-icons/ai';
import shortsData from '../api/shorts.json';
import './Shorts.css';

const Shorts = () => {
  const { t } = useTranslation();
  const [shorts, setShorts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [likes, setLikes] = useState({});
  const containerRef = useRef(null);
  const videoRefs = useRef([]);

  useEffect(() => {
    // Load shorts data
    setTimeout(() => {
      setShorts(shortsData);
      setLoading(false);
    }, 300);
  }, []);

  useEffect(() => {
    // Load likes from localStorage
    const savedLikes = JSON.parse(localStorage.getItem('shortsLikes') || '{}');
    setLikes(savedLikes);
  }, []);

  useEffect(() => {
    // Intersection Observer for auto-play
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          const video = entry.target;
          if (entry.isIntersecting) {
            video.play().catch(() => {});
          } else {
            video.pause();
          }
        });
      },
      { threshold: 0.5 }
    );

    videoRefs.current.forEach((video) => {
      if (video) observer.observe(video);
    });

    return () => observer.disconnect();
  }, [shorts]);

  const handleLike = (shortId) => {
    const newLikes = { ...likes };
    newLikes[shortId] = !newLikes[shortId];
    setLikes(newLikes);
    localStorage.setItem('shortsLikes', JSON.stringify(newLikes));
  };

  const formatLikes = (likesStr) => {
    const baseLikes = parseInt(likesStr.replace('K', '000'));
    return likes[shorts.find(s => s.likes === likesStr)?.id] 
      ? `${Math.floor(baseLikes / 1000) + 1}K`
      : likesStr;
  };

  if (loading) {
    return (
      <div className="shorts-page">
        <div className="loading">
          {t('common.loading')}
        </div>
      </div>
    );
  }

  return (
    <div className="shorts-page">
      <div className="shorts-container" ref={containerRef}>
        {shorts.map((short, index) => (
          <div key={short.id} className="short-item">
            <div className="short-video-container">
              <video
                ref={(el) => videoRefs.current[index] = el}
                src={short.video}
                poster={short.thumbnail}
                muted
                loop
                playsInline
                className="short-video"
              />
              
              <div className="short-overlay">
                <div className="short-info">
                  <div className="short-channel">
                    <img src={short.avatar} alt={short.channel} />
                    <span>@{short.channel.replace(' ', '').toLowerCase()}</span>
                  </div>
                  <h3 className="short-title">{short.title}</h3>
                </div>

                <div className="short-actions">
                  <button 
                    className={`action-button ${likes[short.id] ? 'liked' : ''}`}
                    onClick={() => handleLike(short.id)}
                  >
                    <AiOutlineLike />
                    <span>{formatLikes(short.likes)}</span>
                  </button>
                  
                  <button className="action-button">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M15 5.63L20.66 2L22 3.34L17.63 8L22 12.66L20.66 14L15 9.37L9.34 14L8 12.66L12.37 8L8 3.34L9.34 2L15 5.63Z"/>
                    </svg>
                    <span>Dislike</span>
                  </button>
                  
                  <button className="action-button">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M18 16.08c-.76 0-1.44.3-1.96.77L8.91 12.7c.05-.23.09-.46.09-.7s-.04-.47-.09-.7l7.05-4.11c.54.5 1.25.81 2.04.81 1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3c0 .24.04.47.09.7L8.04 9.81C7.5 9.31 6.79 9 6 9c-1.66 0-3 1.34-3 3s1.34 3 3 3c.79 0 1.50-.31 2.04-.81l7.12 4.16c-.05.21-.08.43-.08.65 0 1.61 1.31 2.92 2.92 2.92s2.92-1.31 2.92-2.92S19.61 16.08 18 16.08z"/>
                    </svg>
                    <span>Share</span>
                  </button>
                  
                  <button className="action-button">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zM8 17.5c-1.38 0-2.5-1.12-2.5-2.5S6.62 12.5 8 12.5s2.5 1.12 2.5 2.5S9.38 17.5 8 17.5zM12 10.5c-1.38 0-2.5-1.12-2.5-2.5S10.62 5.5 12 5.5s2.5 1.12 2.5 2.5S13.38 10.5 12 10.5zM16 17.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5S17.38 17.5 16 17.5z"/>
                    </svg>
                    <span>More</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Shorts;