import { useNavigate, useLocation } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { 
  AiOutlineHome, 
  AiOutlineLike 
} from 'react-icons/ai';
import { 
  FaBolt, 
  FaGamepad 
} from 'react-icons/fa';
import { 
  MdSubscriptions, 
  MdHistory, 
  MdPlaylistPlay, 
  MdWatchLater, 
  MdLiveTv, 
  MdSportsSoccer 
} from 'react-icons/md';
import { 
  GiMusicalNotes, 
  GiLipstick 
} from 'react-icons/gi';
import { BiNews } from 'react-icons/bi';
import { RiGraduationCapLine } from 'react-icons/ri';
import { useTheme } from '../contexts/ThemeContext';
import { useLanguage } from '../contexts/LanguageContext';
import './Sidebar.css';

const Sidebar = ({ isCollapsed, onToggle }) => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const location = useLocation();
  const { theme, toggleTheme } = useTheme();
  const { changeLanguage, languages, currentLanguage } = useLanguage();

  const menuItems = [
    {
      section: 'main',
      items: [
        { icon: AiOutlineHome, label: t('sidebar.home'), path: '/' },
        { icon: FaBolt, label: t('sidebar.shorts'), path: '/shorts' },
        { icon: MdSubscriptions, label: t('sidebar.subscriptions'), path: '/subscriptions' }
      ]
    },
    {
      section: 'library',
      items: [
        { icon: MdHistory, label: t('sidebar.history'), path: '/history' },
        { icon: MdPlaylistPlay, label: t('sidebar.playlists'), path: '/playlists' },
        { icon: MdWatchLater, label: t('sidebar.watchLater'), path: '/watch-later' },
        { icon: AiOutlineLike, label: t('sidebar.liked'), path: '/liked' }
      ]
    },
    {
      section: 'explore',
      items: [
        { icon: GiMusicalNotes, label: t('sidebar.music'), path: '/music' },
        { icon: MdLiveTv, label: t('sidebar.live'), path: '/live' },
        { icon: FaGamepad, label: t('sidebar.gaming'), path: '/gaming' },
        { icon: BiNews, label: t('sidebar.news'), path: '/news' },
        { icon: MdSportsSoccer, label: t('sidebar.sports'), path: '/sports' },
        { icon: RiGraduationCapLine, label: t('sidebar.learning'), path: '/learning' },
        { icon: GiLipstick, label: t('sidebar.fashion'), path: '/fashion' }
      ]
    }
  ];

  const handleItemClick = (path) => {
    navigate(path);
  };

  return (
    <nav className={`sidebar ${isCollapsed ? 'collapsed' : ''}`}>
      <div className="sidebar-content">
        {menuItems.map((section, sectionIndex) => (
          <div key={section.section} className="sidebar-section">
            {section.items.map((item, index) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.path;
              
              return (
                <button
                  key={index}
                  className={`sidebar-item ${isActive ? 'active' : ''}`}
                  onClick={() => handleItemClick(item.path)}
                  title={isCollapsed ? item.label : ''}
                >
                  <Icon className="sidebar-icon" />
                  {!isCollapsed && <span className="sidebar-label">{item.label}</span>}
                </button>
              );
            })}
            {sectionIndex < menuItems.length - 1 && !isCollapsed && (
              <div className="sidebar-divider"></div>
            )}
          </div>
        ))}

        {!isCollapsed && (
          <>
            <div className="sidebar-divider"></div>
            <div className="sidebar-section">
              <div className="sidebar-settings">
                <h3 className="settings-title">{t('sidebar.settings')}</h3>
                
                <div className="setting-item">
                  <span className="setting-label">{t('user.theme')}</span>
                  <button className="theme-toggle" onClick={toggleTheme}>
                    {theme === 'dark' ? '🌙' : '☀️'}
                  </button>
                </div>

                <div className="setting-item">
                  <span className="setting-label">{t('user.language')}</span>
                  <div className="language-selector">
                    {languages.map(lang => (
                      <button
                        key={lang.code}
                        className={`language-btn ${currentLanguage === lang.code ? 'active' : ''}`}
                        onClick={() => changeLanguage(lang.code)}
                        title={lang.name}
                      >
                        {lang.flag}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </nav>
  );
};

export default Sidebar;