import { useState, useRef, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { FaVideo, FaBolt } from 'react-icons/fa';
import { IoMdNotifications } from 'react-icons/io';
import { AiOutlineLike } from 'react-icons/ai';
import { useTheme } from '../contexts/ThemeContext';
import { useLanguage } from '../contexts/LanguageContext';
import './Header.css';

const Header = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const location = useLocation();
  const { theme, toggleTheme } = useTheme();
  const { changeLanguage, languages, currentLanguage } = useLanguage();
  
  const [searchTerm, setSearchTerm] = useState('');
  const [showUserDropdown, setShowUserDropdown] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showFavorites, setShowFavorites] = useState(false);
  const [user, setUser] = useState(null);

  const userDropdownRef = useRef(null);
  const notificationRef = useRef(null);
  const favoritesRef = useRef(null);

  useEffect(() => {
    const userData = localStorage.getItem('user');
    if (userData) {
      setUser(JSON.parse(userData));
    }
  }, []);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (userDropdownRef.current && !userDropdownRef.current.contains(event.target)) {
        setShowUserDropdown(false);
      }
      if (notificationRef.current && !notificationRef.current.contains(event.target)) {
        setShowNotifications(false);
      }
      if (favoritesRef.current && !favoritesRef.current.contains(event.target)) {
        setShowFavorites(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSearch = (e) => {
    e.preventDefault();
    if (location.pathname === '/' && searchTerm) {
      window.dispatchEvent(new CustomEvent('search', { detail: searchTerm }));
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('user');
    navigate('/login');
  };

  const getFavorites = () => {
    return JSON.parse(localStorage.getItem('favorites') || '[]');
  };

  const removeFavorite = (videoId) => {
    const favorites = getFavorites();
    const updated = favorites.filter(fav => fav.id !== videoId);
    localStorage.setItem('favorites', JSON.stringify(updated));
    // Force re-render
    setShowFavorites(false);
    setTimeout(() => setShowFavorites(true), 0);
  };

  if (!user) return null;

  return (
    <header className="header">
      <div className="header-left">
        <div className="logo" onClick={() => navigate('/')}>
          <FaBolt className="logo-icon" />
          <span className="logo-text">YouTube</span>
        </div>
      </div>

      <div className="header-center">
        <form className="search-form" onSubmit={handleSearch}>
          <input
            type="text"
            placeholder={t('header.search')}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="search-input"
          />
          <button type="submit" className="search-button">
            <svg width="24" height="24" viewBox="0 0 24 24">
              <path fill="currentColor" d="m20.87 20.17-5.59-5.59C16.35 13.35 17 11.75 17 10c0-3.87-3.13-7-7-7s-7 3.13-7 7 3.13 7 7 7c1.75 0 3.35-.65 4.58-1.71l5.59 5.59.7-.71zM10 16c-3.31 0-6-2.69-6-6s2.69-6 6-6 6 2.69 6 6-2.69 6-6 6z"/>
            </svg>
          </button>
        </form>
        <button className="voice-button">
          <svg width="24" height="24" viewBox="0 0 24 24">
            <path fill="currentColor" d="M12 14c1.66 0 3-1.34 3-3V5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3z"/>
            <path fill="currentColor" d="M17 11c0 2.76-2.24 5-5 5s-5-2.24-5-5H5c0 3.53 2.61 6.43 6 6.92V21h2v-3.08c3.39-.49 6-3.39 6-6.92h-2z"/>
          </svg>
        </button>
      </div>

      <div className="header-right">
        <button className="header-button">
          <FaVideo />
        </button>

        <div className="notification-container" ref={notificationRef}>
          <button 
            className="header-button notification-button"
            onClick={() => setShowNotifications(!showNotifications)}
          >
            <IoMdNotifications />
            <span className="notification-badge">2</span>
          </button>
          {showNotifications && (
            <div className="notification-dropdown">
              <div className="notification-header">
                <h3>{t('header.notifications')}</h3>
              </div>
              <div className="notification-item">
                <div className="notification-avatar">
                  <img src="https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=50" alt="Avatar" />
                </div>
                <div className="notification-content">
                  <p>New video from Nature Explorer</p>
                  <span>2 hours ago</span>
                </div>
              </div>
              <div className="notification-item">
                <div className="notification-avatar">
                  <img src="https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=50" alt="Avatar" />
                </div>
                <div className="notification-content">
                  <p>Chef Marco uploaded a new recipe</p>
                  <span>1 day ago</span>
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="favorites-container" ref={favoritesRef}>
          <button 
            className="header-button favorites-button"
            onClick={() => setShowFavorites(!showFavorites)}
          >
            <AiOutlineLike />
            <span className="favorites-text">{t('header.favorites')}</span>
          </button>
          {showFavorites && (
            <div className="favorites-dropdown">
              <div className="favorites-header">
                <h3>{t('header.favorites')}</h3>
              </div>
              <div className="favorites-list">
                {getFavorites().length === 0 ? (
                  <p className="no-favorites">No favorites yet</p>
                ) : (
                  getFavorites().map(video => (
                    <div key={video.id} className="favorite-item">
                      <img 
                        src={video.thumbnail} 
                        alt={video.title}
                        className="favorite-thumbnail"
                        onClick={() => navigate(`/video/${video.id}`)}
                      />
                      <div className="favorite-info">
                        <h4 onClick={() => navigate(`/video/${video.id}`)}>{video.title}</h4>
                        <p>{video.channel}</p>
                      </div>
                      <button 
                        className="remove-favorite"
                        onClick={() => removeFavorite(video.id)}
                      >
                        ×
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>

        <div className="user-container" ref={userDropdownRef}>
          <button 
            className="user-avatar"
            onClick={() => setShowUserDropdown(!showUserDropdown)}
          >
            <img 
              src="https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=100" 
              alt="User Avatar" 
            />
          </button>
          {showUserDropdown && (
            <div className="user-dropdown">
              <div className="user-info">
                <img 
                  src="https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=50" 
                  alt="User Avatar" 
                />
                <div>
                  <h4>{user.name}</h4>
                  <p>@{user.name.toLowerCase()}</p>
                </div>
              </div>
              <div className="dropdown-divider"></div>
              <button className="dropdown-item" onClick={() => navigate('/settings')}>
                <span>{t('user.profile')}</span>
              </button>
              <div className="dropdown-divider"></div>
              <button className="dropdown-item" onClick={toggleTheme}>
                <span>{t('user.theme')}: {theme === 'dark' ? 'Dark' : 'Light'}</span>
              </button>
              <div className="dropdown-section">
                <span className="dropdown-label">{t('user.language')}</span>
                {languages.map(lang => (
                  <button
                    key={lang.code}
                    className={`dropdown-item language-item ${currentLanguage === lang.code ? 'active' : ''}`}
                    onClick={() => changeLanguage(lang.code)}
                  >
                    <span className="language-flag">{lang.flag}</span>
                    <span>{lang.name}</span>
                  </button>
                ))}
              </div>
              <div className="dropdown-divider"></div>
              <button className="dropdown-item" onClick={handleLogout}>
                <span>{t('user.signOut')}</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;