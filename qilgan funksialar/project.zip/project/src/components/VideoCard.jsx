import { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { AiOutlineLike } from 'react-icons/ai';
import './VideoCard.css';

const VideoCard = ({ video, showSaveButton = true }) => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const videoRef = useRef(null);
  const [isHovered, setIsHovered] = useState(false);
  const [isSaved, setIsSaved] = useState(false);

  const handleMouseEnter = () => {
    setIsHovered(true);
    if (videoRef.current) {
      videoRef.current.play().catch(() => {
        // Handle play error silently
      });
    }
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
    if (videoRef.current) {
      videoRef.current.pause();
      videoRef.current.currentTime = 0;
    }
  };

  const handleVideoClick = (e) => {
    e.preventDefault();
    navigate(`/video/${video.id}`);
  };

  const handleSaveClick = (e) => {
    e.stopPropagation();
    const favorites = JSON.parse(localStorage.getItem('favorites') || '[]');
    
    if (isSaved) {
      const updated = favorites.filter(fav => fav.id !== video.id);
      localStorage.setItem('favorites', JSON.stringify(updated));
      setIsSaved(false);
    } else {
      favorites.push(video);
      localStorage.setItem('favorites', JSON.stringify(favorites));
      setIsSaved(true);
    }
  };

  useState(() => {
    const favorites = JSON.parse(localStorage.getItem('favorites') || '[]');
    setIsSaved(favorites.some(fav => fav.id === video.id));
  });

  return (
    <div className="video-card">
      <div 
        className="video-thumbnail"
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
        onClick={handleVideoClick}
      >
        {isHovered ? (
          <video
            ref={videoRef}
            src={video.video}
            muted
            loop
            className="video-preview"
          />
        ) : (
          <img 
            src={video.thumbnail} 
            alt={video.title}
            className="thumbnail-image"
          />
        )}
        <div className="video-duration">{video.duration}</div>
        {showSaveButton && (
          <button 
            className={`save-button ${isSaved ? 'saved' : ''}`}
            onClick={handleSaveClick}
            title={isSaved ? 'Remove from favorites' : 'Save to favorites'}
          >
            <AiOutlineLike />
          </button>
        )}
      </div>
      
      <div className="video-info">
        <div className="video-avatar">
          <img src={video.avatar} alt={video.channel} />
        </div>
        <div className="video-details">
          <h3 className="video-title" onClick={handleVideoClick}>
            {video.title}
          </h3>
          <p className="video-channel">{video.channel}</p>
          <div className="video-meta">
            <span>{video.views} {t('video.views')}</span>
            <span className="meta-separator">•</span>
            <span>{video.date}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VideoCard;