import React, { useState } from 'react';

function ColorPicker() {
  // Rang holatini boshqarish uchun useState
  const [color, setColor] = useState('aqua');

  // Rang o‘zgarishini boshqarish
  const handleColorChange = (event) => {
    setColor(event.target.value);
  };

  return (
    <div style={{ backgroundColor: color, padding: '20px', textAlign: 'center' }}>
      <h1>Tanlangan rang: {color}</h1>
      <input
        type="color"    
        value={color}
        onChange={handleColorChange}
      />
    </div>
  );
}

export default ColorPicker;