import React, { useState, useEffect, useRef } from "react";
import "./TimerCountdown.css";

function TimerCountdown() {
    const [seconds, setSeconds] = useState(60);
    const [isActive, setIsActive] = useState(false);
    const [initialTime, setInitialTime] = useState(60);
    const intervalRef = useRef(null);

    useEffect(() => {
        if (isActive && seconds > 0) {
            intervalRef.current = setInterval(() => {
                setSeconds(prevSeconds => prevSeconds - 1);
            }, 1000);
        } else if (seconds === 0) {
            clearInterval(intervalRef.current);
            setIsActive(false);
        }

        return () => clearInterval(intervalRef.current);
    }, [isActive, seconds]);

    const handleStartStop = () => {
        setIsActive(!isActive);
    };

    const handleReset = () => {
        clearInterval(intervalRef.current);
        setIsActive(false);
        setSeconds(initialTime);
    };

    const handleTimeChange = (e) => {
        const newTime = parseInt(e.target.value);
        if (!isActive && newTime > 0) {
            setInitialTime(newTime);
            setSeconds(newTime);
        }
    };

    const formatTime = (timeInSeconds) => {
        const minutes = Math.floor(timeInSeconds / 60);
        const seconds = timeInSeconds % 60;
        return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    };

    const progress = (1 - seconds / initialTime) * 283;

    return (
        <div className="timer-container">
            <h2 className="timer-title">Taymer</h2>

            <div className="timer-display">
                <div className="progress-ring">
                    <svg className="progress-circle" width="120" height="120">
                        <circle
                            className="progress-circle-background"
                            strokeWidth="8"
                            cx="60"
                            cy="60"
                            r="45"
                        />
                        <circle
                            className="progress-circle-progress"
                            strokeWidth="8"
                            strokeDasharray="283"
                            strokeDashoffset={progress}
                            cx="60"
                            cy="60"
                            r="45"
                        />
                    </svg>
                    <div className="time-text">{formatTime(seconds)}</div>
                </div>
            </div>

            <div className="timer-controls">
                <button
                    onClick={handleStartStop}
                    className={`timer-btn ${isActive ? 'timer-btn-stop' : 'timer-btn-start'}`}
                >
                    {isActive ? "To'xtatish" : "Boshlash"}
                </button>
                <button
                    onClick={handleReset}
                    className="timer-btn timer-btn-reset"
                >
                    Qayta boshlash
                </button>
            </div>

            <div className="time-settings">
                <label htmlFor="time-input">Taymer vaqtini soatda kiriting:</label>
                <input
                    id="time-input"
                    type="number"
                    min="1"
                    max="3600"
                    value={initialTime}
                    onChange={handleTimeChange}
                    disabled={isActive}
                    className="time-input"
                />
            </div>

            {seconds === 0 && (
                <div className="timer-complete">
                    <div className="timer-alert">Vaqt tugadi!</div>
                </div>
            )}
        </div>
    );
}

export default TimerCountdown;