import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { I18nextProvider } from 'react-i18next';
import { ThemeProvider } from './contexts/ThemeContext';
import { LanguageProvider } from './contexts/LanguageContext';
import i18n from './i18n';

import Header from './components/Header';
import Sidebar from './components/Sidebar';
import Login from './pages/Login';
import Home from './pages/Home';
import Shorts from './pages/Shorts';
import VideoPage from './pages/VideoPage';
import Subscriptions from './pages/Subscriptions';
import Library from './pages/Library';

const ProtectedRoute = ({ children }) => {
  const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
  return isLoggedIn ? children : <Navigate to="/login" replace />;
};

const App = () => {
  useEffect(() => {
    const savedTheme = localStorage.getItem('theme') || 'light';
    document.documentElement.setAttribute('data-theme', savedTheme);
  }, []);

  const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';

  return (
    <I18nextProvider i18n={i18n}>
      <ThemeProvider>
        <LanguageProvider>
          <Router>
            <div className="app">
              <Routes>
                <Route path="/login" element={<Login />} />
                <Route
                  path="/*"
                  element={
                    <ProtectedRoute>
                      <>
                        <Header />
                        <Sidebar />
                        <Routes>
                          <Route path="/" element={<Home />} />
                          <Route path="/shorts" element={<Shorts />} />
                          <Route path="/video/:id" element={<VideoPage />} />
                          <Route path="/subscriptions" element={<Subscriptions />} />
                          <Route path="/library" element={<Library />} />
                        </Routes>
                      </>
                    </ProtectedRoute>
                  }
                />
              </Routes>
            </div>
          </Router>
        </LanguageProvider>
      </ThemeProvider>
    </I18nextProvider>
  );
};

export default App;