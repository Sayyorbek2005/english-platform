import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useTheme } from '../contexts/ThemeContext';
import { useLanguage } from '../contexts/LanguageContext';
import { FaVideo, FaSearch, FaMicrophone } from 'react-icons/fa';
import { IoMdNotifications } from 'react-icons/io';
import './Header.css';

const Header = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { theme, toggleTheme } = useTheme();
  const { changeLanguage, languages, currentLanguage } = useLanguage();
  const [showNotifications, setShowNotifications] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  
  const notificationRef = useRef(null);
  const profileRef = useRef(null);
  const userName = localStorage.getItem('userName') || 'Sayyor';

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (notificationRef.current && !notificationRef.current.contains(event.target)) {
        setShowNotifications(false);
      }
      if (profileRef.current && !profileRef.current.contains(event.target)) {
        setShowProfile(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('isLoggedIn');
    localStorage.removeItem('userName');
    navigate('/login');
  };

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      console.log('Searching for:', searchQuery);
    }
  };

  return (
    <header className="header">
      <div className="header-left">
        <div className="logo" onClick={() => navigate('/')}>
          <div className="youtube-logo">
            <span className="logo-icon">▶</span>
            <span className="logo-text">YouTube</span>
          </div>
        </div>
      </div>

      <div className="header-center">
        <form className="search-container" onSubmit={handleSearch}>
          <input
            type="text"
            className="search-input"
            placeholder={t('header.searchPlaceholder')}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          <button type="submit" className="search-button">
            <FaSearch />
          </button>
        </form>
        <button className="voice-search">
          <FaMicrophone />
        </button>
      </div>

      <div className="header-right">
        <button className="header-icon">
          <FaVideo />
        </button>

        <div className="notification-container" ref={notificationRef}>
          <button
            className="header-icon notification-icon"
            onClick={() => setShowNotifications(!showNotifications)}
          >
            <IoMdNotifications />
            <span className="notification-badge">2</span>
          </button>
          {showNotifications && (
            <div className="notification-dropdown">
              <div className="notification-header">
                <h3>Notifications</h3>
              </div>
              <div className="notification-item">
                <div className="notification-content">
                  <p>New video from CodeWithSayyor</p>
                  <span>2 hours ago</span>
                </div>
              </div>
              <div className="notification-item">
                <div className="notification-content">
                  <p>JavaScript Master uploaded a new video</p>
                  <span>1 day ago</span>
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="profile-container" ref={profileRef}>
          <button
            className="profile-avatar"
            onClick={() => setShowProfile(!showProfile)}
          >
            <img
              src="https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=150"
              alt="Profile"
            />
          </button>
          {showProfile && (
            <div className="profile-dropdown">
              <div className="profile-info">
                <img
                  src="https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=150"
                  alt="Profile"
                />
                <span>{userName}</span>
              </div>
              <div className="dropdown-divider"></div>
              
              <div className="dropdown-section">
                <button className="dropdown-item" onClick={toggleTheme}>
                  <span>{t('profile.theme')}</span>
                  <span className="theme-indicator">
                    {theme === 'light' ? '☀️' : '🌙'}
                  </span>
                </button>
              </div>

              <div className="dropdown-section">
                <div className="dropdown-label">{t('profile.language')}</div>
                {languages.map((lang) => (
                  <button
                    key={lang.code}
                    className={`dropdown-item language-item ${currentLanguage === lang.code ? 'active' : ''}`}
                    onClick={() => changeLanguage(lang.code)}
                  >
                    <span>{lang.flag} {lang.name}</span>
                    {currentLanguage === lang.code && <span className="checkmark">✓</span>}
                  </button>
                ))}
              </div>

              <div className="dropdown-divider"></div>
              <button className="dropdown-item logout-item" onClick={handleLogout}>
                {t('profile.logout')}
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;