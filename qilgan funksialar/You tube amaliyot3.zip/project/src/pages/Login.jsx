import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import './Login.css';

const Login = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: '',
    code: ''
  });
  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const validateForm = () => {
    const newErrors = {};

    if (formData.name !== 'Sayyor') {
      newErrors.name = t('login.nameError');
    }

    const code = parseInt(formData.code);
    if (!formData.code || isNaN(code) || code < 1 || code > 12345) {
      newErrors.code = t('login.codeError');
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (validateForm()) {
      localStorage.setItem('isLoggedIn', 'true');
      localStorage.setItem('userName', formData.name);
      navigate('/');
    }
  };

  return (
    <div className="login-container">
      <div className="login-card">
        <div className="login-header">
          <div className="youtube-logo">
            <span className="logo-icon">▶</span>
            <span className="logo-text">YouTube</span>
          </div>
          <h1>{t('login.title')}</h1>
        </div>

        <form className="login-form" onSubmit={handleSubmit}>
          <table className="form-table">
            <tbody>
              <tr>
                <td className="form-label">
                  <label htmlFor="name">{t('login.nameLabel')}:</label>
                </td>
                <td className="form-input">
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    className={errors.name ? 'error' : ''}
                    required
                  />
                  {errors.name && <span className="error-message">{errors.name}</span>}
                </td>
              </tr>
              <tr>
                <td className="form-label">
                  <label htmlFor="code">{t('login.codeLabel')}:</label>
                </td>
                <td className="form-input">
                  <input
                    type="number"
                    id="code"
                    name="code"
                    value={formData.code}
                    onChange={handleChange}
                    className={errors.code ? 'error' : ''}
                    min="1"
                    max="12345"
                    required
                  />
                  {errors.code && <span className="error-message">{errors.code}</span>}
                </td>
              </tr>
              <tr>
                <td colSpan="2" className="form-submit">
                  <button type="submit" className="login-button">
                    {t('login.loginButton')}
                  </button>
                </td>
              </tr>
            </tbody>
          </table>
        </form>
      </div>
    </div>
  );
};

export default Login;