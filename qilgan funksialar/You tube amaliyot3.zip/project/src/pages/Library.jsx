import React from 'react';
import { useTranslation } from 'react-i18next';
import './Library.css';

const Library = () => {
  const { t } = useTranslation();

  return (
    <div className="library-container">
      <div className="library-content">
        <h1>{t('sidebar.library')}</h1>
        <p>This page is coming soon...</p>
      </div>
    </div>
  );
};

export default Library;