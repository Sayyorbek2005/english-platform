import './App.css';
import TodoList from './components/TodoList.jsx';


function App() {
  return (
    <div>
      <TodoList />
    </div>
  );
}

export default App;
