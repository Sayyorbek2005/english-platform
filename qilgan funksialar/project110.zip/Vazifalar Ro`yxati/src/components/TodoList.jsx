import React, { useState } from 'react';
import './TodoList.css';

function TodoList() {
 
  const [todos, setTodos] = useState([]);
  const [newTodo, setNewTodo] = useState('');

  // Yangi vazifa kiritish
  const handleInputChange = (event) => {
    setNewTodo(event.target.value);
  };

  // Vazifa qo‘shish
  const addTodo = () => {
    if (newTodo.trim() !== '') {
      setTodos([...todos, newTodo]);
      setNewTodo('');
    }
  };

  // Vazifani o‘chirish
  const removeTodo = (index) => {
    setTodos(todos.filter((_, i) => i !== index));
  };

  return (
    <div className="TodoList">
      <h1>Vazifalar Ro‘yxati</h1>
      <div>
        <input
          type="text"
          value={newTodo}
          onChange={handleInputChange}
          placeholder="Yangi vazifa kiriting..."
        />
        <button onClick={addTodo}>Qo‘shish</button>
      </div>
      <ul>
        {todos.map((todo, index) => (
          <li key={index}>
            {todo}
            <button onClick={() => removeTodo(index)}>O‘chirish</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default TodoList;