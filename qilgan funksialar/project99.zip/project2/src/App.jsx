import { useState } from 'react'
import './App.css'

function App() {
  const [searchTerm, setSearchTerm] = useState('')

  const cards = [
    {
      id: 1,
      title: 'Foundation',
      
    },
    {
      id: 2,
      title: 'Frontend',
      
    },
    {
      id: 3,
      title: 'Backend',
      
    }
  ]

  const filteredCards = cards.filter(card =>
    card.title.toLowerCase().includes(searchTerm.toLowerCase())
  )

  const handleSearchChange = (e) => {
    setSearchTerm(e.target.value)
  }

  return (
      <div className="app">
      <header className="header">
        <div className="container">
          <input
            type="text"
            placeholder="Search"
            value={searchTerm}
            onChange={handleSearchChange}
            className="search-input"
          />
        </div>
      </header>

      <main className="main">
        <section className="hero">
          <div className="container">
            <div className="cards-grid">
              {filteredCards.map(card => (
                <div key={card.id} className="card">
                 
                  <h3 className="card-title">{card.title}</h3>
                </div>
              ))}
            </div>
            {filteredCards.length === 0 && (
              <div className="no-results">
                <p>Unaqa narsa yuq  "{searchTerm}"</p>
              </div>
            )}
          </div>
        </section>
      </main>
    </div>
  )
}

export default App