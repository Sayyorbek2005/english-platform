import React, { useState } from 'react';

function SearchableTable() {
  const [uzunlik, setUzunlik] = useState(8);
  const [harflar, setHarflar] = useState(true);
  const [raqamlar, setRaqamlar] = useState(true);
  const [maxsusBelgilar, setMaxsusBelgilar] = useState(false);
  const [parol, setParol] = useState('');

  const parolYaratish = () => {
    const kattaHarflar = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const kichikHarflar = 'abcdefghijklmnopqrstuvwxyz';
    const raqamlarStr = '0123456789';
    const maxsusBelgilarStr = '!@#$%^&*()_+-=[]{}|;:,.<>?';

    let belgilar = '';
    if (harflar) belgilar += kattaHarflar + kichikHarflar;
    if (raqamlar) belgilar += raqamlarStr;
    if (maxsusBelgilar) belgilar += maxsusBelgilarStr;

    if (!belgilar) {
      setParol('Iltimos, kamida bitta tur tanlang!');
      return;
    }

    let yangiParol = '';
    for (let i = 0; i < uzunlik; i++) {
      const tasodifiyIndex = Math.floor(Math.random() * belgilar.length);
      yangiParol += belgilar[tasodifiyIndex];
    }
    setParol(yangiParol);
  };

  return (
    <div style={{ padding: '20px', maxWidth: '400px', margin: '0 auto', textAlign: 'center' }}>
      <h2>Uzunligi</h2>
      <div style={{ marginBottom: '20px' }}>
        <label>
          Uzunlik:
          <input
            type="number"
            value={uzunlik}
            onChange={(e) => setUzunlik(Math.max(4, e.target.value))}
            min="4"
            style={{ marginLeft: '10px', padding: '5px', width: '60px' }}
          />
        </label>
      </div>
      <div style={{ marginBottom: '20px' }}>
        <label style={{ marginRight: '20px' }}>
          <input
            type="checkbox"
            checked={harflar}
            onChange={() => setHarflar(!harflar)}
          />
          Harflar
        </label>
        <label style={{ marginRight: '20px' }}>
          <input
            type="checkbox"
            checked={raqamlar}
            onChange={() => setRaqamlar(!raqamlar)}
          />
          Raqamlar
        </label>
        <label>
          <input
            type="checkbox"
            checked={maxsusBelgilar}
            onChange={() => setMaxsusBelgilar(!maxsusBelgilar)}
          />
          Maxsus belgilar
        </label>
      </div>
      <button
        onClick={parolYaratish}
        style={{
          padding: '10px 20px',
          backgroundColor: '#007bff',
          color: 'white',
          border: 'none',
          borderRadius: '5px',
          cursor: 'pointer',
        }}
      >
        Parol yaratish
      </button>
      {parol && (
        <div style={{ marginTop: '20px', wordBreak: 'break-all' }}>
          <p style={{ fontWeight: 'bold', color: parol.includes('Iltimos') ? 'red' : 'black' }}>
            {parol}
          </p>
        </div>
      )}
    </div>
  );
}

export default SearchableTable;