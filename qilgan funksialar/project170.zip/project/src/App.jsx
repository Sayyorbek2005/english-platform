import './App.css';
import SearchableTable from './components/SearchableTable';




function App() {
 
  return (
    <div className="App">
      <SearchableTable />
    </div>
  );
}

export default App;
