import { useState } from 'react'
import './App.css'

function App() {
 
  const [fruits, setFruits] = useState(['feijoa', 'evkalipt', 'banan', 'dovcha', 'anjir', 'olma', 'nok', 'shaftoli', 'gilos', 'orik'])

  const sortFruits = () => {
    const sortedFruits = [...fruits].sort((a, b) => a.localeCompare(b))
    setFruits(sortedFruits)
  }

  return (
    <div className="app">
     
      <header className="header">
        <div className="header-container">
          <button className="tartibli-button" onClick={sortFruits}>
            Tartibli
          </button>
        </div>
      </header>

    
      <main className="hero">
        <div className="hero-container">
          <h1 className="hero-title">Kolleksia</h1>
          <div className="fruits-grid">
            {fruits.map((fruit, index) => (
              <div key={`${fruit}-${index}`} className="fruit-card">
                <span className="fruit-name">{fruit}</span>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  )
}

export default App