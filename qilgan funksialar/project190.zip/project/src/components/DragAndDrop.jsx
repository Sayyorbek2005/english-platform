import React, { useState } from 'react';

function DragAndDrop() {
  const [vazifalar, setVazifalar] = useState([
    { id: 1, matn: 'Vazifa 1' },
    { id: 2, matn: 'Vazifa 2' },
    { id: 3, matn: 'Vazifa 3' },
  ]);
  const [bajarilgan, setBajarilgan] = useState([]);

  const dragStart = (e, id, manba) => {
    e.dataTransfer.setData('id', id);
    e.dataTransfer.setData('manba', manba);
  };

  const drop = (e, manzil) => {
    e.preventDefault();
    const id = parseInt(e.dataTransfer.getData('id'));
    const manba = e.dataTransfer.getData('manba');

    if (manba === manzil) return;

    if (manba === 'vazifalar') {
      const vazifa = vazifalar.find((v) => v.id === id);
      setVazifalar(vazifalar.filter((v) => v.id !== id));
      setBajarilgan([...bajarilgan, vazifa]);
    } else {
      const vazifa = bajarilgan.find((v) => v.id === id);
      setBajarilgan(bajarilgan.filter((v) => v.id !== id));
      setVazifalar([...vazifalar, vazifa]);
    }
  };

  const allowDrop = (e) => {
    e.preventDefault();
  };

  return (
    <div style={{ padding: '20px', maxWidth: '600px', margin: '0 auto', display: 'flex', gap: '20px' }}>
      <div
        onDrop={(e) => drop(e, 'vazifalar')}
        onDragOver={allowDrop}
        style={{ width: '50%', border: '1px solid #ccc', padding: '10px', minHeight: '200px' }}
      >
        <h3>Yangi Vazifalar</h3>
        {vazifalar.map((vazifa) => (
          <div
            key={vazifa.id}
            draggable
            onDragStart={(e) => dragStart(e, vazifa.id, 'vazifalar')}
            style={{
              padding: '10px',
              margin: '5px',
              backgroundColor: '#f0f0f0',
              borderRadius: '5px',
            }}
          >
            {vazifa.matn}
          </div>
        ))}
      </div>
      <div
        onDrop={(e) => drop(e, 'bajarilgan')}
        onDragOver={allowDrop}
        style={{ width: '50%', border: '1px solid #ccc', padding: '10px', minHeight: '200px' }}
      >
        <h3>Bajarilgan Vazifalar</h3>
        {bajarilgan.map((vazifa) => (
          <div
            key={vazifa.id}
            draggable
            onDragStart={(e) => dragStart(e, vazifa.id, 'bajarilgan')}
            style={{
              padding: '10px',
              margin: '5px',
              backgroundColor: '#d4edda',
              borderRadius: '5px',
            }}
          >
            {vazifa.matn}
          </div>
        ))}
      </div>
    </div>
  );
}

export default DragAndDrop;