import './App.css';
import DragAndDrop from './components/DragAndDrop';



function App() {


  return (
    <div className="App">
      <DragAndDrop />
    </div>
  );
}

export default App;
