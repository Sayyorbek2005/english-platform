import React, { useState } from 'react';
import { MessageSquare, Palette, Plus, Minus, Type } from 'lucide-react';

function App() {
  const [message, setMessage] = useState("");
  const [inputText, setInputText] = useState("");
  const [count, setCount] = useState(0);
  const [isRed, setIsRed] = useState(false);
  const [bgColor, setBgColor] = useState("#fff");

  const colors = [
    { color: "#FFCDD2", name: "Pink" },
    { color: "#C8E6C9", name: "Green" }, 
    { color: "#BBDEFB", name: "Blue" },
    { color: "#FFF9C4", name: "Yellow" },
    { color: "#D1C4E9", name: "Purple" }
  ];

  function showMessage() {
    setMessage("Tugmani bosdingiz!");
    // Clear message after 3 seconds
    setTimeout(() => setMessage(""), 3000);
  }

  function alertInput() {
    if (inputText.trim()) {
      alert(`Siz yozdingiz: "${inputText}"`);
    } else {
      alert("Hech nima yozilmadi");
    }
  }

  function changeBgColor() {
    const randomColor = colors[Math.floor(Math.random() * colors.length)];
    setBgColor(randomColor.color);
  }

  function increment() {
    setCount((c) => c + 1);
  }

  function decrement() {
    setCount((c) => c - 1);
  }

  function toggleTextColor() {
    setIsRed((r) => !r);
  }

  return (
    <div 
      className="min-h-screen transition-all duration-500 ease-in-out p-4"
      style={{ backgroundColor: bgColor }}
    >
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center py-8">
          <h1 
            className={`text-5xl font-bold transition-colors duration-300 ${
              isRed ? 'text-red-500' : 'text-gray-800'
            }`}
          >
            Salom, React!
          </h1>
          <p className="text-gray-600 mt-2 text-lg">Interactive React Components</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Message Card */}
          <div className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow duration-300">
            <div className="flex items-center mb-4">
              <MessageSquare className="text-blue-500 mr-3" size={24} />
              <h3 className="text-xl font-semibold text-gray-800">Xabar</h3>
            </div>
            <button
              onClick={showMessage}
              className="w-full bg-blue-500 hover:bg-blue-600 text-white font-medium py-3 px-4 rounded-lg transition-colors duration-200 transform hover:scale-105"
            >
              Xabar ko'rsat
            </button>
            {message && (
              <div className="mt-4 p-3 bg-blue-50 border-l-4 border-blue-500 rounded animate-pulse">
                <p className="text-blue-800 font-medium">{message}</p>
              </div>
            )}
          </div>

          {/* Input Alert Card */}
          <div className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow duration-300">
            <div className="flex items-center mb-4">
              <Type className="text-green-500 mr-3" size={24} />
              <h3 className="text-xl font-semibold text-gray-800">Matn Kiritish</h3>
            </div>
            <div className="space-y-3">
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder="Matn kiriting..."
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200"
              />
              <button
                onClick={alertInput}
                className="w-full bg-green-500 hover:bg-green-600 text-white font-medium py-3 px-4 rounded-lg transition-colors duration-200 transform hover:scale-105"
              >
                Alert ko'rsat
              </button>
            </div>
          </div>

          {/* Background Color Card */}
          <div className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow duration-300">
            <div className="flex items-center mb-4">
              <Palette className="text-purple-500 mr-3" size={24} />
              <h3 className="text-xl font-semibold text-gray-800">Fon Rangi</h3>
            </div>
            <button
              onClick={changeBgColor}
              className="w-full bg-purple-500 hover:bg-purple-600 text-white font-medium py-3 px-4 rounded-lg transition-colors duration-200 transform hover:scale-105"
            >
              Rangni o'zgartir
            </button>
            <div className="mt-4 flex justify-center space-x-2">
              {colors.map((colorObj, index) => (
                <div
                  key={index}
                  className="w-6 h-6 rounded-full border-2 border-gray-300"
                  style={{ backgroundColor: colorObj.color }}
                  title={colorObj.name}
                />
              ))}
            </div>
          </div>

          {/* Counter Card */}
          <div className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow duration-300 md:col-span-2 lg:col-span-1">
            <div className="flex items-center mb-4">
              <div className="bg-orange-100 p-2 rounded-lg mr-3">
                <span className="text-orange-500 font-bold text-lg">#</span>
              </div>
              <h3 className="text-xl font-semibold text-gray-800">Hisoblagich</h3>
            </div>
            <div className="flex items-center justify-center space-x-4">
              <button
                onClick={decrement}
                className="bg-red-500 hover:bg-red-600 text-white w-12 h-12 rounded-full flex items-center justify-center transition-all duration-200 transform hover:scale-110"
              >
                <Minus size={20} />
              </button>
              <div className="bg-gray-100 px-6 py-3 rounded-lg">
                <span className="text-3xl font-bold text-gray-800">{count}</span>
              </div>
              <button
                onClick={increment}
                className="bg-green-500 hover:bg-green-600 text-white w-12 h-12 rounded-full flex items-center justify-center transition-all duration-200 transform hover:scale-110"
              >
                <Plus size={20} />
              </button>
            </div>
          </div>

          {/* Text Color Toggle Card */}
          <div className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow duration-300 md:col-span-2">
            <h3 className="text-xl font-semibold text-gray-800 mb-4">Matn Rangi</h3>
            <label className="flex items-center cursor-pointer group">
              <div className="relative">
                <input
                  type="checkbox"
                  checked={isRed}
                  onChange={toggleTextColor}
                  className="sr-only"
                />
                <div className={`w-12 h-6 rounded-full transition-colors duration-200 ${
                  isRed ? 'bg-red-500' : 'bg-gray-300'
                }`}>
                  <div className={`w-5 h-5 bg-white rounded-full shadow transform transition-transform duration-200 translate-y-0.5 ${
                    isRed ? 'translate-x-6' : 'translate-x-0.5'
                  }`} />
                </div>
              </div>
              <span className={`ml-3 font-medium transition-colors duration-200 ${
                isRed ? 'text-red-500' : 'text-gray-700'
              }`}>
                Sarlavha rangini qizilga o'zgartir
              </span>
            </label>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center py-8">
          <p className="text-gray-500">Interactive React Components Demo</p>
        </div>
      </div>
    </div>
  );
}

export default App;