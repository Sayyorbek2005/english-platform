import ContactTable from './ContactTable'
import './Hero.css'

function Hero({ contacts }) {
  return (
    <section className="hero">
      <div className="hero-container">
        <div className="hero-content">
          <h2 className="hero-title">Contacts</h2>
          <p className="hero-subtitle">
           
          </p>
          
          <ContactTable contacts={contacts} />
        </div>
      </div>
    </section>
  )
}

export default Hero