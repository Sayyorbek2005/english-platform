import './ContactTable.css'

function ContactTable({ contacts }) {
  return (
    <div className="table-container">
      <table className="contact-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Name</th>
            <th>Number</th>
          </tr>
        </thead>
        <tbody>
          {contacts.map(contact => (
            <tr key={contact.id} className="table-row">
              <td>{contact.firstName}</td>
              <td>{contact.lastName}</td>
              <td>{contact.phoneNumber}</td>
            </tr>
          ))}
        </tbody>
      </table>
      
      {contacts.length === 0 && (
        <div className="empty-state">
          <p>No contacts yet. Add your first contact above!</p>
        </div>
      )}
    </div>
  )
}

export default ContactTable