import React, { useState } from 'react';
import { Plus, RotateCcw } from 'lucide-react';

export default function App() {
  const [count, setCount] = useState(0);

  const increment = () => setCount(count + 1);
  const reset = () => setCount(0);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Header */}
      <header className="bg-white/10 backdrop-blur-md border-b border-white/20">
        <div className="max-w-6xl mx-auto px-6 py-6">
          <h1 className="text-3xl font-bold text-white text-center tracking-tight">
            My Simple React Site
          </h1>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex items-center justify-center px-6 py-20">
        <div className="max-w-md w-full">
          {/* Counter Card */}
          <div className="bg-white/10 backdrop-blur-lg rounded-3xl p-8 shadow-2xl border border-white/20">
            <div className="text-center mb-8">
              <h2 className="text-lg font-medium text-gray-300 mb-2">Current Count</h2>
              <div className="text-6xl font-bold text-white mb-2 tabular-nums tracking-tight">
                {count}
              </div>
              <div className="h-1 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full mx-auto w-16"></div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-4">
              <button
                onClick={increment}
                className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-semibold py-4 px-8 rounded-2xl transition-all duration-200 transform hover:scale-105 hover:shadow-xl active:scale-95 flex items-center justify-center gap-3 group"
              >
                <Plus className="w-5 h-5 transition-transform group-hover:rotate-90" />
                Increase Count
              </button>

              {count > 0 && (
                <button
                  onClick={reset}
                  className="w-full bg-white/10 hover:bg-white/20 text-white font-medium py-3 px-6 rounded-2xl transition-all duration-200 border border-white/20 hover:border-white/40 flex items-center justify-center gap-2 group"
                >
                  <RotateCcw className="w-4 h-4 transition-transform group-hover:-rotate-45" />
                  Reset
                </button>
              )}
            </div>

            {/* Stats */}
            <div className="mt-8 pt-6 border-t border-white/20">
              <div className="text-center text-sm text-gray-400">
                <p>Clicks: <span className="font-semibold text-white">{count}</span></p>
              </div>
            </div>
          </div>

          {/* Achievement Badge */}
          {count >= 10 && (
            <div className="mt-6 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-2xl p-4 text-center animate-pulse">
              <p className="text-white font-semibold">🎉 Achievement Unlocked!</p>
              <p className="text-yellow-100 text-sm">You've reached {count} clicks!</p>
            </div>
          )}

          {count >= 50 && (
            <div className="mt-4 bg-gradient-to-r from-green-400 to-emerald-500 rounded-2xl p-4 text-center animate-bounce">
              <p className="text-white font-semibold">🚀 Click Master!</p>
              <p className="text-green-100 text-sm">Incredible dedication!</p>
            </div>
          )}
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-black/20 backdrop-blur-md border-t border-white/10">
        <div className="max-w-6xl mx-auto px-6 py-8">
          <div className="text-center text-gray-400">
            <p className="text-sm">
              &copy; 2025 My Simple React Site
            </p>
            <p className="text-xs mt-2 opacity-75">
              Built with React & Tailwind CSS
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}