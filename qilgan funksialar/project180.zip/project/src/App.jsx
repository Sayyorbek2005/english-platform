import './App.css';
import ThemeSwitcher from './components/ThemeSwitcher';

function App() {


  return (
    <div className="App">
      <ThemeSwitcher />
    </div>
  );
}

export default App;
