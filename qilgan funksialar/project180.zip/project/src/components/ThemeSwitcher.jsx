import React, { useState } from 'react';

function ParolniKorsatish() {
  // `ko'rsatish` - bu parolni ko'rsatish yoki yashirish holatini saqlaydigan boolean state.
  const [korsatish, setKorsatish] = useState(false);
  // `parol` - bu inputga kiritilgan parolni saqlaydigan state.
  const [parol, setParol] = useState('');

  // Bu funksiya parolni ko'rsatish holatini o'zgartiradi.
  const holatniOzgartirish = () => {
    setKorsatish(!korsatish);
  };

  return (
    <div style={{ padding: '20px', maxWidth: '400px', margin: '50px auto', border: '1px solid #ccc', borderRadius: '8px' }}>
      <h2 style={{ textAlign: 'center' }}>Parolni Ko'rsatish</h2>
      <br />
      <div style={{ position: 'relative' }}>
        <input
          type={korsatish ? 'text' : 'password'}
          value={parol}
          onChange={(e) => setParol(e.target.value)}
          placeholder="Parol kiriting..."
          style={{
            width: '100%',
            padding: '10px',
            fontSize: '16px',
            boxSizing: 'border-box',
            marginBottom: '10px',
            paddingRight: '40px', // Tugma uchun joy
          }}
        />
        <button
          onClick={holatniOzgartirish}
          style={{
            position: 'absolute',
            right: '5px',
            top: '5px',
            border: 'none',
            background: 'none',
            cursor: 'pointer',
            fontSize: '18px',
          }}
        >
          {korsatish ? '👁️' : '🔒'}
        </button>
      </div>
      <p style={{ textAlign: 'center', marginTop: '10px' }}>
        Kiritilgan parol: <strong>{parol}</strong>
      </p>
    </div>
  );
}

export default ParolniKorsatish;
